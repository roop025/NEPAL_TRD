//    @<script src="aes.js" type="text/javascript"></script>
//    <script type="text/javascript">
    var Base64 = { _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) { var t = ""; var n, r, i, s, o, u, a; var f = 0; e = Base64._utf8_encode(e); while (f < e.length) { n = e.charCodeAt(f++); r = e.charCodeAt(f++); i = e.charCodeAt(f++); s = n >> 2; o = (n & 3) << 4 | r >> 4; u = (r & 15) << 2 | i >> 6; a = i & 63; if (isNaN(r)) { u = a = 64 } else if (isNaN(i)) { a = 64 } t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a) } return t }, decode: function (e) { var t = ""; var n, r, i; var s, o, u, a; var f = 0; e = e.replace(/[^A-Za-z0-9+/=]/g, ""); while (f < e.length) { s = this._keyStr.indexOf(e.charAt(f++)); o = this._keyStr.indexOf(e.charAt(f++)); u = this._keyStr.indexOf(e.charAt(f++)); a = this._keyStr.indexOf(e.charAt(f++)); n = s << 2 | o >> 4; r = (o & 15) << 4 | u >> 2; i = (u & 3) << 6 | a; t = t + String.fromCharCode(n); if (u != 64) { t = t + String.fromCharCode(r) } if (a != 64) { t = t + String.fromCharCode(i) } } t = Base64._utf8_decode(t); return t }, _utf8_encode: function (e) { e = e.replace(/rn/g, "n"); var t = ""; for (var n = 0; n < e.length; n++) { var r = e.charCodeAt(n); if (r < 128) { t += String.fromCharCode(r) } else if (r > 127 && r < 2048) { t += String.fromCharCode(r >> 6 | 192); t += String.fromCharCode(r & 63 | 128) } else { t += String.fromCharCode(r >> 12 | 224); t += String.fromCharCode(r >> 6 & 63 | 128); t += String.fromCharCode(r & 63 | 128) } } return t }, _utf8_decode: function (e) { var t = ""; var n = 0; var r = c1 = c2 = 0; while (n < e.length) { r = e.charCodeAt(n); if (r < 128) { t += String.fromCharCode(r); n++ } else if (r > 191 && r < 224) { c2 = e.charCodeAt(n + 1); t += String.fromCharCode((r & 31) << 6 | c2 & 63); n += 2 } else { c2 = e.charCodeAt(n + 1); c3 = e.charCodeAt(n + 2); t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63); n += 3 } } return t } }



function EncryptText2(str) {

    str = Math.random().toString(36).substring(2, 10) + str;
    var _strkey = Base64.decode("aDRyV0NWRTRqVENkL29IZTY2NTdMZz09LFdFQmc4SkZ3Tk9LQnNFT054azcydXBobmdLRGZGdGVNbGQ2T0dxOEF3MDg9");
    _strkey.split(",");
    var text = CryptoJS.enc.Utf8.parse(str);
    var Key = CryptoJS.enc.Base64.parse(_strkey.split(",")[1]); //secret key
    var IV = CryptoJS.enc.Base64.parse(_strkey.split(",")[0]); //16 digit
    var encryptedText = CryptoJS.AES.encrypt(text, Key, { keySize: 128 / 8, iv: IV, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
    //return encryptedText.toString(CryptoJS.enc.Hex);
    var b64=encryptedText.toString();
    var e64=CryptoJS.enc.Base64.parse(b64);
    var eHex=e64.toLocaleString(CryptoJS.enc.Hex);
    return eHex.toUpperCase();
}

function EncryptText3(str,Key,IV) {

    str = Math.random().toString(36).substring(2, 10) + str;
    
    var text = CryptoJS.enc.Utf8.parse(str);
     Key = CryptoJS.enc.Base64.parse(Key);
	 IV = CryptoJS.enc.Base64.parse(IV); //16 digit
    var encryptedText = CryptoJS.AES.encrypt(text, Key, { keySize: 128 / 8, iv: IV, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
    //return encryptedText.toString(CryptoJS.enc.Hex);
    var b64=encryptedText.toString();
    var e64=CryptoJS.enc.Base64.parse(b64);
    var eHex=e64.toLocaleString(CryptoJS.enc.Hex);
    return eHex.toUpperCase();
}

function DecryptText3(str,Key,IV) {
try{
    //document.getElementById("txtError").value="";
    
    var reb64 = CryptoJS.enc.Hex.parse(str);
   var text = reb64.toString(CryptoJS.enc.Base64);
    //var text = str;
	    Key = CryptoJS.enc.Base64.parse(Key);
	 IV = CryptoJS.enc.Base64.parse(IV); //16 digit
    
    var encryptedText = CryptoJS.AES.decrypt(text, Key, { keySize: 128 / 8, iv: IV, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
    //return encryptedText.toString(CryptoJS.enc.Utf8).substring(8);
    return encryptedText.toString(CryptoJS.enc.Utf8).substring(8);
    }
    catch(e)
    {
          alert(e);
    }
}

function DecryptText2(str) {
try{
    //document.getElementById("txtError").value="";
    var _strkey = Base64.decode("aDRyV0NWRTRqVENkL29IZTY2NTdMZz09LFdFQmc4SkZ3Tk9LQnNFT054azcydXBobmdLRGZGdGVNbGQ2T0dxOEF3MDg9");
    _strkey.split(",");
    var reb64 = CryptoJS.enc.Hex.parse(str);
   var text = reb64.toString(CryptoJS.enc.Base64);
    //var text = str;
    var Key = CryptoJS.enc.Base64.parse(_strkey.split(",")[1]); //secret key
    
    var IV = CryptoJS.enc.Base64.parse(_strkey.split(",")[0]); //16 digit
    var encryptedText = CryptoJS.AES.decrypt(text, Key, { keySize: 128 / 8, iv: IV, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
    //return encryptedText.toString(CryptoJS.enc.Utf8).substring(8);
    return encryptedText.toString(CryptoJS.enc.Utf8).substring(8);
    }
    catch(e)
    {
          alert(e);
    }
}


function OnClickDecrypt(){
   
  var Encrypt = document.getElementById("txtEncryptResult").value;
   document.getElementById("txtDecrypt").innerText =   DecryptText2(Encrypt);

}

function EncryptFromClientSide(){

try{
 var str = document.getElementById("txtEncrypt").value;
 document.getElementById("txtEncryptResult").value="";
 document.getElementById("txtEncryptResult").value= EncryptText2(str);
 document.getElementById("txtEncryptResult").value= EncryptText2(str);

}
catch(e)
{
 alert(e);
}
}

//    </script>
