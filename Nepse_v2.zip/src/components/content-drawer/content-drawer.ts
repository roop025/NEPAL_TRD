import { Component, ElementRef, Input, Renderer } from '@angular/core';
import { DomController, Platform } from 'ionic-angular';

/**
 * Generated class for the ContentDrawerComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */

import { ViewChild, ChangeDetectorRef, NgZone } from '@angular/core';
import { NavController, IonicPage, NavParams, Events, Navbar, PopoverController, FabButton, Slides, ModalController ,AlertController} from 'ionic-angular';
import { MarketDepthProvider } from '../../providers/market-depth/market-depth';
import { ReportProvider } from '../../providers/report/report';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import { QuoteHeaderProvider } from '../../providers/quote-header/quote-header';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { Storage } from '@ionic/storage';
import swal from 'sweetalert2';
import {BuySellProvider} from "../../providers/buy-sell/buy-sell";


@Component({
  selector: 'content-drawer',
  templateUrl: 'content-drawer.html'
})
export class ContentDrawerComponent {

  @Input('options') options: any;
  handleHeight: number = 50;
  bounceBack: boolean = true;
  thresholdTop: number = 200;
  thresholdBottom: number = 200;





  optionsBrowser: InAppBrowserOptions = {
    location: 'no',//Or 'no'
    hidden: 'no', //Or  'yes'
    clearcache: 'yes',
    clearsessioncache: 'yes',
    hardwareback: 'yes',
  };
  public depthdata: any;
  public item: any;
  public finacialData: any;
  public curentDate: any;
  public dd: any;
  public mm: any;
  public yyyy: any;
  public Volume1: any;
  public TTQ1: any;
  public quote_result_data: any;
  public itemset: any;
  public company_result_data: any;
  public GetCompanyInformationData: any;
  public TickSize: any;
  public DPR: any;
  public clientUserData: any;
  public scripOrderReport_result: any;
  public orderitems: any;
  public tradeOrderReport_result: any;
  public tradeitems: any;
  public marketDepth_result: any;
  public keylist: any;
  public itemNew: any;
  public webSocket_Data: any;
  public getSpecifiedReport_result: any;
  public marketInformationData: any;
  public date: any;
  public time: any;
  public getIntradayChart_result: any;
  public jsonData: any;
  public DataMessage: any;
  public message: any;
  public msg: any;
  public ClientName: any;
  public ltp_result_data: any;
  public itemLTPData: any;
  //public intervalId : any;
  public tabsSection: any;
  public headingName: any;
  public percentChange: any;
  public specifiedQuote_result: any;
  public quoteitems: any;
  public itemQuote: any = { underlying: ' ', LTP: ' ' };
  public sep1: any;
  public sep2: any;
  public spreadType: any;
  public itemQuoteNew: any;
  public dprArry: any;
  public MarketLot: any;
  public newsUrlScrip: any;
  public newsUrl: any;
  public itemNews: any;
  public quoteItem: any;
  public itemToBuySell: any;
  public disableName: any;
  public longTermExpiryData: any;
  public newTicker = '';
  public newTickerCode: any;
  public getDate = [];
  dpthData: any;
  selectedTabIndex: any;
  activeInd: any = 1;
  userData: any;
  show_buy_sell: any;
  show_buy_sell_future: any;

  // alert data here
  public alertDataObj: any;
  AlertObject: any = {};
  altNotification: any;
  altValue: '';
  public showAlertContainer: any;
  public scriptname: any;
  public aleartId: any = '';
  public optionValue = { callPut: '', date: '' };
  public tkr: any = '';
  public optionData: any;
  public strikPrizeData: any;
  public optionListData: any;
  public expiryMsg: any;
  Interval_obj: any;
  // public options:any;
  data;
  prev_page:any;
  cancelOrderObject:any;
  @ViewChild(Navbar) navBar: Navbar;
  @ViewChild(Slides) slides: Slides;

  
  // constructor(public element: ElementRef, public renderer: Renderer, public domCtrl: DomController, public platform: Platform) {
  // }

  constructor(public element: ElementRef, public renderer: Renderer, public domCtrl: DomController, public platform: Platform,
    public navCtrl: NavController,
    public navParams: NavParams,
    public marketDepthManager: MarketDepthProvider,
    public getReportManager: ReportProvider,
    public socket: WebsocketProvider,
    private clientMarketWatchList: GlobalVariableService,
    private commonService: CommonProvider,
    public popoverCtrl: PopoverController,
    private quoteHeaderManager: QuoteHeaderProvider,
    private theInAppBrowser: InAppBrowser,
    private ev: Events,
    public websocketUtilityManager: WebsocketUtilityService,
    private changeDetectorRef: ChangeDetectorRef,
    public eref: ElementRef,
    private storage: Storage, public modalCtrl: ModalController,
    public ngZone: NgZone,
    public alertCtrl:AlertController,
    public buySellManager : BuySellProvider,
  )
  {
    this.disableName = true;
    this.expiryMsg = false;
    this.AlertObject = { "ClientCode": "SHRUTICLI2", "AlertName": "", "Ticker": "TCSEQ", "AlertExpression": "=", "ColumnList": "LTP", "EmailNotification": "0", "SMSNotification": "1", "PushNotification": "0", "ApplicationNotification": "0", "Status": "Active", "Remark": "blue" };

    this.optionValue = {
      callPut: 'CE',
      date: 'PE'
    }
    this.optionValue.callPut = 'CE'
    this.tabsSection = 'marketDepth'
    this.newTickerCode = [];
    this.optionListData = [];
    this.depthdata = [
      {
        "Ticker": "", "DateTime": "", "depth":
          [
            { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
            { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
            { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
            { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
            { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" }
          ],

      }
    ];
    this.itemNew = [];
    this.itemQuoteNew = [];
    this.itemQuote = [];
    this.Volume1 = ''
    this.MarketLot = ''
    this.item = ''
    this.data = [];
    this.dprArry = [];
    this.message = ""

    //console.log("this.depthdata",this.depthdata)
    this.clientMarketWatchList.setPageName({ currentPageName: "MarketDepthPage" });
    this.ClientName = clientMarketWatchList.clientName;
    this.ev.subscribe('items', data => {
      this.item = data;
    });

  }

  ionViewDidEnter(){

    if(this.keylist) { 
      this.socket.send(this.keylist.toUpperCase());

      this.itemNew.push(this.item)
      this.websocketUtilityManager.getFeedAfterSubscribeMDepth(this.depthdata, this.item).then((data) => {
        this.webSocket_Data = data;
      })
    }
    
  }

  ionViewDidLoad() {
    // ionViewDidEnter(){
    //---get the selected scrip data --
    this.item = this.navParams.get('userMWDepthData');
    

    let ddd = this.navParams.get('ev')
    console.log(ddd)
    if(!this.item){
      this.item = ddd
    }

    this.finacialData = this.item;
    this.itemToBuySell = this.navParams.get('userMWDepthData');
    console.log("this.item from depth>>>>>>>>>>>>>>>>>>", this.item)
    console.log("this.item from userMWDepthData", this.itemToBuySell)
    this.percentChange = (this.item.LTP - this.item.Close) / this.item.Close;
    this.clientUserData = this.navParams.get('clientUserData');


    this.clientMarketWatchList.setclosingMWatch(false);
    this.prev_page=this.navParams.get('prev_page') || '';
    //---Computation of initial operations --
    this.PrepareUnderlyingAndTicker()
    //-------------------

    //find date and compare with current date the show time if date is today else date
    this.curentDate = new Date();
    this.dd = this.curentDate.getDate();
    this.mm = this.curentDate.getMonth() + 1; //January is 0!
    this.yyyy = this.curentDate.getFullYear();
    if (this.dd < 10) {
      this.dd = '0' + this.dd
    }
    if (this.mm < 10) {
      this.mm = '0' + this.mm
    }
    /* curentDate = mm+'/'+dd+'/'+yyyy; */
    this.curentDate = this.dd + '/' + this.mm + '/' + this.yyyy;
    //  var x = curentDate.toString();
    //check format of amount in k , lacs,crore for volume
    if (this.item.Volume >= 10000000) {
      this.Volume1 = (this.item.Volume / 10000000).toFixed(2) + ' Cr';
    } else if (this.item.Volume >= 100000) {
      this.Volume1 = (this.item.Volume / 100000).toFixed(2) + ' Lac';
    } else if (this.item.Volume >= 1000) {
      this.Volume1 = (this.item.Volume / 1000).toFixed(2) + ' K';
    } else {
      this.Volume1 = this.item.Volume;
    }
    //check format of amount in k , lacs,crore for TTQ
    if (this.item.TTQ >= 10000000) {
      this.TTQ1 = (this.item.TTQ / 10000000).toFixed(2) + ' Cr';
    } else if (this.item.TTQ >= 100000) {
      this.TTQ1 = (this.item.TTQ / 100000).toFixed(2) + ' Lac';
    } else if (this.item.TTQ >= 1000) {
      this.TTQ1 = (this.item.TTQ / 1000).toFixed(2) + ' K';
    } else {
      this.TTQ1 = this.item.TTQ;
    }
    //console.log(' this.item', this.item);
    //---Call of function to get the service ---
    this.socket.connect();
    this.getMarketDepthInfo();
    this.ToGetSpecifiedCollumsData();
    this.getCompanyInformation();

    
    // //------Service to call intraday chart--
    this.loadIntradayChart();
    

    this.storage.get("userMaster").then((data) => {
      if (data != null && data != '') {
        this.userData = data;
      }
    });
    this.refreshZone();
  }

  ionViewDidLeave() {
    
  }

  public PrepareUnderlyingAndTicker(){
    if(!this.item.underlying){
      this.item.underlying = this.item.ticker.split("~")[0]
    }

    if (this.item.Instrument === "FUTIDX" || this.item.Instrument === "OPTIDX") {
      switch (this.item.underlying) {
        case "NIFTY 50":
          this.item.underlying = "Nifty";
          break;
        case "NIFTY BANK":
          this.item.underlying = "BANKNIFTY";
          break;
        case "NIFTY IT":
          this.item.underlying = "NiftyIT";
          break;
        case "NIFTY MIDCAP 50":
          this.item.underlying = "NIFTYMID50";
          break;
        case "NIFTY PSE":
          this.item.underlying = "NIFTYPSE";
          break;
        case "NIFTY INFRA":
          this.item.underlying = "NIFTYINFRA";
          break;
      }
    }



    //------------------
    if (this.item.Instrument == "FUTSTK" || this.item.Instrument == "FUTCUR" || this.item.Instrument == "FUTCOM" || this.item.Instrument == "FUTIDX") {
      this.item.reconstructedTicker = this.item.underlying + '~F:' + this.item.ExpiryDate;
    } else if (this.item.Instrument == "OPTSTK" || this.item.Instrument == "OPTCUR" || this.item.Instrument == "OPTFUT" || this.item.Instrument === "OPTIDX") {
      this.item.reconstructedTicker = this.item.underlying + '~O:' + this.item.ExpiryDate + ':' + this.item.optType + ':' + this.item.strikePrice;
    } else if (this.item.Instrument == "SPREAD") {
      this.item.reconstructedTicker = this.item.ticker;
    } else {
      this.item.reconstructedTicker = this.item.ticker;
    }
  }
  //----Service to get specified column data --
  ToGetSpecifiedCollumsData() {
    this.marketDepthManager.getSpecifiedQuoteData(this.item.exchange, this.item.ticker).then((data) => {
      this.quote_result_data = data;
      if (this.quote_result_data.ErrorCode == 0) {
        this.itemset = JSON.parse(this.quote_result_data.data);
        if(this.prev_page!='mwatch'){
          let rtiker=this.item.reconstructedTicker;
          let underlying = this.item.underlying;
          this.item = this.itemset[0];
          this.item.reconstructedTicker = rtiker;
          this.item.underlying = underlying;
        }
        this.PrepareUnderlyingAndTicker()
        this.quoteItem = this.itemset[0];
        try {
          if (this.item.Volume >= 10000000) {
            this.Volume1 = (this.item.Volume / 10000000).toFixed(2) + ' Cr';
          } else if (this.item.Volume >= 100000) {
            this.Volume1 = (this.item.Volume / 100000).toFixed(2) + ' Lac';
          } else if (this.item.Volume >= 1000) {
            this.Volume1 = (this.item.Volume / 1000).toFixed(2) + ' K';
          } else {
            this.Volume1 = this.item.Volume;
          }
          if (this.item.TTQ >= 10000000) {
            this.TTQ1 = (this.item.TTQ / 10000000).toFixed(2) + ' Cr';
          } else if (this.item.TTQ >= 100000) {
            this.TTQ1 = (this.item.TTQ / 100000).toFixed(2) + ' Lac';
          } else if (this.item.TTQ >= 1000) {
            this.TTQ1 = (this.item.TTQ / 1000).toFixed(2) + ' K';
          } else {
            this.TTQ1 = this.item.TTQ;
          }
        } catch (err) { }
        //---get company information section --
         //this.getCompanyInformation();


         this.quoteitems = JSON.parse(this.quote_result_data.data);
        //  //this.quoteitems = this.itemset;
         // console.log('-*-*-*-*-*-*-*-*-*-*-*-*-', this.items);
         if (this.quoteitems.ExpiryDate == undefined) {
           this.quoteitems.ExpiryDate = this.item.ExpiryDate;
         }
         this.itemQuote = this.quoteitems[0];
         //console.log("this.itemQuote",this.itemQuote)
         try {
           if (this.itemQuote.Close != 0 && this.itemQuote.LTP != '' && this.itemQuote.LTP != 0) {
             this.itemQuote['%Change'] = Number((((this.itemQuote.LTP - this.itemQuote.Close) / this.itemQuote.Close) * 100).toFixed(2));
           } else {
             this.itemQuote['%Change'] = 0.00;
           }
         } catch (err) { }
         // console.log("this.item-->>",this.item);
         //---look for tilde (~), if found, the ticker is F&O. then find if there is more than 1 Colen (:), if found, ticker is Options
         //---use this to identify underlying, expiry, option type and strike price
         var tickertype = 'EQT';
         if (this.itemQuote.ticker.search("~") > 0) {
           tickertype = 'FUT';
           if (this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":") + 1) > 0) {
             tickertype = 'OPT';
           }
           if (this.itemQuote.ticker.search("~S") > 0) {
             tickertype = 'SPD';
           }
         }
         if (tickertype == 'EQT') {
           this.itemQuote.underlying = this.itemQuote.ticker.toUpperCase();
           this.itemQuote.optType = '';
           this.itemQuote.strikePrice = '';
           this.sep1 = '';
           this.sep2 = '';
         }
         if (tickertype == 'FUT') {
           this.itemQuote.underlying = this.itemQuote.ticker.substr(0, this.itemQuote.ticker.search("~")).toUpperCase();
           this.itemQuote.optType = '';
           this.itemQuote.strikePrice = '';
           this.sep1 = '|';
           this.sep2 = '';
         }
         if (tickertype == 'SPD') {
           this.itemQuote.underlying = this.itemQuote.ticker.substr(0, this.itemQuote.ticker.search("~")).toUpperCase();
           this.itemQuote.optType = 'S';
           this.spreadType = this.itemQuote.ticker.substr(this.itemQuote.ticker.indexOf(":") + 1);
           this.itemQuote.strikePrice = this.spreadType.split("~")[0];
           this.sep1 = '|';
           this.sep2 = '|';
         }
         if (tickertype == 'OPT') {
           this.itemQuote.underlying = this.itemQuote.ticker.substr(0, this.itemQuote.ticker.search("~")).toUpperCase();
           this.itemQuote.optType = this.itemQuote.ticker.substr(this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":") + 1) + 1, 2);
           this.itemQuote.strikePrice = this.itemQuote.ticker.substr(this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":") + 1) + 1) + 1);
           this.sep1 = '|';
           this.sep2 = '|';
         }
 



      }
    }, err => {
      // this.common.hideLoading();
    });
  }

  getCompanyInformation() {
    if (this.item.exchange == "FONSE") {
      this.item.exchange = "NSE"
    };
    if (this.item.exchange == "FOBSE") {
      this.item.exchange = "BSE"
    };
    //---service to get the company information --
    this.marketDepthManager.getCompanyInfo(this.item.exchange, this.item.ticker).then((data) => {
      this.company_result_data = data;
      if (this.company_result_data.ErrorCode == 0) {
        this.GetCompanyInformationData = JSON.parse(this.company_result_data.data);
        console.log("this.GetCompanyInformationData ", this.GetCompanyInformationData)
        if (this.GetCompanyInformationData[0].LowPriceRange != undefined) {
          this.TickSize = this.GetCompanyInformationData[0].TickSize;
          this.DPR = this.GetCompanyInformationData[0].LowPriceRange + "-" + this.GetCompanyInformationData[0].HighPriceRange;
        } else {
          if (this.GetCompanyInformationData[0].TickSize != undefined) {
            this.TickSize = this.GetCompanyInformationData[0].TickSize;
            this.DPR = this.GetCompanyInformationData[0]['LowerCircuit'] + "-" + this.GetCompanyInformationData[0]['UpperCircuit'];
          } else {
            this.TickSize = this.GetCompanyInformationData[0]['Price Tick (in Rs.)'];
            this.DPR = this.GetCompanyInformationData[0]['Lower Circuit'] + "-" + this.GetCompanyInformationData[0]['Upper Circuit'];
          }
        }

        this.headingName = this.GetCompanyInformationData[0].Name;
        if (typeof (this.GetCompanyInformationData[0].Name) == 'undefined') {
          this.headingName = this.GetCompanyInformationData[0].ScripName;
        }
        
        this.dprArry = this.DPR.split("-");
        this.MarketLot = this.GetCompanyInformationData[0].MarketLot;
      }
      // this.getMarketDepthInfo();

    }, err => {

    });
  }
  //----get report for scrip order --
  scripOrdersReports() {
    this.getReportManager.getScripOrderReport(encodeURIComponent(this.item.reconstructedTicker), "PendingOrder", this.clientUserData, "").then((data) => {
      this.scripOrderReport_result = data;
      if (this.scripOrderReport_result.ErrorCode == 0) {
        this.orderitems = JSON.parse(this.scripOrderReport_result.reportTable);
        // console.log("this.orderitems",this.orderitems)
      } else {
        this.orderitems = '';
        this.message = this.scripOrderReport_result.Message
      }
    }, err => {

    });
  }
  //---get reports for the trade order --
  scripTradesReports() {
    this.getReportManager.getScripOrderReport(encodeURIComponent(this.item.reconstructedTicker), "TradeLog", this.clientUserData, "").then((data) => {
      this.tradeOrderReport_result = data;
      if (this.tradeOrderReport_result.ErrorCode == 0) {
        this.tradeitems = JSON.parse(this.tradeOrderReport_result.reportTable);
        //console.log("this.tradeitems",this.tradeitems)
      } else {
        this.message = this.tradeOrderReport_result.Message
        this.tradeitems = [];
        //console.log("this.message",this.message)
      }
    }, err => {

    });
  }
  //---Service for market information of the Script--
  getMarketDepthInfo() {

    this.getReportManager.getMarketDepthReport(encodeURIComponent(this.item.ticker), this.item.exchange).then((data) => {
      this.marketDepth_result = data;
      //---successfully fetched the market depth result --
      try {
        if (this.marketDepth_result.ErrorCode == 0) {
          this.depthdata = JSON.parse(JSON.stringify(JSON.parse(this.marketDepth_result.data)));
        } else {
        
        }
      } catch (err) { }
      //---on successful binding of data from response, create scriplist variable

      this.keylist = 'ADD^2^' + this.GetExchangeCode(this.item.exchange) + '.1!' + this.item.ticker + '^' + this.GetExchangeCode(this.item.exchange) + '.2!' + this.item.ticker;
      setTimeout(_ => {
        this.socket.send(this.keylist.toUpperCase());
        // sessionStorage.setItem('keylist',this.keylist)
      }, 500)

      //---Creating array and pushing in the websocket part for feed regestration --
      this.itemNew.push(this.item)
      this.websocketUtilityManager.getFeedAfterSubscribeMDepth(this.depthdata, this.item).then((data) => {
        this.webSocket_Data = data;
      })

    }, err => {

    });
  }
  //----Function to perfor get specified quote operations --
  GetspecifiedQuoteFunction() {

    this.quoteHeaderManager.getSpecifiedQuoteData(this.item.exchange, this.item.ticker).then((data) => {
      //----Successfully loaded specifiedQuote info ---
      this.specifiedQuote_result = data;
      console.log("this.specifiedQuote_result", this.specifiedQuote_result)
      if (this.specifiedQuote_result.ErrorCode == '0') {
        this.quoteitems = JSON.parse(this.specifiedQuote_result.data);
        // console.log('-*-*-*-*-*-*-*-*-*-*-*-*-', this.items);
        if (this.quoteitems.ExpiryDate == undefined) {
          this.quoteitems.ExpiryDate = this.item.ExpiryDate;
        }
        this.itemQuote = this.quoteitems[0];
        //console.log("this.itemQuote",this.itemQuote)
        try {
          if (this.itemQuote.Close != 0 && this.itemQuote.LTP != '' && this.itemQuote.LTP != 0) {
            this.itemQuote['%Change'] = Number((((this.itemQuote.LTP - this.itemQuote.Close) / this.itemQuote.Close) * 100).toFixed(2));
          } else {
            this.itemQuote['%Change'] = 0.00;
          }
        } catch (err) { }
        // console.log("this.item-->>",this.item);
        //---look for tilde (~), if found, the ticker is F&O. then find if there is more than 1 Colen (:), if found, ticker is Options
        //---use this to identify underlying, expiry, option type and strike price
        var tickertype = 'EQT';
        if (this.itemQuote.ticker.search("~") > 0) {
          tickertype = 'FUT';
          if (this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":") + 1) > 0) {
            tickertype = 'OPT';
          }
          if (this.itemQuote.ticker.search("~S") > 0) {
            tickertype = 'SPD';
          }
        }
        if (tickertype == 'EQT') {
          this.itemQuote.underlying = this.itemQuote.ticker.toUpperCase();
          this.itemQuote.optType = '';
          this.itemQuote.strikePrice = '';
          this.sep1 = '';
          this.sep2 = '';
        }
        if (tickertype == 'FUT') {
          this.itemQuote.underlying = this.itemQuote.ticker.substr(0, this.itemQuote.ticker.search("~")).toUpperCase();
          this.itemQuote.optType = '';
          this.itemQuote.strikePrice = '';
          this.sep1 = '|';
          this.sep2 = '';
        }
        if (tickertype == 'SPD') {
          this.itemQuote.underlying = this.itemQuote.ticker.substr(0, this.itemQuote.ticker.search("~")).toUpperCase();
          this.itemQuote.optType = 'S';
          this.spreadType = this.itemQuote.ticker.substr(this.itemQuote.ticker.indexOf(":") + 1);
          this.itemQuote.strikePrice = this.spreadType.split("~")[0];
          this.sep1 = '|';
          this.sep2 = '|';
        }
        if (tickertype == 'OPT') {
          this.itemQuote.underlying = this.itemQuote.ticker.substr(0, this.itemQuote.ticker.search("~")).toUpperCase();
          this.itemQuote.optType = this.itemQuote.ticker.substr(this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":") + 1) + 1, 2);
          this.itemQuote.strikePrice = this.itemQuote.ticker.substr(this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":", this.itemQuote.ticker.indexOf(":") + 1) + 1) + 1);
          this.sep1 = '|';
          this.sep2 = '|';
        }
      
      } else {

      }
    }, err => {
      // this.common.hideLoading();
      swal({ title: "Error!", text: "Service Not Availabe", timer: 2000, type: 'error', allowOutsideClick: true, showConfirmButton: true });
    });
  }
  /*set exchange code in order to build keylist to register for feed.*/
  GetExchangeCode(Exchange) {
    var strCode = "0";
    switch (Exchange) {
      case "NSE":
      case "FONSE":
        strCode = "4";
        break;
      case "BSE":
      case "FOBSE":
        strCode = "1";
        break;
      case "ACE":
        strCode = "10";
        break;
      case "CDNSE":
        strCode = "13";
        break;
      case "MCX":
        strCode = "7";
        break;
      case "COMNSE":
        strCode = "5";
        break;
      case "NCDEX":
        strCode = "8";
        break;
      case "MCXSX":
        strCode = "14";
        break;
      case "NSEL":
        strCode = "36";
        break;
      case "MCXSXEQ":
        strCode = "64";
        break;
      case "MCXSXFO":
        strCode = "65";
        break;
      case "CDBSE":
        strCode = "17";
        break;
      case "NEPSE":
          strCode = "25";
      break;
    }
    return (strCode);
  }
  //---Service for market Depth of the Script--
  getMarketDepthService() {
    this.getReportManager.getScripSpecifiedReport(this.item.exchange, this.item.ticker).then((data) => {
      this.getSpecifiedReport_result = data;
      if (this.getSpecifiedReport_result.ErrorCode == 0) {
        this.marketInformationData = JSON.parse(this.getSpecifiedReport_result.data);
        if (this.item.LastTradeTime == undefined) {
          this.item.LastTradeTime = this.marketInformationData.LastTradeTime;
        }
        this.date = this.item.LastTradeTime.substr(0, this.item.LastTradeTime.search(" "));
        this.time = this.item.LastTradeTime.substr(10, this.item.LastTradeTime.search(" "));
        //   console.log("toadys date", x);
        if (this.curentDate == this.date) {
          this.date = this.time;
        } else {
          this.date = this.date;
        };
      }

    }, err => {

    });
  }
  //----Intraday Chart Section ---
  loadIntradayChart() {

    this.options = {
      chart: {
        type: 'linePlusBarChart',
        height: 275,
        showLegend: false,
        noData: "No Sufficient Data Available",
        data: "Data is loading...",
        margin: {
          top: 20,
          right: 55,
          bottom: 20,
          left: 55
        },
        bars: {
          forceY: [0]
        },
        bars2: {
          forceY: [0]
        },
        color: ['#1f77b4', '#fff'],
        x: function (d, i) { return i },
        xAxis: {
          axisLabel: '',
          tickFormat: function (d) {

          }
        },
        x2Axis: {
          tickFormat: function (d) {
          },
          showMaxMin: false
        },
        y1Axis: {
          axisLabel: 'Y1 Axis',
          tickFormat: function (d) {
            return d3.format(',f')(d);
          },
          axisLabelDistance: 12
        },
        y2Axis: {
          axisLabel: 'Y2 Axis',
          tickFormat: function (d) {
            return '' + d3.format(',.2f')(d)
          }
        },
        y3Axis: {
          tickFormat: function (d) {
            return d3.format(',f')(d);
          }
        },
        y4Axis: {
          tickFormat: function (d) {
            return '' + d3.format(',.2f')(d)
          }
        }
      }
    }
    //---service to call intraday chart value --
    this.getReportManager.getScripIntradayChartReport(this.item.exchange, encodeURIComponent(this.item.ticker)).then((data) => {
      this.getIntradayChart_result = data;
      if (this.getIntradayChart_result.ErrorCode == 0) {
        this.jsonData = JSON.parse(this.getIntradayChart_result.data);
        //console.log("  this.getIntradayChart_result",  this.jsonData)
        if (this.jsonData.length >= 9) {
          this.DataMessage = "Chart Data Tested : OK";
        } else if (this.jsonData.length = 0) {
          this.jsonData.length = 0;
          //deferred.resolve(jsonData);
        } else {
          this.jsonData.length = 0;
          //deferred.resolve(jsonData)
        }
        var priceData = [],
          volumeData = [];

        this.jsonData.forEach((value, index) => {
          if (value.CurrentPrice == '') {
            value.CurrentPrice = 0
          }
          if (value.TradedQty == '') {
            value.TradedQty = 0
          }
          if (value.TTQ == '') {
            value.TTQ = 0
          }
          if (value.PriceDate == '') {
            value.PriceDate = 0
          }
          var dateToMillis = value.PriceDate,
            date2 = Date.parse(dateToMillis),
            price = JSON.parse(value.CurrentPrice),
            volume = JSON.parse(value.TradedQty),
            volumeDatum = JSON.parse('[' + date2 + ',' + volume + ']'),
            priceDatum = JSON.parse('[' + date2 + ',' + price + ']');
          volumeData.unshift(volumeDatum),
            priceData.unshift(priceDatum);
        });
        volumeData = volumeData.reverse();
        priceData = priceData.reverse();

        this.data = [
          {
            "key": "Quantity",
            "bar": true,
            "values": volumeData
          },
          {
            "key": "Price",
            "bar": false,
            "values": priceData
          }

        ].map(function (series) {
          series.values = series.values.map(function (d) { return { x: d[0], y: d[1] } });
          return series;
        });
        //console.log("data",this.data)
      }
    }, err => {

    })
  }
  //--pull down to refresh --
  doRefresh(refresher) {
    this.ToGetSpecifiedCollumsData();
    setTimeout(() => {
      refresher.complete();
    }, 1500);
  }
  //---buy page--
  buyItem() {
    //--Apply the logic of valid trade password for login --
    // this.socket.send('DELETE^*')
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: this.itemToBuySell });
    this.navCtrl.push('BuyPage', { userbuyData: this.itemToBuySell, clientUserData: this.clientUserData });
  }
  //---sell page--
  sellItem() {
    // this.socket.send('DELETE^*')
    //--Apply the logic of valid trade password for login --
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: this.itemToBuySell });
    this.navCtrl.push('SellPage', { usersellData: this.itemToBuySell, clientUserData: this.clientUserData });
  }




  getAlertData() {
    this.showAlertContainer = false;
    var altData;
    var ticker = '';
    if (this.item.ticker.indexOf('~') > -1) {
      ticker = this.item.ticker.split('~')[0];
    } else if ((this.item.exchange == 'MCX') || (this.item.exchange == 'NCDEX') || (this.item.exchange == 'CDNSE') || (this.item.exchange == 'CDBSE')) {
      ticker = this.item.ticker.split('~')[0];
    } else {
      ticker = this.item.ticker;
    }

    var ticData = this.GetExchangeCode(this.item.exchange) + '.1!' + ticker;
    this.marketDepthManager.getAlertShowData(this.clientUserData.ClientCode, ticData).then((data: any) => {
      this.quote_result_data = data;
      // console.log('Response--------> '+JSON.stringify(data));
      altData = JSON.parse(data.data);
      if (this.quote_result_data.ErrorCode == 0) {
        this.alertDataObj = altData;
        // console.log(this.alertDataObj);
      }
    }, err => {
      // this.common.hideLoading();
    });
  }




  public add(scripName) {
    this.showAlertContainer = !this.showAlertContainer;

    // if(this.item.exchange.indexOf('~') > -1){
    //   this.scriptname = this.item.ticker.split('~')[0];
    // }
    if ((this.item.exchange == 'MCX') || (this.item.exchange == 'NCDEX') || (this.item.exchange == 'CDNSE') || (this.item.exchange == 'CDBSE')) {
      this.scriptname = this.item.ticker.split('~')[0];
    }
    this.scriptname = this.GetExchangeCode(this.item.exchange) + '.1!' + scripName;
    // console.log(scripName);
  }

  //  --------------------------Save  data For alert Show

  public submit(AlertObject) {


    if (this.AlertObject.ColumnList == "" || this.AlertObject.ColumnList == undefined) {
      swal({
        title: 'Alert',
        text: 'Plz Select Column List',
        type: "warning"
      });
      return;
    }
    if (this.altValue == "" || this.altValue == undefined) {
      swal({
        title: 'Alert',
        text: 'Required Alert Value ',
        type: "warning"
      });
      return;
    }
    if (this.AlertObject.AlertName == "" || this.AlertObject.AlertName == undefined) {
      swal({
        title: 'Alert',
        text: 'Required Alert Name',
        type: "warning"
      });
      return;
    } if (this.altNotification == "" || this.altNotification == undefined) {
      swal({
        title: 'Alert',
        text: 'Plz Select Alert Notification',
        type: "warning"
      });
      return;
    }
    if (this.AlertObject.Remark == "" || this.AlertObject.Remark == undefined) {
      swal({
        title: 'Alert',
        text: 'Plz Select Alert Remark',
        type: "warning"
      });
      return;
    }

    var emailNotif = 0;
    var smsNotif = 0;
    var pushNotif = 0;
    var applicationNotif = 0;

    var altValue = this.altValue;
    var columnList = this.AlertObject.ColumnList;
    var altExp = this.AlertObject.AlertExpression;
    var altExpretion = columnList + '' + altExp + '' + altValue;

    var notification = this.altNotification;
    var lenth = notification.length;
    for (var k = 0; k < lenth; k++) {
      if (notification[k] == 'SMS') { smsNotif = 1; }
      if (notification[k] == 'Push') { pushNotif = 1; }
      if (notification[k] == 'E-Mail') { emailNotif = 1; }
      if (notification[k] == 'Application') { applicationNotif = 1; }
    }
    // console.log(emailNotif,smsNotif,pushNotif,altExpretion);

    this.AlertObject = {
      "AlertId": this.aleartId,
      "ClientCode": this.clientUserData.ClientCode,
      "AlertName": this.AlertObject.AlertName,
      "Ticker": this.scriptname,
      "AlertExpression": altExpretion,
      "ColumnList": this.AlertObject.ColumnList,
      "EmailNotification": emailNotif + "",
      "SMSNotification": smsNotif + "",
      "PushNotification": pushNotif + "",
      "ApplicationNotification": applicationNotif + "",
      "Status": this.AlertObject.Status,
      "Remark": this.AlertObject.Remark
    };

    this.commonService.showLoading();
    this.marketDepthManager.saveAlertShowData(JSON.stringify(this.AlertObject)).then((data: any) => {
      this.quote_result_data = data;
      this.commonService.hideLoading();
      // console.log('Response--------> '+JSON.stringify(this.AlertObject));
      if (this.quote_result_data.ErrorCode == 0) {
        swal({
          title: 'Success',
          text: this.quote_result_data.Message,
          type: "success",
          timer: 3000
        });
        this.getAlertData();
      }
    }, err => {
      this.commonService.hideLoading();
      this.getAlertData();
    });

  }


  //  --------------------------Bind data for modify record

  public modifyRecord(obj, scripName) {
    this.disableName = false
    // console.log(obj);
    // this.scriptname = scripName;
    this.scriptname = this.GetExchangeCode(this.item.exchange) + '.1!' + scripName;

    this.aleartId = obj.AlertId;

    this.showAlertContainer = !this.showAlertContainer;
    this.altNotification = [];
    if (obj.SMSNotification == 'True') { this.altNotification.push('SMS') }
    if (obj.PushNotification == 'True') { this.altNotification.push('Push') }
    if (obj.EmailNotification == 'True') { this.altNotification.push('E-Mail') }
    if (obj.ApplicationNotification == 'True') { this.altNotification.push('Application') }

    var res;
    var checkIndx;
    var checkIndx1;
    var checkIndx2;
    var checkIndx3;
    var checkIndx4;
    checkIndx = (obj.AlertExpression.indexOf('=') > -1);
    if (checkIndx) {

      checkIndx1 = (obj.AlertExpression.indexOf('>=') > -1);
      checkIndx2 = (obj.AlertExpression.indexOf('<=') > -1);

      if (checkIndx1) {
        res = obj.AlertExpression.split(">=");

        this.AlertObject.AlertExpression = '>=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
        // console.log(res)

      } else if (checkIndx2) {
        res = obj.AlertExpression.split("<=");
        this.AlertObject.AlertExpression = '<=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];

        // console.log(res)
      } else {
        res = obj.AlertExpression.split("=");
        this.AlertObject.AlertExpression = '=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];

      }
    }



    checkIndx3 = (obj.AlertExpression.indexOf('>') > -1);
    if (checkIndx3) {

      checkIndx1 = (obj.AlertExpression.indexOf('>=') > -1);
      if (checkIndx1) {
        res = obj.AlertExpression.split(">=");

        this.AlertObject.AlertExpression = '>=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
        // console.log(res)

      } else {
        // res = obj.AlertExpression.split("<=");
        res = obj.AlertExpression.split(">");
        this.AlertObject.AlertExpression = '>';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
        // console.log(res)
      }
    }

    checkIndx4 = (obj.AlertExpression.indexOf('<') > -1);
    if (checkIndx4) {

      checkIndx2 = (obj.AlertExpression.indexOf('<=') > -1);
      if (checkIndx2) {
        res = obj.AlertExpression.split("<=");
        this.AlertObject.AlertExpression = '<=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
      } else {
        res = obj.AlertExpression.split("<");
        this.AlertObject.AlertExpression = '<';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
      }


    }




    var emailNotif = 0;
    var smsNotif = 0;
    var pushNotif = 0;
    var applicationNotif = 0;

    var altValue = this.altValue;
    var columnList = this.AlertObject.ColumnList;
    var altExp = this.AlertObject.AlertExpression;
    var altExpretion = columnList + '' + altExp + '' + altValue;

    var notification = this.altNotification;
    var lenth = notification.length;
    for (var k = 0; k < lenth; k++) {
      if (notification[k] == 'SMS') { smsNotif = 1; }
      if (notification[k] == 'Push') { pushNotif = 1; }
      if (notification[k] == 'E-Mail') { emailNotif = 1; }
      if (notification[k] == 'Application') { applicationNotif = 1; }
    }

    this.AlertObject.AlertName = obj.AlertName;
    //  this.AlertObject.Status = obj.Status;
    if (obj.Status == 'True') { this.AlertObject.Status = '1' } else { this.AlertObject.Status = '0' }

    if (obj.Remarks != undefined || obj.Remarks != '') {
      this.AlertObject.Remark = obj.Remarks;
    }


    this.AlertObject = {
      "AlertId": this.aleartId,
      "ClientCode": this.clientUserData.ClientCode,
      "AlertName": this.AlertObject.AlertName,
      "Ticker": this.scriptname,
      "AlertExpression": this.AlertObject.AlertExpression,
      "ColumnList": this.AlertObject.ColumnList,
      "EmailNotification": emailNotif,
      "SMSNotification": smsNotif,
      "PushNotification": pushNotif,
      "ApplicationNotification": applicationNotif,
      "Status": this.AlertObject.Status,
      "Remark": this.AlertObject.Remark
    };
  }


  //  --------------------------Change status for Active Inactive


  public statusChange(obj, scripName, status) {

    // this.scriptname = scripName;
    this.scriptname = this.GetExchangeCode(this.item.exchange) + '.1!' + scripName;
    this.aleartId = obj.AlertId;


    // this.showAlertContainer = !this.showAlertContainer;
    this.altNotification = [];
    if (obj.SMSNotification == 'True') { this.altNotification.push('SMS') }
    if (obj.PushNotification == 'True') { this.altNotification.push('Push') }
    if (obj.EmailNotification == 'True') { this.altNotification.push('E-Mail') }
    if (obj.ApplicationNotification == 'True') { this.altNotification.push('Application') }

    var res;
    var checkIndx;
    var checkIndx1;
    var checkIndx2;
    var checkIndx3;
    var checkIndx4;

    checkIndx = (obj.AlertExpression.indexOf('=') > -1);
    if (checkIndx) {

      checkIndx1 = (obj.AlertExpression.indexOf('>=') > -1);
      checkIndx2 = (obj.AlertExpression.indexOf('<=') > -1);

      if (checkIndx1) {
        res = obj.AlertExpression.split(">=");

        this.AlertObject.AlertExpression = '>=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
        // console.log(res)

      } else if (checkIndx2) {
        res = obj.AlertExpression.split("<=");
        this.AlertObject.AlertExpression = '<=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];

        // console.log(res)
      } else {
        res = obj.AlertExpression.split("=");
        this.AlertObject.AlertExpression = '=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];

      }
    }



    checkIndx3 = (obj.AlertExpression.indexOf('>') > -1);
    if (checkIndx3) {

      checkIndx1 = (obj.AlertExpression.indexOf('>=') > -1);
      if (checkIndx1) {
        res = obj.AlertExpression.split(">=");
        this.AlertObject.AlertExpression = '>=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
        // console.log(res)

      } else {
        res = obj.AlertExpression.split("<=");
        res = obj.AlertExpression.split(">");
        this.AlertObject.AlertExpression = '>';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
        // console.log(res)
      }
    }

    checkIndx4 = (obj.AlertExpression.indexOf('<') > -1);
    if (checkIndx4) {

      checkIndx2 = (obj.AlertExpression.indexOf('<=') > -1);
      if (checkIndx2) {
        res = obj.AlertExpression.split("<=");
        this.AlertObject.AlertExpression = '<=';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
      } else {
        res = obj.AlertExpression.split("<");
        this.AlertObject.AlertExpression = '<';
        this.AlertObject.ColumnList = res[0];
        this.altValue = res[1];
      }
    }


    var emailNotif = 0;
    var smsNotif = 0;
    var pushNotif = 0;
    var applicationNotif = 0;

    var altValue = this.altValue;
    var columnList = this.AlertObject.ColumnList;
    var altExp = this.AlertObject.AlertExpression;
    var altExpretion = columnList + '' + altExp + '' + altValue;

    var notification = this.altNotification;
    var lenth = notification.length;
    for (var k = 0; k < lenth; k++) {
      if (notification[k] == 'SMS') { smsNotif = 1; }
      if (notification[k] == 'Push') { pushNotif = 1; }
      if (notification[k] == 'E-Mail') { emailNotif = 1; }
      if (notification[k] == 'Application') { applicationNotif = 1; }
    }

    this.AlertObject.AlertName = obj.AlertName;
    this.AlertObject.Status = obj.Status;
    if (obj.Remarks != undefined || obj.Remarks != '') {
      this.AlertObject.Remark = obj.Remarks;
    } else {
      this.AlertObject.Remark = 'blue';
    }

    this.AlertObject = {
      "AlertId": this.aleartId,
      "ClientCode": this.clientUserData.ClientCode,
      "AlertName": this.AlertObject.AlertName,
      "Ticker": this.scriptname,
      "AlertExpression": altExpretion,
      "ColumnList": this.AlertObject.ColumnList,
      "EmailNotification": emailNotif + "",
      "SMSNotification": smsNotif + "",
      "PushNotification": pushNotif + "",
      "ApplicationNotification": applicationNotif + "",
      "Status": status,
      "Remark": this.AlertObject.Remark
    };

    this.commonService.showLoading();
    this.marketDepthManager.deleteAlertShowData(JSON.stringify(this.AlertObject)).then((data: any) => {
      this.quote_result_data = data;
      this.commonService.hideLoading();
      // console.log('Active Inactive Response--------> ' + JSON.stringify(this.AlertObject));
      this.getAlertData();
    }, err => {
      this.commonService.hideLoading();
      this.getAlertData();
    });
  }

  change(value) {
    if (value.length > 10) {
      return true;
    } else {
      return false;
    }

  }


  isMaxKey() {
    try {
      if (this.AlertObject.AlertName.length > 15) {
        this.AlertObject.AlertName = this.AlertObject.AlertName.substring(0, this.AlertObject.AlertName.length - 1);
        swal({
          title: "Info!",
          text: "Alert name should be max 15 character",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
        });

        return true
      }
      
      this.changeDetectorRef.detectChanges();
      // return true;
    } catch (w) {
      // alert(w);
    }
  }


  onSlideDidChange() {
    let currentIndex = this.slides.getActiveIndex();
    console.log('Current index is', currentIndex);
    if (currentIndex == 0) {
      this.tabsSection = 'marketDepth';
    }
    else if (currentIndex == 1) {
      this.tabsSection = 'companyInfo';
    }
    else if (currentIndex == 2) {
      this.tabsSection = 'orderBook';
      this.scripOrdersReports()
    } else if (currentIndex == 3) {
      this.tabsSection = 'netPosition';
      this.scripTradesReports()
    } else if (currentIndex == 4) {
      this.tabsSection = 'alertShow';
      this.getAlertData();
    } else if (currentIndex == 5) {
      this.tabsSection = 'future';
      this.getLongTermExpiryCode('future')
    } else if (currentIndex == 6) {
      this.tabsSection = 'option';
      this.getLongTermExpiryCode('option')
    } else {
      this.tabsSection = 'marketDepth';
    }
  }


  segmentChanged(value) {
    console.log(value._value)
    if (value._value == 'marketDepth') {
      this.slides.slideTo(0)
    }
    else if (value._value == 'companyInfo') {
      this.slides.slideTo(1)
    }
    else if (value._value == 'orderBook') {
      this.slides.slideTo(2)
    } else if (value._value == 'netPosition') {
      this.slides.slideTo(3)
    } else if (value._value == 'alertShow') {
      this.slides.slideTo(4)
    } else if (value._value == 'future') {
      this.slides.slideTo(5)
      // this.getLongTermExpiryCode('future')

    } else if (value._value == 'option') {
      this.slides.slideTo(6)
    } else {
      this.slides.slideTo(1)
    }
  }


  getLongTermExpiryCode(key) {
    // this.prepareNiftyUnderlying()
    
    var instructionType = ''
    //  this.getDate = [];

    if (key == 'future' && this.item.isIndex != 'True') {
      instructionType = 'FUTSTK'
    } else if (key == 'option' && this.item.isIndex != 'True') {
      instructionType = 'OPTSTK'
    } else if (key == 'future' && this.item.isIndex != 'False') {
      instructionType = 'OPTIDX'
    } else if (key == 'option' && this.item.isIndex != 'False') {
      instructionType = 'OPTIDX'
    }

    if ((key == 'future') || (key == 'option')) {
      if (this.item.ticker.indexOf('EQ') > 0) {
        this.newTicker = this.item.ticker.split("EQ")[0];
      } else {
        this.newTicker = this.item.ticker;
      }
    }
    this.commonService.showLoading();
    let symbol= this.item.ticker.indexOf('EQ') > 0 ? this.newTicker : this.item.underlying;
    instructionType = this.item.Instrument ? this.item.Instrument : instructionType;
    
    let tradingSymbol = this.getTradingTicker(symbol)

    this.marketDepthManager.getLongTermExpiry(this.item.exchange, instructionType,tradingSymbol).then((data: any) => {
      this.longTermExpiryData = data;
      this.commonService.hideLoading();
      console.log('Response longTermExpiryData--------> ', data);
      if (this.longTermExpiryData.ErrorCode == 0) {
        //  var expData = JSON.stringify(this.longTermExpiryData.data)
        var expData = JSON.parse(this.longTermExpiryData.data)
        this.optionData = expData;
        // console.log('Response longTermExpiryData--------> ',expData);
        if (expData != null && expData != undefined) {
          this.generateNewTicker(expData)
        } else {
          this.expiryMsg = true
        }


      }
    }, err => {
      this.commonService.hideLoading();
      // this.getAlertData();
    });
  }

  generateNewTicker(expData) {
    var exchangeSymbol = '';
    var newTicker_Code = [];
    // this.newTickerCode = [];
    // this.getDate = [];
    if (this.tabsSection == 'future') {
      exchangeSymbol = '~F:';
    } else {
      exchangeSymbol = '~O:';
    }
    this.optionValue.date = expData[0]['ExpKey'];

    expData.forEach((o, index) => {
      var lastCode = o.ExpKey;

      this.tkr = this.newTicker.split('~')[0] + '' + exchangeSymbol + '' + lastCode;

      //  newTicker_Code.push(tkr)
      this.GetspecifiedQuoteFunction2()
    });
    
    if (this.tabsSection == 'option') {
      setTimeout(() => {
        this.getStrikePricesData();
      }, 1000);
    }

  }


  GetspecifiedQuoteFunction2() {
    // this.item.ticker
    this.quoteHeaderManager.getSpecifiedQuoteData(this.item.exchange, this.tkr).then((data: any) => {
      this.dpthData = data.data;
      // var getDate = [];
      this.dpthData = JSON.parse(this.dpthData)
      console.log("this.newTickerCode future***********", this.dpthData)

      this.dpthData[0]['%Change'] = Number((((this.dpthData[0].LTP - this.dpthData[0].Close) / this.dpthData[0].Close) * 100).toFixed(2));
      if(isNaN(this.dpthData[0]['%Change'])){
        this.dpthData[0]['%Change'] = 0
      }
      if ((this.newTickerCode.length < 3) && (this.dpthData[0].ExpiryDate != '') && (this.dpthData[0].ExpiryDate != undefined)) {
        this.newTickerCode.push(this.dpthData[0]);
        this.getDate.push(this.dpthData[0].ExpiryDate);
      }
    });
    setTimeout(_ => {


      console.log("getDate", this.getDate, ">>>>>>>>>>>>>>>>>>>>>>..", this.newTickerCode);
    }, 5000)
  }


  public changeValue(v) {
    console.log(v);
    if (this.optionValue.callPut != undefined && this.optionValue.callPut != undefined) {
      this.getStrikePricesData();
    }
  }



  getStrikePricesData() {
    // var tkr = '';
    if (this.tabsSection == 'option') {

      this.tkr = this.tkr.split("~")[0];
    }
    if (this.optionValue.callPut == '' || this.optionValue.callPut == undefined) {
      swal({
        title: "Info!",
        text: "Plz select Option Call/Put!",
        timer: 1500,
      });
    } else if (this.optionValue.date == '' || this.optionValue.date == undefined) {
      swal({
        title: "Info!",
        text: "Plz select expiry date!",
        timer: 1500,
      });
    }
    this.optionValue.date = this.optionValue.date;
    var month = '';
    month = this.optionValue.date[0];
    var typ = '';
    this.optionValue.callPut = this.optionValue.callPut;
    let tradingTicker = this.getTradingTicker(this.item.underlying)
    this.quoteHeaderManager.getStrikePricesData(this.item.exchange, month, tradingTicker, this.optionValue.callPut).then((data: any) => {

      if (data.ErrorCode == 0) {
        this.strikPrizeData = data.data;

        this.strikPrizeData = JSON.parse(this.strikPrizeData);
        console.log("getDate -----> ", this.strikPrizeData);
        this.GetspecifiedQuoteBySelectOption(this.item.underlying)
      }
    });
  }


  GetspecifiedQuoteBySelectOption(tkr_v) {

    if(tkr_v.toUpperCase().endsWith('EQ'))
      tkr_v= tkr_v.slice(0,-2)
    
    var tkr = [];
    this.optionListData = [];
    for (var k = 0; k < this.strikPrizeData.length; k++) {
      tkr.push(this.item.exchange + '.' + tkr_v + '~O:' + this.optionValue.date + ':' + this.optionValue.callPut + ':' + this.strikPrizeData[k]);
    }
    let tkr_value = tkr.toString();
    // console.log("getDate    tkr------>",tkr_value);
    this.quoteHeaderManager.getSpecifiedQuoteForOption(this.item.exchange, tkr_value).then((data: any) => {
      let dpthData = data.data;
      // var getDate = [];

      if (data.ErrorCode == 0) {
        dpthData = JSON.parse(dpthData)
        console.log("optionListData ------>", dpthData);
        for (var i = 0; i < dpthData.length; i++) {
          let p_change = Number((((dpthData[i].LTP - dpthData[i].Close) / dpthData[i].Close) * 100).toFixed(2));
          dpthData[i]['%Change'] = isNaN(p_change) ? 0 : p_change;
          this.optionListData.push(dpthData[i]);
        }

        console.log("optionListData ------>", this.optionListData);
      } else {

      }
    });

  }

  buyItem_o(buyObj) {
    //--Apply the logic of valid trade password for login --
    //--console.log("buyObj",buyObj)
    this.clientMarketWatchList.setclosingMWatch(true);
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: buyObj });
    this.navCtrl.push('BuyPage', { userbuyData: buyObj, clientUserData: this.userData });
  }
  //---open sell page --
  sellItem_o(sellObj) {
    //--Apply the logic of valid trade password for login --
    this.clientMarketWatchList.setclosingMWatch(true);
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: sellObj });
    this.navCtrl.push('SellPage', { usersellData: sellObj, clientUserData: this.userData });
  }

  openBuySell(index) {
    this.show_buy_sell = index;
  }

  openBuySellFuture(index) {
    this.show_buy_sell_future = index;
  }

  refreshZone() {
    this.Interval_obj = setInterval(() => {

      this.ngZone.run(_ => {
        console.log("Refresh me after 10 second")
      })

    }, 10000);
  }

  ionViewWillLeave() {
    this.socket.send('DELETE^*')
    clearInterval(this.Interval_obj)
  }




  moreOptionsOrder(item) {
    let alert = this.alertCtrl.create();
    alert.setTitle('Action');

    alert.addInput({
      type: 'radio',
      label: 'Modify Order',
      value: 'modifyOrder',
      disabled: (item.OrderStatus=='ACCEPTED') || (item.OrderStatus=='AMO')?false:true,
    });
    
    alert.addInput({
      type: 'radio',
      label: 'Cancel Order',
      value: 'cancelOrder',
      disabled:(item.OrderStatus=='ACCEPTED') || (item.OrderStatus=='AMO')?false:true
    });

    alert.addButton('Dismiss');
    alert.addButton({
      text: 'OK',
      handler: data => {
      if(data=='modifyOrder')
      {
        this.modifyOrder(item)
      }
      else if(data=='cancelOrder')
      {
        this.cancelOrder(item)
      }
      else{
      //  alert.dismiss()
      }
    }
    });
    alert.present();
  }
  
  modifyOrder(item){
    item.ticker=item.Scrip;
    item.exchange=item.Exchange;
    if (item['B/S'] == "B") {
      this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: item });
      this.navCtrl.push('BuyPage',{userbuyData:item,clientUserData:this.userData,ismodify:true});
    } else {
      this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: item });
      this.navCtrl.push('SellPage',{usersellData:item,clientUserData:this.userData,ismodify:true});
    }
  }
  cancelOrder(item){
    item.exchange=item.Exchange;
    item.ticker=item.Scrip;

    this.cancelOrderObject = {
        SessionNo: this.userData.SessionNo,
        ClientCode:this.userData.ClientCode,
        OrderPlacedBy:this.userData.ClientCode,
        Source: "5",
        TradingAccount: item.TradingAccount,
        Exchange: item.exchange,
        Scrip: item.Scrip,
        Quantity: item.RemainingQty,
        Price: item.Price,
        Market: item.MarketOrder,
        OrderTerms: item.OrderTerms,
        BuySellIndicator: item['B/S'],
        BuySellType: item.BuySellType,
        TriggerPrice: item.TriggerPrice,
        DeliveryTerms: item.DeliveryTerms,
        MarketSegment: item.MarketSegment,
        DeliveryFlag: item.TradeType,
        OrderCategory: "NORMAL",
        OrderType: "NORMAL",
        AccrefCode: item.AccRefCode,
        TermValidity: item.TermValidity,
        DisclosedQuantity: item.DisclosedQuantity,
        OrderID: item.BrokerTranID,
        Remarks: 'Cancelled from Mobile App',
        TranID: item.LatestOrderID,
        AMOBulkIndicator: '',
        Status: item.OrderStatus,
        AddModifyFlag:'2'
    };
    if (item.OrderStatus === "AMO") {
        this.cancelOrderObject.AMOBulkIndicator = 'AMO';
    }
    //---build Cancel order querystring
    var CancelOrderqString = '{';
    CancelOrderqString += '"SessionNo":"' + this.cancelOrderObject.SessionNo + '",';
    CancelOrderqString += '"ClientCode":"' + this.cancelOrderObject.ClientCode + '",';
    CancelOrderqString += '"OrderPlacedBy":"' + this.cancelOrderObject.OrderPlacedBy + '",';
    CancelOrderqString += '"Source":"' + this.cancelOrderObject.Source + '",';
    CancelOrderqString += '"TradingAccount":"' + this.cancelOrderObject.TradingAccount + '",';
    CancelOrderqString += '"Exchange":"' + this.cancelOrderObject.Exchange + '",';
    CancelOrderqString += '"Scrip":"' + encodeURIComponent(this.cancelOrderObject.Scrip) + '",';
    CancelOrderqString += '"Quantity":"' + this.cancelOrderObject.Quantity + '",';
    CancelOrderqString += '"Price":"' + this.cancelOrderObject.Price + '",';
    CancelOrderqString += '"Market":"' + this.cancelOrderObject.Market + '",';
    CancelOrderqString += '"OrderTerms":"' + this.cancelOrderObject.OrderTerms + '",';
    CancelOrderqString += '"BuySellIndicator":"' + this.cancelOrderObject.BuySellIndicator + '",';
    CancelOrderqString += '"BuySellType":"' + this.cancelOrderObject.BuySellType + '",';
    CancelOrderqString += '"TriggerPrice":"' + this.cancelOrderObject.TriggerPrice + '",';
    CancelOrderqString += '"DeliveryTerms":"' + this.cancelOrderObject.DeliveryTerms + '",';
    CancelOrderqString += '"MarketSegment":"' + this.cancelOrderObject.MarketSegment + '",';
    CancelOrderqString += '"DeliveryFlag":"' + this.cancelOrderObject.DeliveryFlag + '",';
    CancelOrderqString += '"OrderCategory":"' + this.cancelOrderObject.OrderCategory + '",';
    CancelOrderqString += '"OrderType":"' + this.cancelOrderObject.OrderType + '",';
    CancelOrderqString += '"AccrefCode":"' + this.cancelOrderObject.AccrefCode + '",';
    CancelOrderqString += '"TermValidity":"' + this.cancelOrderObject.TermValidity + '",';
    CancelOrderqString += '"DisclosedQuantity":"' + this.cancelOrderObject.DisclosedQuantity + '",';
    CancelOrderqString += '"OrderID":"' + this.cancelOrderObject.OrderID + '",';
    CancelOrderqString += '"TranID":"' + this.cancelOrderObject.TranID + '",';
    CancelOrderqString += '"AMOBulkIndicator":"' + this.cancelOrderObject.AMOBulkIndicator + '",';
    CancelOrderqString += '"AddModifyFlag":"' + this.cancelOrderObject.AddModifyFlag + '",';

    if (this.cancelOrderObject.Status.toUpperCase() == 'INPROCESS') {
        CancelOrderqString += '"OREOrderID ":"' + this.cancelOrderObject.TranID + '",';
        // this.inProcessOrder=true;
        //CancelOrderService = configService.CancelInProcessOrder;
    }
    CancelOrderqString += '"Remarks":"' + this.cancelOrderObject.Remarks + '"}';

    var alerttext = ''; {
        alerttext = "You are cancelling an order <br>" +
            item.Scrip + " - " + item.RemainingQty + " Qty " + "<br>" +
            "Product - " + item.TradingAccount + "<br>" +
            "OrderID - " + item.LatestOrderID + "<br>"
    }
    swal({
      title: 'Cancel Order?',
      html: alerttext,
      type: 'info',
      showCancelButton: true,
      cancelButtonText: "No, let it be !",
      confirmButtonColor: "#387ef5",
      confirmButtonText: "Yes, Cancel order!"
      }).then((result) => {
      if (result.value) {
          //---User want to Cancel Place order--
          // this.cancelBtnFlg = true;
           
          this.buySellManager.cancelOrder(CancelOrderqString,null).then((data)=>{
            let cancel_order_result:any = data;
            if(cancel_order_result.ErrorCode == '0'){
              // closeSlide.close()
              this.scripOrdersReports()
              swal({
                  title: "Cancellation Status",
                  text: JSON.stringify(cancel_order_result.Message),
                  showCancelButton: true,
                  showConfirmButton: false,
                  cancelButtonText: "Close"
              }).then((result) => {
                  if (result.value) {
                    swal({
                        title: "Redirecting",
                        text: "loading order details",
                        type: "success",
                        showConfirmButton: false,
                        timer: 350
                    });
                    //---Code to redirect to order Detail page goes here --
                    this.navCtrl.push('OrderBookPage');
                  }
              })
              
            }else{
              swal({
                  title: "Cancellation Status",
                  text: JSON.stringify(cancel_order_result.Message),
                  type: "info",
                  showCancelButton: true,
                  cancelButtonText: "Close",
                  confirmButtonColor: "#387ef5",
                  confirmButtonText: "Order Detail"
              }).then(_=>{
                
              })
            }

          }, err=> {});
          
          // this.cancelBtnFlg = false;  
        }
      })
  }

  openMoreDropDown(currentIndex)
  {
    for(let i=0;i<this.orderitems.length;i++)
    this.orderitems[i].isOpen=i!=currentIndex?false:this.orderitems[i].isOpen;
    this.orderitems[currentIndex].isOpen=this.orderitems[currentIndex].isOpen?false:true
  }

  numDifferentiation(val) {
    if(val >= 10000000) val = (val/10000000).toFixed(2) + ' Cr';
    else if(val >= 100000) val = (val/100000).toFixed(2) + ' Lac';
    else if(val >= 1000) val = (val/1000).toFixed(2) + ' K';
    else val=val
    return val;
}


public shownGroup : any = false;

toggleGroup (group) {
  if (this.isGroupShown(group)) {
      this.shownGroup = null;
  } else {
      this.shownGroup = group;
  }
}
isGroupShown(group) {
  return this.shownGroup === group;
}





public getTradingTicker(val){

  let retVal= val

  if (val) {
    switch (val) {
      case "NIFTY 50":
        retVal = "Nifty";
        break;
      case "NIFTY BANK":
        retVal = "BANKNIFTY";
        break;
      case "NIFTY IT":
        retVal = "NiftyIT";
        break;
      case "NIFTY MIDCAP 50":
        retVal = "NIFTYMID50";
        break;
      case "NIFTY PSE":
        retVal = "NIFTYPSE";
        break;
      case "NIFTY INFRA":
        retVal = "NIFTYINFRA";
        break;
    }
  }
  return retVal

}














  ngAfterViewInit() {
    if(this.options.handleHeight){
      this.handleHeight = this.options.handleHeight;
    }
    if(this.options.bounceBack){
      this.bounceBack = this.options.bounceBack;
    }
    if(this.options.thresholdFromBottom){
      this.thresholdBottom = this.options.thresholdFromBottom;
    }
    if(this.options.thresholdFromTop){
      this.thresholdTop = this.options.thresholdFromTop;
    }
    this.renderer.setElementStyle(this.element.nativeElement, 'top', (this.platform.height() - 100) - this.handleHeight + 'px');
    this.renderer.setElementStyle(this.element.nativeElement, 'padding-top', this.handleHeight + 'px');
    let hammer = new window['Hammer'](this.element.nativeElement);
    hammer.get('pan').set({ direction: window['Hammer'].DIRECTION_VERTICAL });
    hammer.on('pan', (ev) => {
      this.handlePan(ev);
    });
  }
  handlePan(ev){
    let newTop = ev.center.y;
    let bounceToBottom = false;
    let bounceToTop = false;
    if(this.bounceBack && ev.isFinal){
      let topDiff = newTop - this.thresholdTop;
      let bottomDiff = (this.platform.height() - this.thresholdBottom) - newTop;
      topDiff >= bottomDiff ? bounceToBottom = true : bounceToTop = true;
    }
    if((newTop < this.thresholdTop && ev.additionalEvent === "panup") || bounceToTop){
      this.domCtrl.write(() => {
        this.renderer.setElementStyle(this.element.nativeElement, 'transition', 'top 0.5s');
        this.renderer.setElementStyle(this.element.nativeElement, 'top', '0px');
      });
    } else if(((this.platform.height() - newTop) < this.thresholdBottom && ev.additionalEvent === "pandown") || bounceToBottom){
      this.domCtrl.write(() => {
        this.renderer.setElementStyle(this.element.nativeElement, 'transition', 'top 0.5s');
        this.renderer.setElementStyle(this.element.nativeElement - 100, 'top', this.platform.height() - this.handleHeight + 'px');
      });
    } else {
      this.renderer.setElementStyle(this.element.nativeElement, 'transition', 'none');
      if(newTop > 0 && newTop < (this.platform.height() - this.handleHeight)) {
        if(ev.additionalEvent === "panup" || ev.additionalEvent === "pandown"){
          this.domCtrl.write(() => {
            this.renderer.setElementStyle(this.element.nativeElement, 'top', newTop + 'px');
          });
        }
      }
    }
  }


}
