import { ElementRef, Input, NgModule, Renderer } from '@angular/core';
import { ProgressBarComponent } from './progress-bar/progress-bar';
import { CommonModule } from '@angular/common';
import { TvChartContainerComponent } from './tv-chart-container/tv-chart-container.component';

@NgModule({
	declarations: [ProgressBarComponent,TvChartContainerComponent],
	imports: [CommonModule],
	exports: [ProgressBarComponent,TvChartContainerComponent]
})
export class ComponentsModule {
  
}
