import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http'; // for HTTP request
import { HttpClientModule,HttpClientJsonpModule } from '@angular/common/http';
import {JsonpModule} from '@angular/http';
import { MyApp } from './app.component';
//import { HomePage } from '../pages/Dion/home/home';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

//---Services import sction--
import { RequestManagerProvider } from '../providers/request-manager/request-manager';
import { UserManagerProvider } from '../providers/user-manager/user-manager';
import { CommonProvider } from '../providers/common/common';
import { MarketWatchProvider } from '../providers/market-watch/market-watch';
import { AddScripProvider } from '../providers/add-scrip/add-scrip';
import { ExchangeInformationProvider } from '../providers/exchange-information/exchange-information';
import { WebsocketProvider } from '../providers/websocket/websocket';
import { QuoteHeaderProvider } from '../providers/quote-header/quote-header';
import { MarketDepthProvider } from '../providers/market-depth/market-depth';
import { ReportProvider } from '../providers/report/report';
import { BuySellProvider } from '../providers/buy-sell/buy-sell';
import { ConvertProvider } from '../providers/convert/convert';
import { MarketMoversProvider } from '../providers/market-movers/market-movers';
import { FundManagementProvider } from '../providers/fund-management/fund-management';
import { AppUpdateProvider } from '../providers/app-update/app-update';

//--Plugin import and declaration--
import { Network } from '@ionic-native/network';
import { IonicStorageModule } from '@ionic/storage';

//--Global Client declaration service --
import { GlobalVariableService } from '../providers/common/global-variable';
import { GlobalConfigService } from '../providers/common/configService';

//---web socket utility service --
import { WebsocketUtilityService } from '../util/webSocketUtility';

//---charts module --
import { NvD3Module } from 'ng2-nvd3';

//--Gauze module for dashboard page --\
//import { GaugeModule } from 'angular-gauge';

//---Ng module for the keep alive and session time out functionality in case of users inactivity..
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'; // this includes the core NgIdleModule but includes keepalive providers for easy wireup
import { MomentModule } from 'angular2-moment'; // optional, provides moment-style pipes for date formatting

//---Speech recognisation module --
import { SpeechRecognition } from '@ionic-native/speech-recognition';

//---HArdware back button action --
// import { HardwareButtons } from '@scaffold-digital/ionic-hardware-buttons';

//---In app browser for news section --
import { InAppBrowser } from '@ionic-native/in-app-browser';

//---Chat .js module --
import { ChartsModule } from 'ng2-charts';

//---App update --
import { AppVersion } from '@ionic-native/app-version';
//  for notification msg
// import { OneSignal } from '@ionic-native/onesignal';
import { Device } from '@ionic-native/device';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Market } from '@ionic-native/market';
import { AppAvailability } from '@ionic-native/app-availability';
import { PortfolioManagerProvider } from '../providers/portfolio-manager/portfolio-manager';
import { PlaceorderManagerProvider } from '../providers/placeorder-manager/placeorder-manager';
import { IonicSelectableModule } from 'ionic-selectable';
//import { IonicImageViewerModule } from 'ionic-img-viewer';
// import { BackgroundMode } from '@ionic-native/background-mode';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PortfolioTrackerProvider } from '../providers/portfolio-tracker/portfolio-tracker';
import { PdfMakeGeneratorProvider } from '../providers/pdf-make-generator/pdf-make-generator';
import { File } from '@ionic-native/file';
import { IpoServiceProvider } from '../providers/ipo-service/ipo-service';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio';
import { MfContentProvider } from '../providers/mf-content/mf-content';
import { ScreenOrientation } from '@ionic-native/screen-orientation'

@NgModule({
  declarations: [
    MyApp,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    JsonpModule,
    HttpClientJsonpModule,
    NvD3Module,
    MomentModule,
    ChartsModule,
    NgIdleKeepaliveModule.forRoot(),
    IonicModule.forRoot(MyApp,{
      mode: 'md'
    }),
    IonicStorageModule.forRoot(),
    //IonicImageViewerModule
    //GaugeModule.forRoot()
    IonicSelectableModule,BrowserAnimationsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp
  ],
  providers: [
    StatusBar,
    SplashScreen,
    GlobalVariableService,
    RequestManagerProvider,
    UserManagerProvider,
    CommonProvider,
    ExchangeInformationProvider,
    MarketWatchProvider,
    AddScripProvider,
    Network,
    GlobalConfigService,
    IonicStorageModule,
    WebsocketProvider,
    WebsocketUtilityService,
    QuoteHeaderProvider,
    MarketDepthProvider,
    ReportProvider,
    BuySellProvider,
    ConvertProvider,
    MarketMoversProvider,
    FundManagementProvider,
    AppUpdateProvider,
    SpeechRecognition,
    InAppBrowser,
    AppVersion,
    ScreenOrientation,
    // OneSignal,
    Device,Camera,Market,AppAvailability,PortfolioManagerProvider,PlaceorderManagerProvider,
    // BackgroundMode,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    PortfolioTrackerProvider,File,
    PdfMakeGeneratorProvider,
    IpoServiceProvider,FingerprintAIO,MfContentProvider
  ]
})
export class AppModule {}
