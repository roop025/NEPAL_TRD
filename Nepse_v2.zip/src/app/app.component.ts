import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, Events, ToastController, IonicApp, MenuController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { UserManagerProvider } from '../providers/user-manager/user-manager';
import { CommonProvider } from '../providers/common/common';
import { GlobalVariableService } from '../providers/common/global-variable';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { AppVersion } from '@ionic-native/app-version';
// import { OneSignal } from '@ionic-native/onesignal';
import { Device } from '@ionic-native/device';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { ReportProvider } from '../providers/report/report';
import {
  trigger,
  state,
  style,
  animate,
  transition, query, stagger
} from '@angular/animations';

declare var require:any

@Component({
  selector: 'sidemenu-page',
  templateUrl: '../pages/DionWhite/side-menu/side-menu.html',
  animations: [
    trigger('photosAnimation', [
      transition(':enter', [
        query('button', style({ transform: 'translateX(-100%)' }), { optional: true }),
        query('button',
          stagger('100ms', [
            animate('900ms', style({ transform: 'translateX(0)' }))
          ]), { optional: true })
      ])
    ])
  ]
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = '';
  setClient: any = '';
  userData: any = '';
  isLogin: any = '';
  firstUsserLetter: any = '';
  logoutFrmData: any = '';
  user_logout_result: any = '';
  ClientName: any = '';
  appObj: any = '';
  rsponse: any;
  showSubMenu: boolean = false;
  profileImg: any;
  idleState = 'Not started.';
  timedOut = false;
  _Background: boolean = false

  deviceObj: any = {
    deviceModel: '',
    devicePlatform: '',
    deviceUUID: '',
    oneSignalPlayerId: '',
    oneSignalAuthKey: '',
  };

  pages: Array<{ title: string, component: any, icon: any, icon1: any, icon2: any; status: any, subItem: any[] }>;
  public counter = 0;
  public activeClientData:any;

  constructor(public platform: Platform,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    public globalVar: GlobalVariableService,
    private storage: Storage,
    private userManager: UserManagerProvider,
    private common: CommonProvider,
    public toastCtrl: ToastController,
    public appVersion: AppVersion,
    // private oneSignal: OneSignal,
    private appPopObj: IonicApp,
    private ev: Events, private idle: Idle,
    private device: Device, public menuCtr: MenuController,
    public getReportManager: ReportProvider
  ) {
    this.setClient = globalVar.clientName;
    var th = this;
    this.expireSessionWatch();
    this.activeClientData = require("../assets/DionBlack/contactInfo.json");

    if (this.platform.is('cordova')) {

      // One Signal Notification Work Here......
      // if (this.setClient === 'Canara') {
      //   this.platform.ready().then(() => {

      //     this.oneSignal.startInit('f2868596-11ae-4975-b726-4d3297322ae7', '');
      //     this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.InAppAlert);
      //     this.oneSignal.handleNotificationReceived().subscribe((data) => {
      //     });
      //     this.oneSignal.handleNotificationOpened().subscribe((res) => {
      //       // do something when a notification is opened
      //     });
      //     this.oneSignal.endInit();
      //     this.oneSignal.getIds().then((id) => {
      //       // console.log(id);
      //       this.deviceObj.oneSignalPlayerId = id.userId;
      //       this.deviceObj.oneSignalAuthKey = id.pushToken;
      //       this.globalVar.setDeviceInfo(th.deviceObj);
      //       //       console.log(status.subscriptionStatus.userId)
      //     });
      //     // this.backgroundMode.enable();
      //   })
      // } else if (this.setClient === 'Jetrade') {
      //   this.platform.ready().then(() => {
      //     // f92af4a3-8eba-43d5-aba0-939829812c3f   demo One Signal Notification App key
      //     this.storage.get('enable_notification').then(data => {

      //       if (data == null || data == 'enabled') {
      //         this.oneSignal.startInit('e175cd59-436b-4293-aec2-93d71913e9c0', '');
      //         this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.InAppAlert);
      //         this.oneSignal.handleNotificationReceived().subscribe((data) => {
      //         });
      //         this.oneSignal.handleNotificationOpened().subscribe((res) => {
      //           // do something when a notification is opened
      //           console.log("Handle notification", res);
      //           let notification_obj = res;
      //           let body_data = res.notification.payload.body; //Research Call for Basket Trading received from Research Team. (Basket:A2Z)
      //           let check_basket = body_data.search('Trading Basket') //0
      //           if (check_basket !== -1) {
      //             let serchforbasket = body_data.split(' '); //63
      //             // let findsubstring=body_data.substr(serchforbasket); //Basket:A2Z)
      //             // let split_me=findsubstring.split(':'); //  ["Basket", "A2Z)"]
      //             // let basket_key=split_me[1].replace(')','');
      //             let basket_key = serchforbasket[2];
      //             console.log("basketkey", basket_key);
      //             setTimeout(_ => {
      //               if (this.rootPage !== 'LoginPage') {
      //                 this.nav.setRoot('ResearchBasketPage', { basket_key: basket_key })
      //               }
      //             }, 3000)

      //           }
      //           let check_research = body_data.search('Research Call:')
      //           if (check_research !== -1) {
      //             try {
      //               let FlashMsg = body_data;
      //               let msg = FlashMsg.split("] :");//---Split the string so as to get the time and orderObject seperately--
      //               console.log("this.msg", msg)
      //               let cleanArray = msg.filter(function () { return true });//---Removing any empty value from the array--
      //               console.log("this.cleanArray", cleanArray)
      //               let stringWithoutSpace = cleanArray[0].trim();//---Remove any blank space from beginnig or end --
      //               console.log("this.stringWithoutSpace", stringWithoutSpace)
      //               let textMessage = stringWithoutSpace.split("_");
      //               console.log("this.textMessage", textMessage)
      //               let placeArr = textMessage[0].trim().split(" ")
      //               console.log("this.placeArr", placeArr)
      //               //---loop to find out the indexes and value--
      //               let orderOBJ: any = {};
      //               placeArr.forEach((value, index) => {
      //                 console.log("value", value, "Index", index)
      //                 if (value.includes("BuySellInd:")) { orderOBJ.BuySellInd = value.split(":")[1]; }
      //                 if (value.includes("Exchange:")) { orderOBJ.Exchange = value.split(":")[1]; }
      //                 if (value.includes("Scrip")) { orderOBJ.Scrip = value.split(/:(.+)/)[1]; }
      //                 if (value.includes("Quantity:")) { orderOBJ.Quantity = value.split(":")[1]; }
      //                 if (value.includes("Price") && !value.includes("CoverTargetPrice:") && !value.includes("CoverTriggerPrice:")) { orderOBJ.Price = value.split(":")[1]; }
      //                 if (value.includes("CoverTargetPrice:")) { orderOBJ.CoverTargetPrice = value.split(":")[1]; }
      //                 if (value.includes("CoverTriggerPrice:")) { orderOBJ.CoverTriggerPrice = value.split(":")[1]; }
      //                 if (value.includes("Validity:")) { orderOBJ.Validity = value.split(":")[1]; }
      //               })
      //               console.log(orderOBJ)
      //               //console.log("this.orderOBJ",this.orderOBJ)
      //               //---Now get the specified quote and execute fund transfer ---
      //               this.executeOrder(orderOBJ, textMessage);
      //             }
      //             catch (err) { console.log(err) }
      //           }
      //         });
      //         this.oneSignal.endInit();
      //         this.oneSignal.getIds().then((id) => {
      //           console.log(id);
      //           this.deviceObj.oneSignalPlayerId = id.userId;
      //           this.deviceObj.oneSignalAuthKey = id.pushToken;
      //           this.globalVar.setDeviceInfo(th.deviceObj);
      //           //       console.log(status.subscriptionStatus.userId)
      //         });
      //         this.storage.set('enable_notification', "enabled");
      //       }
      //     })
      //   })
      // } else {
      //   console.log('No Client....')
      // }

    }


    this.initializeApp();

    this.checkUserStatus();
    //---get the user login data --
    this.ev.subscribe('checkUserMasterData', data => {
      this.onLoginRegister();
    });

    this.ClientName = globalVar.clientName;
    if (this.ClientName === 'Bgse') {
      this.pages = [
        {
          title: 'Home',
          icon: 'home',
          component: 'HomePage',
          icon1: '',
          icon2: '',
          status: true,
          subItem: []
        },
        {
          title: 'Trading',
          icon: 'line-chart',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Dashboard', component: 'DashboardPage', icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg', status: true, isImg: true },
            { title: 'Holdings', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true, isImg: true },
            { title: 'Net Position', component: 'NetPositionPage', icon: 'assets/' + this.ClientName + '/side_navagation/net_position.svg', status: true, isImg: true },
            { title: 'Trade Book', component: 'TradeBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/trade_book.svg', status: true, isImg: true },
            { title: 'Order Book', component: 'OrderBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/OrderBook.svg', status: true, isImg: true },
            { title: 'Watchlist', component: 'MarketWatchPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true, isImg: true },
            { title: 'Markets', component: 'MarketMoversPage', icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg', status: true, isImg: true },
            { title: 'Margin', component: 'MarginPage', icon: 'assets/' + this.ClientName + '/side_navagation/margin.svg', status: true, isImg: true },
            { title: 'Fund Management', component: 'FundManagementPage', icon: 'assets/' + this.ClientName + '/side_navagation/Fund management.svg', status: true, isImg: true },
            { title: 'News', component: 'NewsPage', icon: 'assets/' + this.ClientName + '/side_navagation/news.svg', status: true, isImg: true },
            { title: 'Our Research', component: 'ResearchPage', icon: 'assets/' + this.ClientName + '/side_navagation/Our_research.svg', status: true, isImg: true },
            { title: 'Research Basket', component: 'ResearchBasketPage', icon: 'assets/' + this.ClientName + '/side_navagation/Research_basket.svg', status: true, isImg: true },
            { title: 'History Report', component: 'HistoryReportPage', icon: 'assets/' + this.ClientName + '/side_navagation/History_report.svg', status: true, isImg: true },
            { title: 'Back Office', component: 'backOffice', icon: 'assets/' + this.ClientName + '/side_navagation/back_office.svg', status: true, isImg: true },
            { title: 'My Profile', component: 'SettingPage', icon: 'assets/' + this.ClientName + '/side_navagation/myprofile.svg', status: true, isImg: true },
            { title: 'About Us', component: 'AboutUsPage', icon: 'assets/' + this.ClientName + '/side_navagation/About-Us.svg', status: true, isImg: true },
          ]
        },
        // {
        //   title: 'Mutual Fund',
        //   icon: '',
        //   component: '',
        //   icon1: 'ios-arrow-down',
        //   icon2: 'ios-arrow-up',
        //   status: false,
        //   subItem: [
        //     //  { title: 'Dashboard', component: 'MfhomePage' , icon: 'tachometer',status:true},
        //     // { title: 'Place Order', component: 'PlaceorderSuggestionPage' , icon:'shopping-bag',status:true},
        //     { title: 'Place Order', component: 'PlaceOrderPage', icon: 'shopping-bag', status: true },
        //     { title: 'Holding Report', component: 'HoldingReportPage', icon: 'list-alt', status: true },
        //     // { title: 'Investment suggestions', component: 'PlaceorderSuggestionPage' , icon:'fa fa-lightbulb-o',status:true},
        //     // { title: 'Mandate registration', component: 'MandateRegisterationPage' , icon:'pencil-square-o',status:true},
        //     { title: 'Order book', component: 'MfOrderBookPage', icon: 'book', status: true },
        //     { title: 'Systematic Registration Report', component: 'MfOrderBookPage', icon: 'refresh', status: true },
        //     // { title: 'My SIP Renew Report', component: 'MysipRenewReportPage' , icon:'refresh',status:true},
        //     // { title: 'My Dividend History', component: 'MydividendHistoryPage' , icon:'history',status:true},

        //     { title: 'Allotment Report', component: 'MfAllotmentReportPage', icon: 'sticky-note', status: true },
        //     { title: 'Margin Report', component: 'MfMarginReportPage', icon: 'repeat', status: true },
        //     // { title: 'Allocation', component: 'AllocationPage' , icon: 'arrows-alt',status:true},

        //     // { title: 'Tax statement', component: 'TaxStatementPage' , icon:'bar-chart',status:true},
        //     // { title: 'Capital gain loss', component: 'CapitalGainLossPage' , icon:'repeat',status:true},
        //     //  { title: 'Segment wise report', component: 'SegmentWiseReportPage' , icon:'sticky-note',status:true},
        //     // { title: 'CAS Upload', component: 'CasUploadPage' , icon: 'tachometer',status:true},
        //     // { title: 'External Portfolio', component: 'ExternalPortfolioPage' , icon: 'external-link-square',status:true},
        //   ]


        // },
        {
          title: 'IPO',
          icon: '',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [{ title: 'Place Order', component: 'IpoPlaceOrderPage', icon: 'book', status: true },
          { title: 'Order Book', component: 'IpoOrderBookPage', icon: 'archive', status: true },
          { title: 'Allotment Report', component: 'IpoAllotmentReportPage', icon: 'list-alt', status: true }
          ]
        },
        //   {
        //   title:'Portfolio Tracker',
        //   icon:'',
        //   component:'',
        //   icon1:'ios-arrow-down',
        //   icon2:'ios-arrow-up',
        //   status:false,
        //   subItem:[{
        //       title:'Dashboard',
        //       component:'PortfolioDashboardPage',
        //       icon:'tachometer',
        //     },
        //     {
        //     title:'My Portfolio',
        //     component:'PortfolioSummaryPage',
        //     icon:'book',
        //   },
        //   {
        //     title:'My Transactions',
        //     component:'PortfolioTransactionsPage',
        //     icon:'exchange',
        //   },
        //   // {
        //   //   title:'Add Investments',
        //   //   component:'AddInvestmentsPage',
        //   //   icon:'plus-square-o',
        //   // },
        //   // {
        //   //   title:'Manage Portfolios',
        //   //   component:'ManagePortfoliosPage',
        //   //   icon:'pencil-square-o',
        //   // },
        //   {
        //     title:'My Portfolios Report ',
        //     component:'PortfolioReportsPage',
        //     icon:'list',
        //   },
        //   // {
        //   //   title:'Commodity ',
        //   //   component:'',
        //   //   icon:'',
        //   // },
        //   // {
        //   //   title:'Mutual Fund ',
        //   //   component:'',
        //   //   icon:'',
        //   // },

        //   // {
        //   //   title:'Bullion',
        //   //   component:'',
        //   //   icon:'',
        //   // },
        //   // {
        //   //   title:'Ulips',
        //   //   component:'',
        //   //   icon:'',
        //   // },
        //   // {
        //   //   title:'Fixed Income',
        //   //   component:'',
        //   //   icon:'',
        //   // },
        //   // {
        //   //   title:'Loans',
        //   //   component:'',
        //   //   icon:'',
        //   // },
        //   // {
        //   //   title:'Borrowings',
        //   //   component:'',
        //   //   icon:'',
        //   // },
        // ]


        //  },
        {
          title: 'Logout',
          icon: 'power-off',
          component: '',
          icon1: '',
          icon2: '',
          status: false,
          subItem: []
        }]
    }
    else if (this.ClientName === 'DionBlack') {
      this.pages = [
        {
          title: 'Home',
          icon: 'assets/' + this.ClientName + '/side_navagation/Home.svg',
          component: 'HomePage',
          icon1: '',
          icon2: '',
          status: true,
          subItem: []
        },
        {
          title: 'Trading',
          icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Dashboard', component: 'DashboardPage', icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg', status: true, isImg: true },
            { title: 'Holdings', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true, isImg: true },
            { title: 'Net Position', component: 'NetPositionPage', icon: 'assets/' + this.ClientName + '/side_navagation/net_position.svg', status: true, isImg: true },
            { title: 'Trade Book', component: 'TradeBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/trade_book.svg', status: true, isImg: true },
            { title: 'Order Book', component: 'OrderBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/OrderBook.svg', status: true, isImg: true },
            { title: 'Watchlist', component: 'MarketWatchPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true, isImg: true },
            { title: 'Live Market', component: 'LiveMarketPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true, isImg: true },
            { title: 'Markets', component: 'MarketMoversPage', icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg', status: true, isImg: true },
            { title: 'Margin', component: 'MarginPage', icon: 'assets/' + this.ClientName + '/side_navagation/margin.svg', status: true, isImg: true },
            { title: 'Fund Management', component: 'FundManagementPage', icon: 'assets/' + this.ClientName + '/side_navagation/Fund management.svg', status: true, isImg: true },
            { title: 'News', component: 'NewsPage', icon: 'assets/' + this.ClientName + '/side_navagation/news.svg', status: true, isImg: true },
            { title: 'Our Research', component: 'ResearchPage', icon: 'assets/' + this.ClientName + '/side_navagation/Our_research.svg', status: true, isImg: true },
            { title: 'Research Basket', component: 'ResearchBasketPage', icon: 'assets/' + this.ClientName + '/side_navagation/Research_basket.svg', status: true, isImg: true },
            { title: 'History Report', component: 'HistoryReportPage', icon: 'assets/' + this.ClientName + '/side_navagation/History_report.svg', status: true, isImg: true },
            // { title: 'Back Office', component: 'backOffice', icon: 'assets/' + this.ClientName + '/side_navagation/back_office.svg', status: true, isImg: true },
            { title: 'My Profile', component: 'SettingPage', icon: 'assets/' + this.ClientName + '/side_navagation/myprofile.svg', status: true, isImg: true },
            { title: 'About Us', component: 'AboutUsPage', icon: 'assets/' + this.ClientName + '/side_navagation/About-Us.svg', status: true, isImg: true },
          ]
        },
        // {
        //   title: 'Mutual Fund',
        //   icon: 'assets/' + this.ClientName + '/side_navagation/mf.svg',
        //   component: '',
        //   icon1: 'ios-arrow-down',
        //   icon2: 'ios-arrow-up',
        //   status: false,
        //   subItem: [
        //     { title: 'Place Order', component: 'PlaceOrderPage', icon: 'shopping-bag', status: true },
        //     { title: 'Holding Report', component: 'HoldingReportPage', icon: 'list-alt', status: true },
        //     { title: 'Order book', component: 'MfOrderBookPage', icon: 'book', status: true },
        //     { title: 'Systematic Registration Report', component: 'MfOrderBookPage', icon: 'refresh', status: true },
        //     { title: 'Allotment Report', component: 'MfAllotmentReportPage', icon: 'sticky-note', status: true },
        //     { title: 'Margin Report', component: 'MfMarginReportPage', icon: 'repeat', status: true },
        //   ]
        // },
        // {
        //   title: 'IPO',
        //   icon: 'assets/' + this.ClientName + '/side_navagation/ipo.svg',
        //   component: '',
        //   icon1: 'ios-arrow-down',
        //   icon2: 'ios-arrow-up',
        //   status: false,
        //   subItem: [{ title: 'Place Order', component: 'IpoPlaceOrderPage', icon: 'book', status: true },
        //   { title: 'Order Book', component: 'IpoOrderBookPage', icon: 'archive', status: true },
        //   { title: 'Allotment Report', component: 'IpoAllotmentReportPage', icon: 'list-alt', status: true }
        //   ]
        // },
        {
          title: 'Logout',
          icon: 'assets/' + this.ClientName + '/side_navagation/LogOut.svg',
          component: '',
          icon1: '',
          icon2: '',
          status: false,
          subItem: []
        }]
    } else if (this.ClientName === 'DionWhite') {
      this.pages = [
        // {
        //   title: 'Dashboard',
        //   icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg',
        //   component: 'DashboardPage',
        //   icon1: '',
        //   icon2: '',
        //   status: true,
        //   subItem: []
        // },
        {
          title: 'Trading',
          icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: true,
          subItem: [
            { title: 'Portfolio', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true, isImg: true },
            // { title: 'Dashboard', component: 'DashboardPage', icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg', status: true, isImg: true },
            // { title: 'Holdings', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true, isImg: true },
            { title: 'Net Position', component: 'NetPositionPage', icon: 'assets/' + this.ClientName + '/side_navagation/net_position.svg', status: true, isImg: true },
            // { title: 'Trade Book', component: 'TradeBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/trade_book.svg', status: true, isImg: true },
            { title: 'Order Book', component: 'OrderBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/OrderBook.svg', status: true, isImg: true },
            { title: 'Live Market', component: 'LiveMarketPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true, isImg: true },
            { title: 'Watchlist', component: 'MarketWatchPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true, isImg: true },
            { title: 'Markets', component: 'MarketMoversPage', icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg', status: true, isImg: true },
            { title: 'Naasa Wallet', component: 'MarginPage', icon: 'assets/' + this.ClientName + '/side_navagation/margin.svg', status: true, isImg: true },
            { title: 'Fund Management', component: 'FundManagementPage', icon: 'assets/' + this.ClientName + '/side_navagation/Fund management.svg', status: true, isImg: true },
            { title: 'Exchange Info', component: 'ExchangeInformationPage', icon: 'assets/' + this.ClientName + '/side_navagation/Our_research.svg', status: true, isImg: true },
            // { title: 'News', component: 'NewsPage', icon: 'assets/' + this.ClientName + '/side_navagation/news.svg', status: true, isImg: true },
            // { title: 'Our Research', component: 'ResearchPage', icon: 'assets/' + this.ClientName + '/side_navagation/Our_research.svg', status: true, isImg: true },
            // { title: 'Research Basket', component: 'ResearchBasketPage', icon: 'assets/' + this.ClientName + '/side_navagation/Research_basket.svg', status: true, isImg: true },
            // { title: 'History Report', component: 'HistoryReportPage', icon: 'assets/' + this.ClientName + '/side_navagation/History_report.svg', status: true, isImg: true },
            // { title: 'Back Office', component: 'backOffice', icon: 'assets/' + this.ClientName + '/side_navagation/back_office.svg', status: true, isImg: true },
            { title: 'My Profile', component: 'SettingPage', icon: 'assets/' + this.ClientName + '/side_navagation/myprofile.svg', status: true, isImg: true },
            { title: 'About Us', component: 'AboutUsPage', icon: 'assets/' + this.ClientName + '/side_navagation/About-Us.svg', status: true, isImg: true },
          ]
        },
        // {
        //   title: 'Mutual Fund',
        //   icon: 'assets/' + this.ClientName + '/side_navagation/mf.svg',
        //   component: '',
        //   icon1: 'ios-arrow-down',
        //   icon2: 'ios-arrow-up',
        //   status: false,
        //   subItem: [
        //     { title: 'Place Order', component: 'PlaceOrderPage', icon: 'shopping-bag', status: true },
        //     { title: 'Holding Report', component: 'HoldingReportPage', icon: 'list-alt', status: true },
        //     { title: 'Order book', component: 'MfOrderBookPage', icon: 'book', status: true },
        //     { title: 'Systematic Registration Report', component: 'MfOrderBookPage', icon: 'refresh', status: true },
        //     { title: 'Allotment Report', component: 'MfAllotmentReportPage', icon: 'sticky-note', status: true },
        //     { title: 'Margin Report', component: 'MfMarginReportPage', icon: 'repeat', status: true },
        //   ]
        // },
        // {
        //   title: 'IPO',
        //   icon: 'assets/' + this.ClientName + '/side_navagation/ipo.svg',
        //   component: '',
        //   icon1: 'ios-arrow-down',
        //   icon2: 'ios-arrow-up',
        //   status: false,
        //   subItem: [{ title: 'Place Order', component: 'IpoPlaceOrderPage', icon: 'book', status: true },
        //   { title: 'Order Book', component: 'IpoOrderBookPage', icon: 'archive', status: true },
        //   { title: 'Allotment Report', component: 'IpoAllotmentReportPage', icon: 'list-alt', status: true }
        //   ]
        // },
        {
          title: 'Logout',
          icon: 'assets/' + this.ClientName + '/side_navagation/LogOut.svg',
          component: '',
          icon1: '',
          icon2: '',
          status: false,
          subItem: []
        }]
    } else if (this.ClientName === 'Bhumika') {
      this.pages = [
        {
          title: 'Home',
          icon: 'assets/' + this.ClientName + '/side_navagation/Home.svg',
          component: 'HomePage',
          icon1: '',
          icon2: '',
          status: true,
          subItem: []
        },
        {
          title: 'Trading',
          icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            // { title: 'Dashboard', component: 'DashboardPage', icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg', status: true, isImg: true },
            // { title: 'Holdings', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true, isImg: true },
            // { title: 'Net Position', component: 'NetPositionPage', icon: 'assets/' + this.ClientName + '/side_navagation/net_position.svg', status: true, isImg: true },
            // { title: 'Trade Book', component: 'TradeBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/trade_book.svg', status: true, isImg: true },
            // { title: 'Order Book', component: 'OrderBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/OrderBook.svg', status: true, isImg: true },
            // { title: 'Watchlist', component: 'MarketWatchPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true, isImg: true },
            // { title: 'Markets', component: 'MarketMoversPage', icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg', status: true, isImg: true },
            // { title: 'Margin', component: 'MarginPage', icon: 'assets/' + this.ClientName + '/side_navagation/margin.svg', status: true, isImg: true },
            // { title: 'Fund Management', component: 'FundManagementPage', icon: 'assets/' + this.ClientName + '/side_navagation/Fund management.svg', status: true, isImg: true },
            // { title: 'News', component: 'NewsPage', icon: 'assets/' + this.ClientName + '/side_navagation/news.svg', status: true, isImg: true },
            // { title: 'Our Research', component: 'ResearchPage', icon: 'assets/' + this.ClientName + '/side_navagation/Our_research.svg', status: true, isImg: true },
            // { title: 'Research Basket', component: 'ResearchBasketPage', icon: 'assets/' + this.ClientName + '/side_navagation/Research_basket.svg', status: true, isImg: true },
            // { title: 'History Report', component: 'HistoryReportPage', icon: 'assets/' + this.ClientName + '/side_navagation/History_report.svg', status: true, isImg: true },
            // { title: 'Back Office', component: 'backOffice', icon: 'assets/' + this.ClientName + '/side_navagation/back_office.svg', status: true, isImg: true },
            // { title: 'My Profile', component: 'SettingPage', icon: 'assets/' + this.ClientName + '/side_navagation/myprofile.svg', status: true, isImg: true },
            // { title: 'About Us', component: 'AboutUsPage', icon: 'assets/' + this.ClientName + '/side_navagation/About-Us.svg', status: true, isImg: true },

            {
              title: "Home",
              component: "HomePage",
              icon: "home",
              status: true,
            },
            {
              title: "Dashboard",
              component: "DashboardPage",
              icon: "tachometer",
              status: true,
            },
            {
              title: "Market Movers",
              component: "MarketMoversPage",
              icon: "line-chart",
              status: true,
            },
            {
              title: "Market Watch",
              component: "MarketWatchPage",
              icon: "rss",
              status: true,
            },
            {
              title: "Order Book",
              component: "OrderBookPage",
              icon: "book",
              status: true,
            },
            {
              title: "Trade Book",
              component: "TradeBookPage",
              icon: "clipboard",
              status: true,
            },
            {
              title: "Net Position",
              component: "NetPositionPage",
              icon: "list-alt",
              status: true,
            },
            {
              title: "Holdings",
              component: "HoldingsPage",
              icon: "pie-chart",
              status: true,
            },
            {
              title: "Margin",
              component: "MarginPage",
              icon: "percent",
              status: true,
            },
            {
              title: "Fund Management",
              component: "FundManagementPage",
              icon: "money",
              status: true,
            },
            {
              title: "Research Calls",
              component: "ResearchPage",
              icon: "bell",
              status: true,
            },
            {
              title: "History Report",
              component: "HistoryReportPage",
              icon: "envelope-open",
              status: true,
            },
            {
              title: "About Us",
              component: "AboutUsPage",
              icon: "info",
              status: true,
            },
            {
              title: "Login",
              component: "LoginPage",
              icon: "info",
              status: false,
            },
            {
              title: "Setting",
              component: "SettingPage",
              icon: "info",
              status: false,
            },
          ]
        },
        {
          title: 'Mutual Fund',
          icon: 'assets/' + this.ClientName + '/side_navagation/mf.svg',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Place Order', component: 'PlaceOrderPage', icon: 'shopping-bag', status: true },
            { title: 'Holding Report', component: 'HoldingReportPage', icon: 'list-alt', status: true },
            { title: 'Order book', component: 'MfOrderBookPage', icon: 'book', status: true },
            { title: 'Systematic Registration Report', component: 'MfOrderBookPage', icon: 'refresh', status: true },
            { title: 'Allotment Report', component: 'MfAllotmentReportPage', icon: 'sticky-note', status: true },
            { title: 'Margin Report', component: 'MfMarginReportPage', icon: 'repeat', status: true },
          ]
        },
        {
          title: 'IPO',
          icon: 'assets/' + this.ClientName + '/side_navagation/ipo.svg',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [{ title: 'Place Order', component: 'IpoPlaceOrderPage', icon: 'book', status: true },
          { title: 'Order Book', component: 'IpoOrderBookPage', icon: 'archive', status: true },
          { title: 'Allotment Report', component: 'IpoAllotmentReportPage', icon: 'list-alt', status: true }
          ]
        },
        {
          title: 'Logout',
          icon: 'assets/' + this.ClientName + '/side_navagation/LogOut.svg',
          component: '',
          icon1: '',
          icon2: '',
          status: false,
          subItem: []
        }]
    } else if (this.ClientName === 'Nirman') {
      this.pages = [
        {
          title: 'Home',
          icon: 'home',
          component: 'HomePage',
          icon1: '',
          icon2: '',
          status: true,
          subItem: []
        },
        {
          title: 'Trading',
          icon: 'line-chart',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Home', component: 'HomePage', icon: 'assets/' + this.ClientName + '/side_navagation/Home.svg', status: true },
            { title: 'Dashboard', component: 'DashboardPage', icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg', status: true },
            { title: 'Holdings', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true },
            { title: 'Net Position', component: 'NetPositionPage', icon: 'assets/' + this.ClientName + '/side_navagation/net_position.svg', status: true },
            { title: 'Trade Book', component: 'TradeBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/trade_book.svg', status: true },
            { title: 'Order Book', component: 'OrderBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/OrderBook.svg', status: true },
            { title: 'Watchlist', component: 'MarketWatchPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true },
            { title: 'Markets', component: 'MarketMoversPage', icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg', status: true },
            { title: 'Margin', component: 'MarginPage', icon: 'assets/' + this.ClientName + '/side_navagation/margin.svg', status: true },
            { title: 'Fund Management', component: 'FundManagementPage', icon: 'assets/' + this.ClientName + '/side_navagation/Fund_management.svg', status: true },
            { title: 'News', component: 'NewsPage', icon: 'assets/' + this.ClientName + '/side_navagation/news.svg', status: true },
            { title: 'Alert Message', component: 'ResearchPage', icon: 'assets/' + this.ClientName + '/side_navagation/Our_research.svg', status: true },
            { title: 'Research Basket', component: 'ResearchBasketPage', icon: 'assets/' + this.ClientName + '/side_navagation/Research_basket.svg', status: true, isImg: true },
            { title: 'Back Office', component: 'backOffice', icon: 'assets/' + this.ClientName + '/side_navagation/back_office.svg', status: true },
            { title: 'My Profile', component: 'SettingPage', icon: 'assets/' + this.ClientName + '/side_navagation/myprofile.svg', status: true },
            { title: 'About Us', component: 'AboutUsPage', icon: 'assets/' + this.ClientName + '/side_navagation/About-Us.svg', status: true },
          ]
        },
        {
          title: 'Mutual Fund',
          icon: '',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Place Order', component: 'PlaceOrderPage', icon: 'shopping-bag', status: true },
            { title: 'Holding Report', component: 'HoldingReportPage', icon: 'list-alt', status: true },
            { title: 'Order book', component: 'MfOrderBookPage', icon: 'book', status: true },
            { title: 'Systematic Registration Report', component: 'MfOrderBookPage', icon: 'refresh', status: true },
            { title: 'Allotment Report', component: 'MfAllotmentReportPage', icon: 'sticky-note', status: true },
            { title: 'Margin Report', component: 'MfMarginReportPage', icon: 'repeat', status: true },
          ]
        },
        {
          title: 'IPO',
          icon: '',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [{ title: 'Place Order', component: 'IpoPlaceOrderPage', icon: 'book', status: true },
          { title: 'Order Book', component: 'IpoOrderBookPage', icon: 'archive', status: true },
          { title: 'Allotment Report', component: 'IpoAllotmentReportPage', icon: 'list-alt', status: true }
          ]
        },
        {
          title: 'Logout',
          icon: 'power-off',
          component: '',
          icon1: '',
          icon2: '',
          status: false,
          subItem: []
        }]
     } else if (this.ClientName === 'Gogia') {
      this.pages = [
        {
          title: 'Home',
          icon: 'home',
          component: 'HomePage',
          icon1: '',
          icon2: '',
          status: true,
          subItem: []
        },
        {
          title: 'Trading',
          icon: 'line-chart',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Home', component: 'HomePage', icon: 'assets/' + this.ClientName + '/side_navagation/Home.svg', status: true },
            { title: 'Dashboard', component: 'DashboardPage', icon: 'assets/' + this.ClientName + '/side_navagation/dashboard.svg', status: true },
            { title: 'Holdings', component: 'HoldingsPage', icon: 'assets/' + this.ClientName + '/side_navagation/Holdings.svg', status: true },
            { title: 'Net Position', component: 'NetPositionPage', icon: 'assets/' + this.ClientName + '/side_navagation/net_position.svg', status: true },
            { title: 'Trade Book', component: 'TradeBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/trade_book.svg', status: true },
            { title: 'Order Book', component: 'OrderBookPage', icon: 'assets/' + this.ClientName + '/side_navagation/OrderBook.svg', status: true },
            { title: 'Watchlist', component: 'MarketWatchPage', icon: 'assets/' + this.ClientName + '/side_navagation/watchlist.svg', status: true },
            { title: 'Markets', component: 'MarketMoversPage', icon: 'assets/' + this.ClientName + '/side_navagation/markets.svg', status: true },
            { title: 'Margin', component: 'MarginPage', icon: 'assets/' + this.ClientName + '/side_navagation/margin.svg', status: true },
            { title: 'Fund Management', component: 'FundManagementPage', icon: 'assets/' + this.ClientName + '/side_navagation/Fund_management.svg', status: true },
            { title: 'News', component: 'NewsPage', icon: 'assets/' + this.ClientName + '/side_navagation/news.svg', status: true },
            { title: 'Alert Message', component: 'ResearchPage', icon: 'assets/' + this.ClientName + '/side_navagation/basket_trading.svg', status: true },
            { title: 'Back Office', component: 'backOffice', icon: 'assets/' + this.ClientName + '/side_navagation/back_office.svg', status: true },
            { title: 'My Profile', component: 'SettingPage', icon: 'assets/' + this.ClientName + '/side_navagation/myprofile.svg', status: true },
            { title: 'About Us', component: 'AboutUsPage', icon: 'assets/' + this.ClientName + '/side_navagation/About-Us.svg', status: true },
          ]
        },
        {
          title: 'Mutual Fund',
          icon: '',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [
            { title: 'Place Order', component: 'PlaceOrderPage', icon: 'shopping-bag', status: true },
            { title: 'Holding Report', component: 'HoldingReportPage', icon: 'list-alt', status: true },
            { title: 'Order book', component: 'MfOrderBookPage', icon: 'book', status: true },
            { title: 'Systematic Registration Report', component: 'MfOrderBookPage', icon: 'refresh', status: true },
            { title: 'Allotment Report', component: 'MfAllotmentReportPage', icon: 'sticky-note', status: true },
            { title: 'Margin Report', component: 'MfMarginReportPage', icon: 'repeat', status: true },
          ]
        },
        {
          title: 'IPO',
          icon: '',
          component: '',
          icon1: 'ios-arrow-down',
          icon2: 'ios-arrow-up',
          status: false,
          subItem: [{ title: 'Place Order', component: 'IpoPlaceOrderPage', icon: 'book', status: true },
          { title: 'Order Book', component: 'IpoOrderBookPage', icon: 'archive', status: true },
          { title: 'Allotment Report', component: 'IpoAllotmentReportPage', icon: 'list-alt', status: true }
          ]
        },
        {
          title: 'Logout',
          icon: 'power-off',
          component: '',
          icon1: '',
          icon2: '',
          status: false,
          subItem: []
        }]
    }


    //---Hardware back button initilize--

    platform.registerBackButtonAction(() => {
      let popupstatus:any = this.globalVar.getIsPopupOpen()
      const overlayView = this.appPopObj._overlayPortal._views[0];
      let viewCtrl = this.nav.getActive().instance.viewCtrl;

      if (overlayView && overlayView.dismiss) {
        overlayView.dismiss();// it will close the modals, alerts
      }
      let activeVC = this.nav.getActive();


      if (viewCtrl && !viewCtrl._isHidden) {
        //  you are in modal
        //this.viewCtrl.dismiss();
        let activeModal = this.appPopObj._modalPortal.getActive();
        if (activeModal) {
          activeModal.dismiss();
          return;
        }
      } 



      if (activeVC.id == 'LoginPage' || activeVC.id == 'MpinLoginPage') {
        this.exitApplication();
      } else if (activeVC.id == 'MarketWatchPage' || activeVC.id == 'DashboardPage' || activeVC.id == 'OrderBookPage'
        || activeVC.id == 'AboutUsPage' || activeVC.id == 'DashboardPage' || activeVC.id == 'FundManagementPage'
        || activeVC.id == 'HoldingsPage' || activeVC.id == 'HomePage' || activeVC.id == 'MarginPage'
        || activeVC.id == 'MarketMoversPage' || activeVC.id == 'NetPositionPage' || activeVC.id == 'ResearchPage'  || activeVC.id == 'AccountingPage'
        || activeVC.id == 'TradeBookPage' || activeVC.id == 'LiveMarketPage' || activeVC.id == 'HelpPage' || activeVC.id == 'ResearchBasketPage'
        || activeVC.id == 'StockPage' || activeVC.id == 'TradecallPage' || activeVC.id == 'InfoPage' || activeVC.id == 'HistoryReportPage' || activeVC.id == 'MpinLoginPage') {
        // this.logOut();
        if(popupstatus){
          this.nav.pop({});
          this.ev.publish('closePopup',false);
          this.globalVar.setIsPopupOpen(false)

        } else {
        this.logOut();
        }

      } else {
        //this.nav.canGoBack();
        this.nav.pop({});
        swal.close()
      }
    }, 1);

    //---Object for app version ---
    this.appObj = {
      appName: '',
      appVer: '',
      appPackage: '',
      appCodeVer: ''
    }

    this.deviceObj = {
      deviceModel: '',
      devicePlatform: '',
      deviceUUID: '',
      oneSignalPlayerId: '',
      oneSignalAuthKey: '',
    }

    // Update uploaded profile pic
    this.ev.subscribe('updateProfile:created', data => {
      this.getProfieImage();
    });

  }

// getting feed while app is forground 
  
  setPlatformListener() {

    this.platform.pause.subscribe(() => {// background
      this._Background = true
      this.globalVar.SetIsBackGround(this._Background);
    });

    this.platform.resume.subscribe(() => {// foreground
      this._Background = false
      this.globalVar.SetIsBackGround(this._Background);
    });
  }


  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.statusBar.overlaysWebView(false); 			// for show all changes in background colors
      this.statusBar.show();					// for show status bar in devices
      //statusBar.backgroundColorByName('#16F367')		// for change background color
      //statusBar.backgroundColorByHexString('#16F367');	// for set default status bar colors according themes
      this.setPlatformListener()
      this.checkIdealSate()
      // if (this.ClientName != 'Jetrade' || this.ClientName != 'Nirman')
      //   this.rootPage = 'LoginPage';

      this.ev.subscribe('checkUserMasterData', data => {
        this.loadHoldingReport(data);
      });

      //---Get app version update functionality --
      if (this.platform.is('cordova')) {
        this.appVersion.getAppName().then((appN: any) => {
          this.appObj.appName = appN;
          this.globalVar.setAppInfo(this.appObj);
        });
        this.appVersion.getPackageName().then((pkg: any) => {
          this.appObj.appPackage = pkg;
          this.globalVar.setAppInfo(this.appObj);
        });
        this.appVersion.getVersionCode().then((vc: any) => {
          this.appObj.appCodeVer = vc;
          this.globalVar.setAppInfo(this.appObj);
        });
        this.appVersion.getVersionNumber().then((vn: any) => {
          this.appObj.appVer = vn;
          this.globalVar.setAppInfo(this.appObj);
        });
        this.deviceObj.deviceModel = this.device.model;
        this.deviceObj.devicePlatform = this.device.platform;
        this.deviceObj.deviceUUID = this.device.uuid;
        this.globalVar.setDeviceInfo(this.deviceObj);
      }
    });
    //------------
    this.checkUserStatus();
  }

  //----Login data ---
  onLoginRegister() {
    this.storage.get("userMaster").then((data) => {
      if (data != null && data != '') {
        this.userData = data;
        this.isLogin = true;
        this.firstUsserLetter = this.userData.ClientName.charAt(0)
      } else {
        this.rootPage = 'LoginPage';
      }
    });

    if (this.ClientName != 'Canara') {
      this.storage.get("userProfilePic").then((data) => {
        if (data != null && data != '') {
          this.profileImg = data;
        } else {
          this.getProfieImage();
        }
      });
    }
  }
  checkUserStatus() {
    this.isLogin = false;

    try {
      this.storage.get("userMaster").then((data) => {
        if (data != null && data != '') {
          this.userData = data;
          this.globalVar.setUserData({ uData: this.userData });
          this.isLogin = true;
          this.firstUsserLetter = this.userData.ClientName.charAt(0)
          this.checkForProfileImage()
          //this.rootPage = 'HomePage';
          //this.iniMenuItems(true);
          // if (this.ClientName != 'Jetrade' || this.ClientName != 'Nirman') {
          //   this.loadHoldingReport(this.userData);
          // }

          // if (this.ClientName === 'Jetrade' || this.ClientName === 'Nirman') {
            this.statusBar.backgroundColorByHexString('#001529');
            let login_obj = {
              userId: data.userId, //ka00458 test003 mobcli01
              SessionNo: data.SessionNo,
            }

            this.userManager.validateSession(JSON.stringify(login_obj)).then((Sessiondata: any) => {
              if (Sessiondata != null && Sessiondata.ErrorCode == 0) {
                this.loadHoldingReport(this.userData);
                this.rootPage = 'HoldingsPage'
              }
              else {

                this.rootPage = 'LoginPage';
                this.storage.remove("userMaster");
              }
            }, err => {
              this.rootPage = 'LoginPage';
            })
          // } else {
          //   //this.rootPage = 'LoginPage';
          //   // this.checkExplainer();
          //   // this.iniMenuItems(false);
          //   if (this.ClientName === 'Jetrade' || this.ClientName === 'Nirman')
          //     this.rootPage = 'LoginPage'
          // }
        }
        else {
          // if (this.ClientName === 'Jetrade' || this.ClientName === 'Nirman')
            this.rootPage = 'LoginPage'
        }
      });
    } catch (e) {
      this.rootPage = 'LoginPage'
    }

  }



  openPage(page) {
    this.menuCtr.close()
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    if ((page.component == 'backOffice') && (this.ClientName == 'Bgse' || this.ClientName == 'Gogia')) {
      //window.open('#');

    }
    else if (page.component == 'backOffice') {
      if (this.ClientName == 'Jetrade') {
        window.open('http://backoffice.jhaveritrade.com:81/MClient/index.cfm?ClientCode=' + this.userData.ClientCode + '&SessionNo=' + this.userData.SessionNo, '_blank', 'location=yes');
      } else if (this.ClientName == 'Nirman') {
        window.open('http://backoffice.nirmanbroking.com:8085/capexweb/capexweb/','_blank', 'location=yes');
        // window.open('http://etrade.archfin.com:105/STSB/BackOffice.html?clientcode=' + this.userData.ClientCode + '&amp;SessionNo=' + this.userData.SessionNo + '&amp;LoginName=' + this.userData.userId + '&amp;Source=5');
      } else {
        window.open('http://etrade.archfin.com:105/STSB/BackOffice.html?clientcode=' + this.userData.ClientCode + '&amp;SessionNo=' + this.userData.SessionNo + '&amp;LoginName=' + this.userData.userId + '&amp;Source=5');
      }
    } else {
      this.nav.setRoot(page.component);
    }

  }

  //--open setting page --
  openSettingPage() {

    let setting_page = this.pages[1].subItem.find(x => (x.component == "SettingPage"));
    console.log("openpage", setting_page);

    this.openPage(setting_page)

  }
  //---use logout --
  logOut() {
    this.logoutFrmData = {
      userId: this.userData.ClientCode,
      Source: 5,
      Action: 'LOGIN',
      ClientIPAddress: '',
      SessionNo: this.userData.SessionNo
    };
    swal({
      title: 'Logout?',
      text: 'Are you sure you want to logout',
      type: 'info',
      showCancelButton: true,
      cancelButtonText: "No",
      showLoaderOnConfirm: true,
      confirmButtonColor: "rgba(244, 12, 12, 0.97)",
      confirmButtonText: "Yes, logout!"
    }).then((result) => {
      if (result.value) {
        //---User want to logout--
        this.common.showLoading();
        this.userManager.logout(this.logoutFrmData).then((data) => {
          this.user_logout_result = data;
          this.common.hideLoading();
          //----Successfully login ---
          if (this.user_logout_result.ErrorCode == '0') {
            swal({
              title: "Logged Out!",
              text: 'You are logged out of the system.',
              type: "success",
              timer: 3000
            });
            //---this.storage.clear();
            this.storage.remove("userMaster");
            // localStorage.clear();
            //---this.openPage(this.pages[10]);
            this.nav.push('LoginPage', { status: 1 }).then(() => {
              location.reload();
            })
          } else if (this.user_logout_result.ErrorCode == '-1010002') {
            swal({
              title: "Logged Out!",
              text: 'You are logged out of the system.',
              type: "success",
              timer: 3000
            });
            //---this.storage.clear();
            this.storage.remove("userMaster");
            //---this.openPage(this.pages[10]);
            this.nav.push('LoginPage', { status: 1 }).then(() => {
              location.reload();
            })
          } else {//----User does not able to login --
            swal({
              text: this.user_logout_result.Message,
            });
          }
        }, err => {
          this.common.hideLoading();
          swal({
            text: 'Network Issue ! Please retry or check your network Connection.',
          });
        });
      } else if (result.dismiss === swal.DismissReason.cancel) {
        //---User does not want to logout--
      }
    })
  }

  // exit app code here...
  public exitApplication() {
    swal({
      title: 'EXIT APP ?',
      text: 'Are you sure you want to Exit The App',
      type: 'info',
      showCancelButton: true,
      cancelButtonText: "No",
      showLoaderOnConfirm: true,
      confirmButtonColor: "rgba(244, 12, 12, 0.97)",
      confirmButtonText: "Yes"
    }).then((result) => {
      if (result.value) {
        this.platform.exitApp();
      } else {
        return true;
      }
    })
    return false;
  }


  //---Change password page --
  changePasswordPage() {
    this.nav.push('ChangePasswordPage', { useLogindata: this.userData });
  }
  //---open help page --
  openHelp() {
    this.nav.push('HelpPage');

  }



  public getProfieImage() {
    //---Generate guest user otp--
    this.userManager.getUploadePhoto(this.userData.ClientCode,this.userData.SessionNo).then((data) => {
      this.rsponse = data;
      if (this.rsponse.ErrorCode == '0') {
        var imageUrl = this.rsponse.Base64ProfileImage;
        if (imageUrl != '') {
          let base64Image = 'data:image/jpeg;base64,' + imageUrl;
          this.profileImg = base64Image;
          this.storage.set("userProfilePic", this.profileImg).then(() => {
          });
        }

      } else {

      }
    }, err => {
    });

  }

  menuOpened() {
    this.globalVar.setclosingMWatch(true);
  }

  menuClosed() {
    this.globalVar.setclosingMWatch(false);
  }


  opensubMenu(group) {
    if (this.showSubMenu)
      this.showSubMenu = false
    else
      this.showSubMenu = true
  }

  public openPortfolio() {
    this.nav.push('PortfolioPage')
    this.showSubMenu = false
  }
  public ipoPlaceOrd() {
    this.nav.push('IpoPlaceOrderPage')
    this.showSubMenu = false
  }
  public ipoOrderBook() {

  }


  checkIdealSate() {
    if (this.ClientName === 'Bhumika' || this.ClientName === 'ATSNew') {
      this.idle.setIdle(18000); // chage date 09/07/19 for 5 hrs
    }
    else if (this.ClientName === 'Jetrade') {
      this.idle.setIdle(43200); // for 12 hours
    }
    else {
      // if(this.ClientName != 'Jetrade' )
      this.idle.setIdle(43200); // for 12 hrs
    }
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this.idle.onIdleEnd.subscribe(() => this.idleState = 'No longer idle.');
    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      console.log(this.idleState)
      this.storage.get('userMaster').then(data => {

        if (data != null) {
          swal(
            'Session Time Out!',
            'You are logged out of the system.',
            'success'
          ).then(_ => {


            //this.storage.clear();
            this.storage.remove("userMaster");
            //this.openPage(this.pages[10]);
            this.nav.setRoot('LoginPage').then(() => {
              location.reload();
            })
          })
        }

      })
    });

    this.reset();
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  executeOrder(orderOBJ, textMessage) {
    let alerttext;
    if (orderOBJ.BuySellInd == 'BUY') {
      alerttext = "<span class=" + "Topheading" + ">" + textMessage[0] + "</span>" + "<br>";
      alerttext += "<p>" + "<span class=" + "mainheading" + ">" + "You are placing an order to buy" + "</span>" + "<br>";
      alerttext += "<span class=" + "scripName" + ">" + orderOBJ.Scrip + "</span>" + " : " + "<span class=" + "quantity" + ">" + orderOBJ.Quantity + "</span>" + " @ ";
      alerttext += "<span class=" + "price" + ">" + orderOBJ.Price + "</span>" + "<br>";
      alerttext += "<span class=" + "exchange" + ">" + "in exchange : " + "</span>";
      alerttext += "<span class=" + "exchangeVal" + ">" + orderOBJ.Exchange + "</span>" + "</p>";
    } else {
      alerttext = "<span class=" + "TopheadingRed" + ">" + textMessage[0] + "</span>" + "<br>";
      alerttext += "<p>" + "<span class=" + "mainheading" + ">" + "You are placing an order to sell" + "</span>" + "<br>";
      alerttext += "<span class=" + "scripName" + ">" + orderOBJ.Scrip + "</span>" + " : " + "<span class=" + "quantity" + ">" + orderOBJ.Quantity + "</span>" + " @ ";
      alerttext += "<span class=" + "price" + ">" + orderOBJ.Price + "</span>" + "<br>";
      alerttext += "<span class=" + "exchange" + ">" + "in exchange : " + "</span>";
      alerttext += "<span class=" + "exchangeVal" + ">" + orderOBJ.Exchange + "</span>" + "</p>";
    }
    swal({
      title: 'Want to Open OrderEntry as per below suggestion...?',
      html: alerttext,
      type: 'question',
      //footer:this.textMessage[0],
      customClass: 'researchCalls',
      showCancelButton: true,
      cancelButtonText: "No, cancel order!",
      confirmButtonColor: "#387ef5",
      confirmButtonText: "Yes, confirm order!"
    }).then((result) => {
      if (result.value) {
        //---User want to Place order--
        if (orderOBJ.BuySellInd == 'BUY') {
          //---Rediret to the Buy page --
          let buyObj = {
            ticker: orderOBJ.Scrip,
            underlying: orderOBJ.Scrip,
            exchange: orderOBJ.Exchange,
            // Close:this.quoteDataItem[0].Close,
            // LTP:this.quoteDataItem[0].Close,
            OfferPrice: orderOBJ.Price,
            Quantity: orderOBJ.Quantity,
            CoverTargetPrice: orderOBJ.CoverTargetPrice || '',
            CoverTriggerPrice: orderOBJ.CoverTriggerPrice || ''

          }
          this.globalVar.setQuoteHeaderData({ quoteItem: buyObj });
          this.nav.push('BuyPage', { userbuyData: buyObj, clientUserData: this.userData, isVoiceSearchOrder: true, from_notification: true });
        } else {
          //---Rediret to the Buy page --
          let sellObj = {
            ticker: orderOBJ.Scrip,
            underlying: orderOBJ.Scrip,
            exchange: orderOBJ.Exchange,
            // Close:this.quoteDataItem[0].Close,
            // LTP:this.quoteDataItem[0].Close,
            OfferPrice: orderOBJ.Price,
            Quantity: orderOBJ.Quantity
          }
          this.globalVar.setQuoteHeaderData({ quoteItem: sellObj });
          this.nav.push('SellPage', { usersellData: sellObj, clientUserData: this.userData, isVoiceSearchOrder: true });
        }
      }
    })
  }

  checkForProfileImage() {
    this.storage.get("userProfilePic").then((data) => {
      if (data != null) {
        this.profileImg = data;
      } else {
        this.getProfieImage();
      }
    });
  }

  expireSessionWatch() {
    console.log("Watch for logouttttttttttttttttttt")
    this.ev.subscribe('invalid_session_app', data => {
      console.log("Session Expire>>>>>>>>>>>>>>.");
      this.logOutSession()

    })

    this.ev.subscribe('logOut', data => {
      this.logOut()

    })
  }
  logOutSession() {
    this.logoutFrmData = {
      userId: this.userData.ClientCode,
      Source: 5,
      Action: 'LOGIN',
      ClientIPAddress: '',
      SessionNo: this.userData.SessionNo
    };

    // if (result.value) {
    //---User want to logout--
    this.common.showLoading();
    this.userManager.logout(this.logoutFrmData).then((data) => {
      this.user_logout_result = data;
      this.common.hideLoading();
      //----Successfully login ---
      if (this.user_logout_result.ErrorCode == '0') {
        swal({
          title: "Logged Out!",
          text: 'You are logged out of the system.',
          type: "success",
          timer: 3000
        });
        //---this.storage.clear();
        this.storage.remove("userMaster").then(_clear => {
          console.log("Clear storage", _clear);

        }).catch(errs => {
          console.log("Err storage", errs);
        })

        this.storage.remove("mutual_fund_authories").then(_clear => {
          console.log("Clear storage", _clear);

        }).catch(errs => {
          console.log("Err storage", errs);
        })

        //---this.openPage(this.pages[10]);
        this.nav.push('LoginPage').then(() => {
          location.reload();
        })
      } else if (this.user_logout_result.ErrorCode == '-1010002') {
        swal({
          title: "Logged Out!",
          text: 'You are logged out of the system.',
          type: "success",
          timer: 3000
        });
        //---this.storage.clear();
        this.storage.remove("userMaster").then(_clear => {
          console.log("Clear storage", _clear);

        }).catch(errs => {
          console.log("Err storage", errs);
        })
        //---this.openPage(this.pages[10]);
        this.nav.push('LoginPage').then(() => {
          location.reload();

        })
      } else {//----User does not able to login --
        swal({
          text: this.user_logout_result.Message,
        });
      }

    }, err => {
      this.common.hideLoading();
      swal({
        text: 'Network Issue ! Please retry or check your network Connection.',
      });
    });
  }


  loadHoldingReport(userData) {

    this.getReportManager.getHoldingReportForMwatch("ALL", "Assets", userData, "").then((data) => {

      let holdings_result: any = data;
      let holdingItems = [];
      if (holdings_result.reportTable == "" || holdings_result.reportTable == null) {
      } else {
        holdingItems = JSON.parse(holdings_result.reportTable);
        this.globalVar.setHoldingReport(holdingItems);
      }

    }, err => {

    });
    this.loadAssetReport(userData)
  }


  loadAssetReport(userData) { //for Holdings

    this.getReportManager.getScripOrderReport("ALL", "Assets", userData, "").then((data) => {
      let holdings_result: any = data;
      if (holdings_result.reportTable == "" || holdings_result.reportTable == null) {

      } else {
        let items = JSON.parse(holdings_result.reportTable);
        this.globalVar.holdingReport = items;
      }
    }, err => {

    });
  }
  openSubMenu(page, index) {
    // we wouldn't want the back button to show in this scenario
    if (page.component == 'HomePage' || page.component == 'DashboardPage') {
      this.openPage(page)
    }
    if (page.component == 'HoldingsPage') {
      this.openPage(page)
    }
    else if (page.title == "Logout") {
      this.logOut()
      this.storage.remove("mutual_fund_authories").then(_clear => {
        console.log("Clear storage", _clear);

      }).catch(errs => {
        console.log("Err storage", errs);
      })
    }else if (page.title == "Mutual Fund") {
     this.storage.get("mutual_fund_authories").then((data) => {
      if (data != null) {
         this.globalVar.userDetailFromGetInvestor = data;
         this.globalVar.userPanCard =this.globalVar.userDetailFromGetInvestor[0].vcClientPANNo;
         this.globalVar.setUserId(this.globalVar.userDetailFromGetInvestor[0].inUserId);
         this.globalVar.userId = this.globalVar.userDetailFromGetInvestor[0].inUserId;
         this.globalVar.set_mutual_fund_authories(true)
          if (this.pages[index].status) {
            this.pages[index].status = false
          }
          else {
            for (let i = 0; i < this.pages.length; i++) {
              if (i == index) {
                this.pages[index].status = true
              }
              else {
                this.pages[i].status = false
              }
            }
          }
      }else {
        swal({
          title: 'OOPS!',
          text: "Access to this module has not been activated, Kindly contact Administrator !!!",
          type: "error"
        });
      }
    });
    }
    else {
      if (this.pages[index].status) {
        this.pages[index].status = false
      }
      else {
        for (let i = 0; i < this.pages.length; i++) {
          if (i == index) {
            this.pages[index].status = true
          }
          else {
            this.pages[i].status = false
          }
        }
      }
    }
  }




  // getToken() {

  //   this.getReportManager.getHoldingReportForMwatch().then((data) => {

  //     let holdings_result: any = data;
  //     let holdingItems = [];
  //     if (holdings_result.reportTable == "" || holdings_result.reportTable == null) {
  //     } else {
  //       holdingItems = JSON.parse(holdings_result.reportTable);
  //       this.globalVar.setHoldingReport(holdingItems);
  //     }

  //   }, err => {

  //   });
  // }

}