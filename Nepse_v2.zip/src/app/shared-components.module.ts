//---All the common shared section will be imported from here.
//--Like comon footer,quote header etc throughout in the app.

import {NgModule} from '@angular/core';
import {IonicPageModule} from 'ionic-angular';
import {quoteHeaderPage} from '../controller/quote-header/quote-header';
import { FooterPage } from '../controller/footer/footer';
import { HeatMapDirective } from '../directives/heat-map/heat-map';
import { BidAskHighlighterDirective } from '../directives/bidaskhighlighter/bidaskhighlighter';
import { CommonScriptInfoPage } from '../controller/common-script-info/common-script-info';
import { ContentDrawerComponent } from '../components/content-drawer/content-drawer';

@NgModule({
  imports: [IonicPageModule.forChild(quoteHeaderPage)],
  declarations: [
    quoteHeaderPage,
    FooterPage,
    HeatMapDirective,
    BidAskHighlighterDirective,
    CommonScriptInfoPage,
    ContentDrawerComponent
    ],
  exports: [quoteHeaderPage,FooterPage,HeatMapDirective,BidAskHighlighterDirective,CommonScriptInfoPage,ContentDrawerComponent]
}) export class SharedModule {}
