import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { Chart } from 'chart.js';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import { PortfolioManagerProvider } from '../../providers/portfolio-manager/portfolio-manager';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { BackButton } from '@scaffold-digital/ionic-hardware-buttons';
import { ChartsModule } from 'ng2-charts';


@IonicPage()
@Component({
  selector: 'page-external-portfolio',
  templateUrl: '../../pages/DionBlack/external-portfolio/external-portfolio.html'
})
export class ExternalPortfolioPage {
  @ViewChild('pieChart') pieChart;
  @ViewChild('barChart') barChart;
  @ViewChild('lineChart') lineChart;

  private   logoutFrmData: any = '';
  private   user_logout_result: any = '';
  public chartDataScheme : any;
  public assetChartData : any;
  shownGroup = null;


  public pieChartEl                : any;
  public barChartEl                : any;
  public lineChartEl               : any;
  public chartLabels               : any    = [];
  public chartValues               : any    = [];
  public chartColours              : any    = [];
  public chartHoverColours         : any    = [];
  public clientName                : any;
  public portfolioSummaryObj       : any;
  private portfolio_summary_Result: any;
  private AssetWiseAllocationObj: any;
  private assetWiseAllocation_Result: any;
  public pieChartDataSchemes: any

  public historicPFObj: any;
  public historicPF_Result: any;
  public folioData: any;
//it has value to disicde which one to display
  public chartType: any;
  public userPan : any;
  public portfolio_assetWise_Result: any;
  private portfolio_Result: any;


//third party validation check result
  public thirdPartyLogin_result: any;
  public showChatType: any;
  public pagelist: any;
  private options: any = {
  legend: { position: 'left' }
}



  constructor(public navCtrl    : NavController,
    public navParams    : NavParams,
    public globalVar    : GlobalVariableService,
    private common      : CommonProvider,
    private portfolioManager: PortfolioManagerProvider,
    private userManager: UserManagerProvider,
    public menu         : MenuController){

      this.showChatType = "asset";
      this.menu.enable(true);
      this.clientName = this.globalVar.clientId;
      // console.log("this.clientName" + this.clientName);
      this.historicPF_Result = [];
      this.portfolio_summary_Result = [];
      this.pieChartDataSchemes = [];
      if(this.globalVar.userDetailFromGetInvestor)
       this.userPan = this.globalVar.userDetailFromGetInvestor[0].vcClientPANNo;

      // this.userPan = this.globalVar.userPanCard;;
      // console.log("this.userPan" + JSON.stringify(this.userPan));
      this.portfolio_assetWise_Result = [];
      this.pieChartDataSchemes = [];
      this.pagelist = [{ text: "Redeem", value: "R" }, { text: "SWP", value: "SWP" }, { text: "Purchase", value: "AP" }, { text: "ISIP", value: "ISIP" }, { text: "XSIP", value: "XSIP" }, { text: "SIP", value: "SIP" },{ text: "Switch", value: "SWITCH" }, { text: "STP", value: "STP" }];

    }

    toggleMenu() {
      this.menu.toggle();
    }

     ionViewWillEnter() {
        this.getPortfolioSummary();
     }


    ionViewDidLoad(){

    }

    gotoformpage(obj, selectedScheme) {

      this.globalVar.setOrderType("FolioOrder");
      if(obj.value == 'R'){
        this.globalVar.isOrderRedeem = true;
        this.globalVar.isOrderSTP = false;
        this.globalVar.isOrderSWP = false;

      } else if(obj.value == 'SWP') {
          this.globalVar.isOrderRedeem = false;
          this.globalVar.isOrderSTP = false;
          this.globalVar.isOrderSWP = true;
      } else if(obj.value == 'STP'){
        this.globalVar.isOrderRedeem = false;
        this.globalVar.isOrderSWP = false;
        this.globalVar.isOrderSTP = true;
      }
        else{
          this.globalVar.isOrderSTP = false;
          this.globalVar.isOrderRedeem = false;
          this.globalVar.isOrderSWP = false;
        }


      // this.navCtrl.push('PortfolioOrderformPage', { inputSchemeObj: selectedScheme, PlaceOrderObj: selectedScheme, tag: obj });
      this.navCtrl.push('FolioOrderPage', { inputSchemeObj: selectedScheme, PlaceOrderObj: selectedScheme, tag: obj });
    }

    @BackButton()
    public onBackButton() {
      // alert("back called");
      // this.common.logout();
    }

    segmentChanged($event){
      // console.log($event.value)
      if(this.pieChartEl)
      this.pieChartEl.destroy();
      this.makeChart();
    }

    getPortfolioSummary(){

      // ReportName : 'PortfolioDashboard' changed to mobileDashboard to handle the things for mobile differently than of mobi
      this.portfolioSummaryObj = {
        AsOn : '',
        PANNo :this.userPan,
        ReportName : 'CASStatement',
        ResponseType : "2",
      }

      this.common.showLoading();

      this.portfolioManager.getExternalPortPolio(this.portfolioSummaryObj).then((data) => {
        this.common.hideLoading();

        this.portfolio_Result = data;
        // this.globalVar.setAllocationObj(this.portfolio_Result);
console.log("ExtApi Data",this.portfolio_Result);

        if (this.portfolio_Result.ErrorCode == '0') {
        this.folioData = data;
        console.log("this.folioData Data : ",this.folioData)
        if(this.portfolio_Result.ReportTable4 != null && this.historicPF_Result != null){
          this.portfolio_summary_Result = this.portfolio_Result.ReportTable;
          console.log("this.portfolio_summary_Result Data : ",this.portfolio_summary_Result);

          this.historicPF_Result = this.portfolio_Result.ReportTable2[0];
          this.pieChartDataSchemes = [];
           this.makeChart();
        }
      }
       else{
        this.common.hideLoading();
      }

      },(err) =>{
        // console.log("err" + err)
        swal({
          title: 'OOPS!',
          text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
          type: "error"
        });
        this.common.hideLoading();
      })

    }



    getProfile(){
      this.navCtrl.push('UserProfilePage');
      // this.common.getProfileImage();
    }

    makeChart(){
      if(this.showChatType == 'asset' ){
          this.pieChartDataSchemes = this.portfolio_Result.ReportTable3;

      } else if(this.showChatType == 'amc'){
          this.pieChartDataSchemes = this.portfolio_Result.ReportTable4;

      }else if(this.showChatType == 'sector'){
          this.pieChartDataSchemes = this.portfolio_Result.ReportTable7;

      }

      var colorArray = ['248488','C0C0C0', 'FF0000', '4D8439', 'D1A65D', '248488']

      if(this.pieChartDataSchemes.length>0){
        console.log("pieChartDataSchemes",this.pieChartDataSchemes);
        
          this.chartDataScheme = [];
      for(let i =0; i <this.pieChartDataSchemes.length; i++){

        if(this.showChatType == 'asset'){
          this.chartDataScheme.push({
            'name' : this.pieChartDataSchemes[i].AssetName,
            'value'      : this.pieChartDataSchemes[i].AllocationAmt,
            'color'      : '#'+colorArray[i],
            'hover'      : 'rgba(199, 108, 129, 0.5)'
          })

        } else if (this.showChatType == 'amc'){
          this.chartDataScheme.push({
            'name' : this.pieChartDataSchemes[i].AMCName,
            'value'      : this.pieChartDataSchemes[i].AllocationAmt,
            'color'      : '#'+colorArray[i],
            'hover'      : 'rgba(199, 108, 129, 0.5)'
          })

        } else if (this.showChatType == 'sector'){
          this.chartDataScheme.push({
            'name'       : this.pieChartDataSchemes[i].SectorName,
            'value'      : this.pieChartDataSchemes[i].Allocation,
            'color'      : '#'+colorArray[i],
            'hover'      : 'rgba(199, 108, 129, 0.5)'
          })
        }

        // console.log("chartDataScheme" + JSON.stringify(this.chartDataScheme));
        this.assetChartData = {
          "assetChartData" : this.chartDataScheme}
      }

      this.defineChartData();
      this.createPieChart();
    }

    }


goToSchemeDetail(obj){
  // start fr
  this.navCtrl.push('SchemePerformanceChartPage', { selectedSchemeDetail: obj });
}

    // ADLPA3454G
    getHistoricalPFDetail(){
      this.historicPFObj = {
        AsOn : '2018/10/28',
        PANNo : this.userPan,
        ReportName : 'MFStatement',
        ResponseType : "2",
      }

      this.common.showLoading();
      var historicPFObj_Result: any;
      this.portfolioManager.FundBossDownloadReport((this.historicPFObj)).then((data) => {
        historicPFObj_Result = data;
        // this.globalVar.setAllocationObj(historicPFObj_Result);

        this.common.hideLoading();
          if (historicPFObj_Result.ErrorCode == '0') {
          this.historicPF_Result = historicPFObj_Result.ReportTable2[0];


          if(this.showChatType == 'asset' ){
              this.pieChartDataSchemes = historicPFObj_Result.ReportTable1;

          } else if(this.showChatType == 'amc'){
              this.pieChartDataSchemes = historicPFObj_Result.ReportTable2;

          } else if(this.showChatType == 'sector'){
              this.pieChartDataSchemes = historicPFObj_Result.ReportTable3;
          }

          // chartDataScheme
          var colorArray = ['248488','C0C0C0', 'FF0000', '4D8439', 'D1A65D', '248488']

          if(this.pieChartDataSchemes != null){
              this.chartDataScheme = [];
          for(let i =0; i <this.pieChartDataSchemes.length; i++){

            if(this.showChatType == 'asset'){
              this.chartDataScheme.push({
                'name' : this.pieChartDataSchemes[i].AssetName,
                'value'      : this.pieChartDataSchemes[i].Allocation,
                'color'      : '#'+colorArray[i],
                'hover'      : 'rgba(199, 108, 129, 0.5)'
              })

            } else if (this.showChatType == 'amc'){
              this.chartDataScheme.push({
                'name' : this.pieChartDataSchemes[i].AMCName,
                'value'      : this.pieChartDataSchemes[i].Allocation,
                'color'      : '#'+colorArray[i],
                'hover'      : 'rgba(199, 108, 129, 0.5)'
              })

            } else if (this.showChatType == 'sector'){
              this.chartDataScheme.push({
                'name' : this.pieChartDataSchemes[i].SectorName,
                'value'      : this.pieChartDataSchemes[i].Allocation,
                'color'      : '#'+colorArray[i],
                'hover'      : 'rgba(199, 108, 129, 0.5)'
              })

            }

            // console.log("chartDataScheme" + JSON.stringify(this.chartDataScheme));

            this.assetChartData = {
              "assetChartData" : this.chartDataScheme}
          }

          this.defineChartData();
          this.createPieChart();
        //  console.log("this.historicPF_Result"+ JSON.stringify(this.historicPF_Result));
          this.getPortfolioSummary();
        }
      }
        else{
            this.historicPF_Result = [];
        }
      },(err) =>{
        // console.log("err" + err)
        swal({
          title: 'OOPS!',
          text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
          type: "error"
        });
        this.common.hideLoading();
      })
    }


    toggleGroup(group) {
    if (this.isGroupShown(group)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = group;
    }
    };


    isGroupShown(group) {
    return this.shownGroup === group;
    };


    AssetWiseAllocation(){
      this.AssetWiseAllocationObj = {
        PANNo : this.userPan,
        ReportName : 'AssetWiseAllocation',
        ResponseType : "2",
      }
      // this.common.showLoading();
      var assetWiseAllocation_Result: any;
      this.portfolioManager.FundBossDownloadReport((this.AssetWiseAllocationObj)).then((data) => {
        this.common.hideLoading();
        assetWiseAllocation_Result = data;
        if (assetWiseAllocation_Result.ErrorCode == '0') {
        this.portfolio_assetWise_Result = assetWiseAllocation_Result.ReportTable;
        this.portfolio_assetWise_Result = assetWiseAllocation_Result;
      //  console.log("this.portfolio_summary_Result"+ JSON.stringify(this.portfolio_assetWise_Result));

        // this.pieChartDataSchemes = assetWiseAllocation_Result.ReportTable3;
        //
        // // chartDataScheme
        // var colorArray = ['248488','C0C0C0', 'FF0000', '4D8439', 'D1A65D', '248488']
        //
        // if(this.pieChartDataSchemes != null){
        //     this.chartDataScheme = [];
        // for(let i =0; i <this.pieChartDataSchemes.length; i++){
        //
        //   this.chartDataScheme.push({
        //     'name' : this.pieChartDataSchemes[i].SchemeClassDescription,
        //     'value'      : this.pieChartDataSchemes[i].PresentValuePercentage,
        //     'color'      : '#'+colorArray[i],
        //     'hover'      : 'rgba(199, 108, 129, 0.5)'
        //   })
        //
        //   console.log("chartDataScheme" + JSON.stringify(this.chartDataScheme));
        //
        //   this.assetChartData = {
        //     "assetChartData" : this.chartDataScheme}
        // }
        //
        // this.defineChartData();
        // this.createPieChart();
      }


     else{
      this.common.hideLoading();
    }

      },(err) =>{
        this.common.hideLoading();
        swal({
          title: 'OOPS!',
          text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
          type: "error"
        });
        // this.common.hideLoading();
      })
    }

    defineChartData()
    {
      let k : any;
      this.chartLabels = [];
      this.chartValues = [];
      this.chartColours = [];
      this.chartHoverColours = [];
if(this.assetChartData.assetChartData !=undefined){
      for(k in this.assetChartData.assetChartData)
      {
        var asset = this.assetChartData.assetChartData[k];
        this.chartLabels.push(asset.name);
        this.chartValues.push(asset.value);
        this.chartColours.push(asset.color);
        this.chartHoverColours.push(asset.hover);
      }
    }
    }




    createPieChart()
    {

      this.common.hideLoading();
      let showme:boolean=false;
if(this.showChatType == 'asset')
showme=true
else
showme=false

      this.pieChartEl	= new Chart(this.pieChart.nativeElement,
        {
          type: 'doughnut',
          data: {
            labels: this.chartLabels,
            datasets: [{
              label                 : '',
              data                  : this.chartValues,
              duration              : 1000,
              easing                : 'easeInQuart',
              backgroundColor       : this.chartColours,
              // hoverBackgroundColor  : this.chartHoverColours
            }]
          },
          options : {
            maintainAspectRatio: false,
            responsive: true,
            showTooltips: true,
            tooltipCaretSize: 0,
            legend: {
              display: showme,
              labels: {
                padding: 3,
                position : 'left',
                fontFamily: 'Helvetica',
              }
            },
            animation: {
              duration : 500
            }
          }
        });

        this.common.hideLoading();

      }

      goToFolioDetail(obj){
        // console.log("folioData"+ JSON.stringify(this.folioData));
          this.navCtrl.push('FolioReportPage', { selectedFolioObject: obj, folioReportData: this.folioData, folioHistory: this.historicPF_Result });

      }

      openCart(){
        console.log("open cart");
        this.navCtrl.push('CartPage');
      }

      OpenFollio(data)
      {
        this.navCtrl.push('ExternalPortfolioDetailsPage',{follio_data:this.folioData,current_obj:data})
      }
    }
