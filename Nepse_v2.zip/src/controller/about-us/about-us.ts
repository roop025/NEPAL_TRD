import { Component } from '@angular/core';
import { NavController , IonicPage } from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { Storage } from '@ionic/storage';
// import  data  from  '../../assets/DionBlack/contactInfo.json';

declare var require:any

@IonicPage()
@Component({
  selector: 'page-aboutus',
  templateUrl: '../../pages/DionWhite/about-us/about-us.html'
})

export class AboutUsPage { 
  public setName : any;
  public ClientName : any;
  private logoutFrmData : any;
  private   user_logout_result: any = '';
  public userData : any;
  public activeClientData:any;

  constructor(
    public navCtrl: NavController,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private storage:Storage,
    ) {

    this.ClientName = globalVar.clientName;
    // this.activeClient = globalVar.getActiveClientData(globalVar.activeClient);

  }

  ionViewDidLoad(){
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
    });
  }

  ngOnInit(){
    this.activeClientData = require("../../assets/DionWhite/contactInfo.json");
    debugger
    // this.activeClientData = data
  }

}
