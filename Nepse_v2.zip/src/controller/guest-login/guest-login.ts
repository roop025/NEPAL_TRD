import { Component ,ViewChild,ElementRef } from '@angular/core';
import {IonicPage, NavController, NavParams,MenuController , Events  ,Platform} from 'ionic-angular';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { CommonProvider } from '../../providers/common/common';
import { AppUpdateProvider } from '../../providers/app-update/app-update';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { HttpClient } from '@angular/common/http';
// import  data  from  '../../assets/DionBlack/contactInfo.json';


declare var require:any


@IonicPage()
@Component({
  selector: 'page-guest-login',
  templateUrl: '../../pages/DionWhite/guest-login/guest-login.html'
})

export class GuestLogin {
  @ViewChild("userIdField") public userIdField: ElementRef;
  @ViewChild("userPasswordField") public userPasswordField: ElementRef;
  @ViewChild("userTradePasswordField") public userTradePasswordField: ElementRef;
  public ClientName : any;
  private guestloginFrmData:any;
  private termsAndConditionData:any;
  public result:any;
  public user_login_result:any;
  public userMasterData:any;
  public user_tradePassword_result:any;
  public user_IP_result:any;
  public ipVal:any;
  public appDetail:any;
  public user_appUpdate_result:any;
  public showPassword:any;
  public showTradePassword:any;
  public googleAppLink:string = 'https://play.google.com/store/apps/details?id='
  public activeClientData:any;


  constructor(public navCtrl: NavController,
    public platform: Platform,
    public globalVar:GlobalVariableService,
    public navParams: NavParams,
    private userManager:UserManagerProvider,
    private common:CommonProvider,
    private storage:Storage,
    private appUpdateManager : AppUpdateProvider,
    private ev:Events,
    public http: HttpClient,
    private menu: MenuController) {
    //console.log(globalVar.clientName)
    this.menu.enable(false);
    this.ClientName = globalVar.clientName;
    // this.activeClient = globalVar.getActiveClientData(globalVar.activeClient);


    this.guestloginFrmData = {
      userId:'', //ka00458 test003 mobcli01
      password:'',//kite444  kite111 pass2222 new123(mb30)
      Source:5,
      Action:'LOGIN',
      TradePassword:'',//kite555 test@1234 123 password2
      NewPassword:'',
      ClientIPAddress:'',
      SessionNo:'',
      PAN:'',
      ValidateThrough:'U',
      DPID:''
      // userId:'', // ankitcli2
      // password:'password0',//kite111 password1 password0(mobcli03)
      // Source:5,
      // Action:'LOGIN',
      // TradePassword:'123',//kite222 password0 123(mobcli03)
      // NewPassword:'',
      // ClientIPAddress:'',
      // SessionNo:'',
      // PAN:'',
      // ValidateThrough:'U',
      // DPID:''

    };
    //this.termsAndConditionData = {checkedData :true}
    //---Setting userId of last successfull logged in user by default.
    // this.storage.get("userLoginId").then((data)=>{
    //     if(data!=null && data!=''){
    //       this.guestloginFrmData.userId = data;
    //     }else{
    //       this.guestloginFrmData.userId = '';
    //     }
    // });
    // this.ev.subscribe('checkUserMasterLoginId',data=>{
    //   this.storage.get("userLoginId").then((data)=>{
    //     this.guestloginFrmData.userId = data;
    //   });
    // });

    ///---Check app version ---
    //this.aapVersionDetail();
    //-----
    this.showPassword=false
    this.showTradePassword=false
  }

  ngOnInit(){
    this.activeClientData = require("../../assets/DionBlack/contactInfo.json");
    // this.activeClientData = data
  }

  ionViewDidLoad(){
    //console.log("test from login",this.termsAndConditionData)
    this.getIp();
  }
  getIp(){
    // this.userManager.getIPAddress().then((data)=>{
    //   this.user_IP_result = data;
    //   console.log("this.user_IP_result",this.user_IP_result)
    //   this.globalVar.setUserIP({ip:this.user_IP_result.ip});
    // }, err=> {
    //
    // });
    this.http.get('https://api.ipify.org?format=json').subscribe(data => {
      this.ipVal=data
      this.globalVar.setUserIP({ip:this.ipVal.ip});
    });

  }



  loginFrmSubmit(){
    if(this.guestloginFrmData.userId==''){
      swal({
          text: "Please Enter Mobile No",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.userIdField;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.userIdField;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.guestloginFrmData.password==''){
      swal({
          text: "Please Enter Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.userPasswordField;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.userPasswordField;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else{
      var randomNumber = Math.floor((Math.random() * 1000) + 1);
      this.guestloginFrmData.ClientIPAddress = randomNumber;
      this.common.showLoading();
      this.userManager.guestlogin(this.guestloginFrmData).then((data)=>{
        this.user_login_result = data;
        this.common.hideLoading();
        //----Successfully login ---
        if(this.user_login_result.ErrorCode == '0'){
            this.user_login_result.guestLogin=true
            //---After successful login store the userId in the localStorage so that user does not need to enter again--
            // this.storage.set("userLoginId",this.guestloginFrmData.userId).then(()=>{
            //     this.ev.publish('checkUserMasterLoginId',this.guestloginFrmData.userId);
            // });
            this.storage.set("userMaster",this.user_login_result).then(()=>{
                this.ev.publish('checkUserMasterData',this.user_login_result);
            });
            this.globalVar.setUserData({uData:this.user_login_result});
            this.navCtrl.push('HomePage');
            swal({
             title: "Login Successful",
             text: this.user_login_result.Message,
             type: "success",
             timer:5000
           });
          //console.log("this.user_login_result",this.user_login_result);
          //---validate trade password based on the client ---
          // if(
          // this.ClientName === 'Canara' || this.ClientName === 'Ratnakar' || this.ClientName === 'Marfatia' || this.ClientName === 'Dion' ||
          // this.ClientName === 'Bhumika' || this.ClientName === 'Asnani' || this.ClientName === 'MTradez' || this.ClientName === 'Ajcon' || this.ClientName === 'Achiievers' ||
          // this.ClientName === 'ATS' || this.ClientName === 'CDTrade' || this.ClientName === 'SCHIL'){
          //   //---Call for the validate trade password service --
          //   this.validateTradePassword();
          //   //---After successful login store the userId in the localStorage so that user does not need to enter again--
          //   this.storage.set("userLoginId",this.guestloginFrmData.userId).then(()=>{
          //       this.ev.publish('checkUserMasterLoginId',this.guestloginFrmData.userId);
          //   });
          // }else{
          //   this.storage.set("userMaster",this.user_login_result).then(()=>{
          //       this.ev.publish('checkUserMasterData',this.user_login_result);
          //       this.navCtrl.push('DashboardPage');
          //       swal({
          //           title: "Login Successful",
          //           text: this.user_login_result.Message,
          //           type: "success"
          //       });
          //   });
          // }
        }
        else if(this.user_login_result.ErrorCode == '-1008015'){ //---Login successfully but password expired--
          swal({
              title: 'Password Expired',
              text: this.user_login_result.Message,
              type: "warning"
          });
          this.navCtrl.push('ChangePasswordFirstPage',{useLogindata:this.user_login_result,userPassword:this.guestloginFrmData.password});
        }
        else if(this.user_login_result.ErrorCode == ''){//---network connection error ---
          swal({
              title: 'Connection Error',
              text: 'Data Network Error',
              // type: "error"
          });
        }else{//----User does not able to login --
          swal({
              //title: "OOPS!",
              text: this.user_login_result.Message,
              // type: "error"
          });
        }
      }, err=> {
        swal({
            //title: 'OOPS!',
            text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
            // type: "error"
        });
        this.common.hideLoading();
      });
    }
  }

  //---Trade password validation ---
  validateTradePassword(){
    var randomNumber = Math.floor((Math.random() * 1000) + 1);
    this.guestloginFrmData.ClientIPAddress = randomNumber;
    this.guestloginFrmData.SessionNo = this.user_login_result.SessionNo;
    this.common.showLoading();
    this.userManager.validateTradePassword(this.guestloginFrmData).then((data)=>{
      this.user_tradePassword_result = data;
      this.common.hideLoading();
      //----Successfully login ---
      if(this.user_tradePassword_result.ErrorCode == '0'){
        //console.log("this.user_tradePassword_result",this.user_tradePassword_result);
        //---validate trade password based on the client ---
        this.storage.set("userMaster",this.user_login_result).then(()=>{
            this.ev.publish('checkUserMasterData',this.user_login_result);
        });
        this.globalVar.setUserData({uData:this.user_login_result});
        if (this.ClientName === 'Canmoney') {
            this.navCtrl.push('DashboardPage');
        } else if (this.ClientName === 'Bhumika' || this.ClientName === 'Ratnakar' || this.ClientName === 'SCHIL') {
            this.navCtrl.push('DashboardPage');
        } else if (this.ClientName === 'Jetrade')
        {
            // call themarket watch  page at the time of second login
            this.navCtrl.push('DashboardPage');
        }else if(this.ClientName === 'MTradez' || this.ClientName === 'Ajcon' || this.ClientName === 'Canara'){
          this.navCtrl.push('HomePage');
        }
        else {
            //--Open market watch --
            this.navCtrl.push('MarketWatchPage',{useLogindata:this.user_login_result});
         }
         swal({
             title: "Login Successful",
             text: this.user_login_result.Message,
             type: "success",
             timer:5000
         });
      }else{//----User does not able to validate the trade password --
        swal({
            //title: "OOPS!",
            text: this.user_tradePassword_result.Message,
            // type: "error"
        });

      }
    }, err=> {
      this.common.hideLoading();
    });
  }





    //----Hide show password function --\
    hideShowPassword(){
      this.showPassword = !this.showPassword;
    }

    //----Forgot Password Page ---ForgotPasswordPage
    forgotPasswordPage(){
      this.navCtrl.push('ForgotPasswordPage',{useLogindata:this.guestloginFrmData});
    }
    guestRegistration(){
      this.navCtrl.push('GuestRegistrationPage');
    }

  }
