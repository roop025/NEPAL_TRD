import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GuestLogin } from './guest-login';

@NgModule({
  declarations: [
    GuestLogin,
  ],
  imports: [
    IonicPageModule.forChild(GuestLogin),
  ],
})
export class guestLoginPageModule {}
