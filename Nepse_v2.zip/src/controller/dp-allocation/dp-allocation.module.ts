import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DpAllocationPage } from './dp-allocation';
import {PipesModule} from '../../pipes/pipes.module';
import { NgProgressModule } from 'ngx-progressbar';

@NgModule({
  declarations: [
    DpAllocationPage,
  ],
  imports: [
    PipesModule,
    NgProgressModule,
    IonicPageModule.forChild(DpAllocationPage),
  ],
})
export class DpAllocationPageModule {}
