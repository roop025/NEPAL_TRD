import { Component, ɵConsole } from '@angular/core';
import { NavController , IonicPage,NavParams ,ModalController} from 'ionic-angular';
import { AddScripProvider } from '../../providers/add-scrip/add-scrip';
import swal from 'sweetalert2';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { ReportProvider } from '../../providers/report/report';
import { Storage } from '@ionic/storage';
// import { OrderbyPipe } from '../../pipes/orderBy/orderBy';
import { NgProgress } from 'ngx-progressbar';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';

@IonicPage()
@Component({
  selector: 'page-dpAllocation',
  templateUrl: '../../pages/DionWhite/dp-allocation/dp-allocation.html'
})

export class DpAllocationPage {
  //public setName : any;
  public searchStr : any;
  public classE : any;
  public classCu : any;
  public classC : any;
  public Equity : any;
  public Commodity : any;
  public Currency : any;
  public CClick : any;
  public EClick : any;
  public CuClick : any;
  public scripList : any;
  public tmpscripList : any;
  public MonthOne : any;
  public MonthTwo : any;
  public MonthThree : any;
  public showFutureData : any;
  public showOptionData : any;
  public showSpreadData : any;
  public showSpotData : any;
  public isFandO : any;
  public user_search_result : any;
  public exchangeList : any;
  //public tempSearch : any;
  public showScripList : any;
  public shownGroup : any;
  public selectedScrip : any;
  public optionButton : any;
  public selectedOptionType : any;
  public selected : any;
  public shownExpiry : any;
  public selectedExpiry : any;
  public rangeData : any;
  public InstrumentType : any;
  public user_expiryDate_result : any;
  public scripSetExpiry : any;
  public selectedExpiryVal : any;
  public selectedDate : any;
  public user_expiryDate_result_option : any;
  public strikePriceList_result : any;
  public strikePriceList : any;
  public getSelectedSrip_result : any;
  public singleScrip : any;
  public watchListAddItem : any;
  public userData : any;
  public getSpecified_quote_result : any;
  public singleScrip_quote : any;
  public spreadType : any;
  public scripExistsinWL : any;
  public progressBarColor : any;
  public ClientName : any;
  public WatchlistName : any;
  public user_marketSave_result : any;
  //public order : any = 'ID';
  //public ascending : any = true;




  constructor(public navCtrl: NavController,
    private addScripManager:AddScripProvider,
    private clientMarketWatchList : GlobalVariableService,
    private storage:Storage,
    public navParams: NavParams,
    private marketWatchManager:MarketWatchProvider,
    public getReportManager : ReportProvider,
    public modalCtrl: ModalController,
    public ngProgress: NgProgress) {
    this.progressBarColor = 'white'
    this.searchStr ='';
    this.classE = "dark";
    this.classCu = "";
    this.classC = "";
    this.Equity = false;
    this.Commodity = true;
    this.Currency = true;
    this.EClick = '1'
    this.CuClick = '1'
    this.CClick = '1'
    this.showScripList = false
    //---CAlling of option button --
    this.optionButton = [{
            'Id': 1,
            'type': 'CE',
            'buttonName': 'CALL',
        },
        {
            'Id': 2,
            'type': 'PE',
            'buttonName': 'PUT',
        }
    ];
    //--------------------------
    this.selectedOptionType = this.optionButton[0].type;
    this.selected = 0;
    this.selectedDate = 0;
    this.singleScrip = {};
    //--range and expiry section default value --
    this.selectedExpiry = "1-MON";
    this.rangeData = {min: 0,max: 0,value: 0,step: 0,selectedStrikePrice:''};
    this.watchListAddItem = this.clientMarketWatchList.getData();
    // console.log("In add scrip page -->",this.watchListAddItem.watchlistItems)
    //---get the user login data --
    this.storage.get("userMaster").then((data)=>{
         this.userData = data;
        // console.log("this.userData",this.userData)
    });
    this.ClientName = clientMarketWatchList.clientName;
    this.WatchlistName=this.navParams.get('currentMarketWatch');
    //console.log("this.WatchlistName",this.WatchlistName)
  }

  ionViewDidLoad(){
    //console.log("test from login")
    //console.log("In add scrip page -->",this.clientMarketWatchList.getData())

  }
  //---Search input field function fired --
  onInput(event){
    setTimeout(() => {
    this.getSearchResults();
    },1000);
  }
  //--more option button click --
  select(index) {
      this.selected = index;
      //console.log("this.selected",this.selected)
  }
 
 
  
  //----search crip function ---
  getSearchResults() {
      this.scripList = [];
      if(this.searchStr == undefined || this.searchStr.trim() == ''){
        return;
      }
      //this.scripList.deleteContents();
      this.tmpscripList = {};

      var exchangeCount = 0;
      this.exchangeList = [];

      //set parameters, count of queries and exchange set

          this.progressBarColor = 'white'
          this.ngProgress.start();
          this.getReportManager.getDpHoldingReport(this.searchStr).then((data)=>{
            this.ngProgress.done();
            this.user_search_result = data;
            //console.log("this.user_search_result",this.user_search_result)
            //----Successfully loaded search result list ---
            if(this.user_search_result.reportTable == "" || this.user_search_result.reportTable == null){
              //---do nothing
                this.showScripList = false;

          }
          else{
            this.showScripList = true;
            this.scripList = JSON.parse(this.user_search_result.reportTable);
           // console.log(this.scripList);
          }
          }, err=> {
            // this.common.hideLoading();
            swal({
                    // title: "Error!",
                    text: "Something went wrong.",
                    timer: 2000,
                    showConfirmButton: false,
                    allowOutsideClick: true
                });
          });
          // console.log("this.exchangeList[i]",this.exchangeList[i])
  }
  //---Toggling of scrip section--
    toggleGroup (group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
        } else {
            //this.getScripRate(group);
            this.shownGroup = group;
        }
    }
    isGroupShown(group) {
        return this.shownGroup === group;
    }



    holdValue(obj){
        //console.log(obj);
        this.navCtrl.push('DpHoldReportPage',{"holdObj":obj},null);
    }
}
