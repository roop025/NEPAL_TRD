import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BitsotPage } from './bitsot';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    BitsotPage,
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(BitsotPage),
  ],
})
export class BitsotPageModule {}
