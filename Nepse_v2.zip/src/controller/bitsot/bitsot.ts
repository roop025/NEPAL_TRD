import { Component } from '@angular/core';
import { NavController, IonicPage, Events } from 'ionic-angular';
import { ReportProvider } from '../../providers/report/report';
import { Storage } from '@ionic/storage';
import swal from 'sweetalert2';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { BuySellProvider } from "../../providers/buy-sell/buy-sell";
import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';

@IonicPage()
@Component({
    selector: 'page-bitsot',
    templateUrl: '../../pages/DionWhite/bitsot/bitsot.html'
})

export class BitsotPage {
    // public setName : any;
    public orderReport_result: any;
    public items: any;
    public message: any;
    public userData: any;
    public spreadType: any;
    public progressBarColor: any;
    public cancelOrderObject: any;
    public inProcessOrder: any;
    public cancel_order_result: any;
    private filterargs: any;
    private ClientName: any;
    private logoutFrmData: any;
    private user_logout_result: any = '';

    shownGroup = null;
    public totalMarketValue: any = 0.00;
    public negativeVal: any;


    constructor(
        public navCtrl: NavController,
        public getReportManager: ReportProvider,
        private storage: Storage,
        public ngProgress: NgProgress,
        private globalVariableService: GlobalVariableService,
        private ev: Events,
        public buySellManager: BuySellProvider,
        private common: CommonProvider,
        private userManager: UserManagerProvider,
    ) {
        this.progressBarColor = 'white';
        this.inProcessOrder = false;
        this.ev.subscribe('checkFilterArgument', data => {
            //alert(data.indexSel)
            if (data.indexSel == "Exchange") {
                this.filterargs = { exchange: data.valueSel };
            } else if (data.indexSel == "Scrip") {
                this.filterargs = { underlying: data.valueSel };
            } else if (data.indexSel == "TradingAccount") {
                this.filterargs = { TradingAccount: data.valueSel };
            } else if (data.indexSel == "Status") {
                this.filterargs = { OrderStatus: data.valueSel };
            } else if (data.indexSel == "BuySellType") {
                this.filterargs = { BuySellType: data.valueSel };
            }
            else {
                this.filterargs = { all: data.valueSel };
            }
        });
        //---Set page name as orderbook--
        this.globalVariableService.setPageName({ currentPageName: "BitsotPage" });
        this.ClientName = globalVariableService.clientName;
    }

    ionViewDidLoad() {
        //console.log("test from login")
        this.storage.get("userMaster").then((data) => {
            if (data != null && data != '') {
                this.userData = data;
            }
            this.loadBitsotDetails();
        });
    }

    //--- Service to call bitsot feed --
    loadBitsotDetails() {
        this.progressBarColor = 'white'
        this.ngProgress.start();
        this.getReportManager.getScripOrderReport("ALL", "Obligation", this.userData, "").then((data) => {
            this.ngProgress.done();
            this.orderReport_result = data;
            if (this.orderReport_result.reportTable == "" || this.orderReport_result.reportTable == null) {
                this.items = '';
                this.message = this.orderReport_result.Message
                console.log(this.message);

            } else {

                this.items = JSON.parse(this.orderReport_result.reportTable);
                var len = this.items.length
                for (var i = 0; i < len; i++) {

                    let marketValue: any = parseFloat(this.items[i].MarketValue);
                    this.totalMarketValue = (this.totalMarketValue + marketValue);

                    if (this.items[i].Exchange == "NSE") {
                        this.items[i]['source'] = "OBN";
                    } else {
                        this.items[i]['source'] = "OBB"
                    }
                }

            }
        }, err => {
            swal({
                title: "Error!",
                text: "Network Issue...",
                timer: 3000,
                showConfirmButton: false
            });
            this.progressBarColor = 'Red'
            this.ngProgress.done();
        });
    }



    NSESell(item) {
        if (item.AvailableQuantity > 0) {
            //---Allow to sell in NSE market when available quantity is present--
            item.ticker = item.Scrip;
            item.exchange = item.Exchange;
            item.totalQtyToSell = Number(item.AvailableQuantity)
            this.globalVariableService.setQuoteHeaderData({ quoteItem: item });
            this.navCtrl.push('SellPage', { usersellData: item, clientUserData: this.userData, fromObligations: true,userOBligationData:item });
        } else {
            //--Does not allow--
            swal({
                title: "Error!",
                text: "You does not have available qyantity for sell",
                type: 'info',
                timer: 3000,
                showConfirmButton: false
            });
        }
    }

    totalCounts(data) {
        let total = 0.00;
        data.forEach((d) => {
            total += parseFloat(d.MarketValue);
        });
        return total;
    }


    //---//--pull down to refresh --
    doRefresh(refresher) {
        this.loadBitsotDetails()
        setTimeout(() => {
            refresher.complete();
        }, 1000);
    }


    toggleGroup(group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
          //  console.log(group)

        } else {
            this.shownGroup = group;

        }
    };
    isGroupShown(group) {
        return this.shownGroup === group;

    };

}
