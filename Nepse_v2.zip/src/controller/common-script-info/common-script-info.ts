import { Component, Input, ElementRef, Renderer,ChangeDetectorRef,OnInit } from '@angular/core';
import {IonicPage,Events,NavController,NavParams} from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { NgProgress } from 'ngx-progressbar';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';

import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { json } from 'd3';



// @IonicPage()
@Component({
  selector: 'common-script-info',
  templateUrl: '../../pages/DionWhite/common-script-info/common-script-info.html'
})
export class CommonScriptInfoPage implements OnInit{

    private footerTickerData : any;
    private tickerList : any;
    private ticker_result : any;
    private spreadType : any;
    private keylist : any;
    //private footer_webSocket_Data : any;
    private hideFilterButton : any;
    private hideGridButton : any;
    private ClientName : any;
    private user_Choice_result : any;
    public sensaxData ={
        ticker:'',
        Change:'',
        LTP:''
    };
    public niftyData ={
        ticker:'',
        Change:'',
        LTP:''
    };
  
    constructor(
      public navCtrl: NavController,
      // private common:CommonProvider,
      private marketWatchManager:MarketWatchProvider,
      public socket: WebsocketProvider,
      private storage:Storage,
      private ev:Events,
      private globalVar : GlobalVariableService,
      public ref: ChangeDetectorRef,
      public websocketUtilityManager: WebsocketUtilityService,
    //   public modalCtrl: ModalController
      ) {
        this.getFooterIndices();
        this.hideFilterButton=false
        this.hideGridButton=false
        this.user_Choice_result=true
       
        this.ClientName = globalVar.clientName;
        this.sensaxData.ticker = '';
        this.sensaxData.Change = '';
        this.sensaxData.LTP = '';

        this.niftyData.ticker = '';
        this.niftyData.Change = '';
        this.niftyData.LTP = '';
  
        //---Hide grid button on everypage except the market watch page --
       
    }
  
    ionViewDidLoad(){
        // this.getFooterIndices();
        // setTimeout(() => {
        // window.location.reload();
        // this.getFooterIndices();
        // // console.log('Reload commmon...')
        // }, 1000);


    }

    ngOnInit(): void{
        this.getFooterIndices();
    }
    //---Set the local storage value to toggle between grid view and list view..
    showGridView(){
      this.storage.set("userMarketWatchGridView",this.user_Choice_result).then(()=>{
          this.ev.publish('checkUserMasterViewPreference',this.user_Choice_result);
          this.user_Choice_result=!this.user_Choice_result
      });
    }
    //---service to load the footer scrip ---
    getFooterIndices(){
      this.tickerList = "NEPSE.SENSITIVE^NEPSE.NEPSE";
      var indexData;
      this.marketWatchManager.listTicker(this.tickerList).then((data)=>{
        this.ticker_result = data;
        //----Successfully loaded market watch list ---
        if(this.ticker_result.ErrorCode == '0'){
          this.footerTickerData = JSON.parse(this.ticker_result.data);
          indexData = JSON.parse(this.ticker_result.data);
          for (var temp = 0; temp < indexData.length; temp++) {
              if (indexData[temp].Close == 0 || indexData[temp].Close == '' || indexData[temp].LTP == '' || indexData[temp].LTP == 0) {
                  indexData[temp].Change = 0.00;
              } else if(isNaN((indexData[temp].LTP - indexData[temp].Close) / (indexData[temp].Close))){
                    indexData[temp]['%change'] = 0.00
                } else {
                    indexData[temp].Change = (indexData[temp].LTP - indexData[temp].Close).toFixed(2);
                    this.footerTickerData[temp].Change = indexData[temp].Change;
                    indexData[temp]['%change'] = (indexData[temp].LTP - indexData[temp].Close) / indexData[temp].Close;
                }
            //  else {
            //       indexData[temp].Change = indexData[temp].LTP - indexData[temp].Close;
            //       indexData[temp]['%change'] = (indexData[temp].LTP - indexData[temp].Close) / indexData[temp].Close;
            //   }
          }


          this.globalVar.setFooterData(this.footerTickerData);
          console.log("Indices Data From Server::::::", this.footerTickerData);
          this.sensaxData = this.footerTickerData[1];

          this.niftyData = this.footerTickerData[0];
        
          var scripList = "";
          //var i = 0;
          var counter = 0;
          this.footerTickerData.forEach((marketWatchListItems_Obj, index) => {
              var ScripExchange = marketWatchListItems_Obj.exchange;
              var ticker = marketWatchListItems_Obj.ticker.toUpperCase();
              if (ScripExchange !== '') {
                  scripList = scripList + this.GetExchangeCode(ScripExchange) + '.1!' + ticker.toUpperCase() + '^';
                  counter = counter + 1;
              }
              this.computeScripDetails(marketWatchListItems_Obj, index);
          });
  
          setTimeout(() => {
                this.keylist = 'ADD^' + counter + '^' + scripList;
                //console.log("KeyList from footer-->", this.keylist);
                //---Service to connect with the websocket --
                this.socket.connect();
                // this.socket.send(this.keylist,this.globalVar.WS_FEED_TYPES.DOT_THREE_NOT);
                this.websocketUtilityManager.getFeedAfterSubscribe(this.footerTickerData,'Footer').then(()=>{
                    
                });
          }, 2000);
          
          this.refresh();
        }else{//----Market watch does not loaded--
  
        }
      }, err=> {
        // this.common.hideLoading();
      });
  
    }
    /*set exchange code in order to build keylist to register for feed.*/
    GetExchangeCode(Exchange) {
        var strCode = "0";
        switch (Exchange) {
            case "NSE":
            case "FONSE":
                strCode = "4";
                break;
            case "BSE":
            case "FOBSE":
                strCode = "1";
                break;
            case "ACE":
                strCode = "10";
                break;
            case "CDNSE":
                strCode = "13";
                break;
            case "MCX":
                strCode = "7";
                break;
            case "COMNSE":
                strCode = "5";
                break;
            case "NCDEX":
                strCode = "8";
                break;
            case "MCXSX":
                strCode = "14";
                break;
            case "NSEL":
                strCode = "36";
                break;
            case "MCXSXEQ":
                strCode = "64";
                break;
            case "MCXSXFO":
                strCode = "65";
                break;
            case "CDBSE":
                strCode = "17";
                break;
                case "NEPSE":
                    strCode = "25";
                    break;
        }
        return (strCode);
    }
    //---Get exchange legend ---
    GetExchangeLegend(Exchange) {
        var strCode = "";
        switch (Exchange) {
            case "NSE":
                strCode = "N";
                break;
            case "BSE":
                strCode = "B";
                break;
            case "FOBSE":
                strCode = "B";
                break;
            case "CDBSE":
                strCode = "B, CU";
                break;
            case "FONSE":
                strCode = "N";
                break;
            case "ACE":
                strCode = "A";
                break;
            case "CDNSE":
                strCode = "N, CU";
                break;
            case "MCX":
                strCode = "M";
                break;
            case "NCDEX":
                strCode = "X";
                break;
            case "MCXSX":
                strCode = "M, CU";
                break;
            case "NSEL":
                strCode = "NS";
                break;
            case "MCXSXEQ":
                strCode = "M, EQ";
                break;
            case "MCXSXFO":
                strCode = "M, FO";
                break;
                case "NEPSE":
                    strCode = "NEP";
                    break;
        }
        return (strCode);
    }
    //----Compute script detail---
    computeScripDetails(value, index) {
        var tickertype = 'EQT';
        var ScripExchange = value.exchange;
        var ticker = value.ticker.toUpperCase();
  
        //identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
        if (ticker.search("~") > 0) {
            tickertype = 'FUT';
            if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
                tickertype = 'OPT';
            }
  
            if (ticker.search("~S") > 0) {
                tickertype = 'SPD';
            }
        } else {
            tickertype = 'EQT';
        }
  
        this.footerTickerData[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);
  
        if (tickertype == 'EQT') {
            this.footerTickerData[index].underlying = ticker.toUpperCase();
            this.footerTickerData[index].optType = '';
            this.footerTickerData[index].strikePrice = '';
        }
  
        if (tickertype == 'FUT') {
            this.footerTickerData[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
            this.footerTickerData[index].optType = 'F';
            this.footerTickerData[index].strikePrice = '';
        }
        if (tickertype == 'SPD') {
            this.footerTickerData[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
            this.footerTickerData[index].strikePrice = '';
            this.footerTickerData[index].optType = 'S';
            this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
            this.footerTickerData[index].strikePrice = this.spreadType.split("~")[0];
  
        }
        if (tickertype == 'OPT') {
            this.footerTickerData[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
            this.footerTickerData[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
            this.footerTickerData[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
  
        }
    }

    refresh() {
        if (!this.ref['destroyed']) {
          this.ref.detectChanges();// to detect the changes inside the angular
        }
      }
  }

