import { Component } from '@angular/core';
import { NavController , IonicPage ,ModalController ,Events, App } from 'ionic-angular';
// import { CommonProvider } from '../../providers/common/common';
// import swal from 'sweetalert2';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { Storage } from '@ionic/storage';

// @IonicPage()
@Component({
  selector: 'page-footer',
  templateUrl: '../../pages/DionWhite/footer/footer.html'
})

export class FooterPage {

  private footerTickerData : any;
  private tickerList : any;
  private ticker_result : any;
  private spreadType : any;
  private keylist : any;
  //private footer_webSocket_Data : any;
  private hideFilterButton : any;
  private hideGridButton : any;
  private ClientName : any;
  private user_Choice_result : any;
  public selectedTab:any;


  constructor(
    public navCtrl: NavController,
    // private common:CommonProvider,
    private marketWatchManager:MarketWatchProvider,
    public socket: WebsocketProvider,
    private storage:Storage,
    private ev:Events,
    private globalVar : GlobalVariableService,
    public websocketUtilityManager: WebsocketUtilityService,
    private app: App,
    public modalCtrl: ModalController,
    ) {
      this.hideFilterButton=false
      this.hideGridButton=false
      this.user_Choice_result=true
      //---Hide the filter button on the pages where it is not required.
      //---For this first we need to get the pagename from the global variables and then apply the disable logic.
      //console.log("this.globalVar.getPageName()",this.globalVar.getPageName())
      if(this.globalVar.getPageName().currentPageName=="DashboardPage"){
        this.hideFilterButton=true
      }else if(this.globalVar.getPageName().currentPageName=="HoldingsPage"){
        this.hideFilterButton=true
      }else if(this.globalVar.getPageName().currentPageName=="MarginPage"){
        this.hideFilterButton=true
      }else if(this.globalVar.getPageName().currentPageName=="FundManagementPage"){
        this.hideFilterButton=true
      }else if(this.globalVar.getPageName().currentPageName=="HomePage"){
        this.hideFilterButton=true
      }
      this.ClientName = globalVar.clientName;

        if(this.ClientName != 'Jetrade'){
            this.getFooterIndices();
        }

      //---Hide grid button on everypage except the market watch page --
      if(this.globalVar.getPageName().currentPageName=="MarketWatchPage"){
        this.hideGridButton=false
      }else{
        this.hideGridButton=true
      }
    this.selectedTab = this.globalVar.getfooterTab()

  }

  ionViewDidLoad(){

  }

  //---Set the local storage value to toggle between grid view and list view..
  showGridView(){
    this.storage.set("userMarketWatchGridView",this.user_Choice_result).then(()=>{
        this.ev.publish('checkUserMasterViewPreference',this.user_Choice_result);
        this.user_Choice_result=!this.user_Choice_result
    });
  }
  //---service to load the footer scrip ---
  getFooterIndices(){
    // this.tickerList = "NSE.NIFTY 50^BSE.SENSEX^NSE.NIFTY BANK";
    this.tickerList = "NEPSE.SENSITIVE^NEPSE.NEPSE";

    var indexData;
    this.marketWatchManager.listTicker(this.tickerList).then((data)=>{
      this.ticker_result = data;
      //----Successfully loaded market watch list ---
      if(this.ticker_result.ErrorCode == '0'){
        this.footerTickerData = JSON.parse(this.ticker_result.data);
        indexData = JSON.parse(this.ticker_result.data);
        for (var temp = 0; temp < indexData.length; temp++) {
            if (indexData[temp].Close == 0 || indexData[temp].Close == '' || indexData[temp].LTP == '' || indexData[temp].LTP == 0) {
                indexData[temp].Change = 0;
            } else {
                indexData[temp].Change = indexData[temp].LTP - indexData[temp].Close;
                indexData[temp]['%change'] = (indexData[temp].LTP - indexData[temp].Close) / indexData[temp].Close;
            }
        }
        this.footerTickerData = indexData;
        //console.log("this.footerTickerData",this.footerTickerData)
        /*on successful binding of data from response, create scriplist variable to subscribe to feed server*/

        // var ScripCode = "";
        var scripList = "";
        //var i = 0;
        var counter = 0;

        this.footerTickerData.forEach((marketWatchListItems_Obj, index) => {
            var ScripExchange = marketWatchListItems_Obj.exchange;
            var ticker = marketWatchListItems_Obj.ticker.toUpperCase();
            if (ScripExchange !== '') {
                scripList = scripList + this.GetExchangeCode(ScripExchange) + '.1!' + ticker.toUpperCase() + '^';
                counter = counter + 1;
            }
            this.computeScripDetails(marketWatchListItems_Obj, index);
        });

        this.keylist = 'ADD^' + counter + '^' + scripList;
        //console.log("KeyList from footer-->", this.keylist);
        //---Service to connect with the websocket --
        this.socket.connect();
        this.socket.send(this.keylist);
        this.websocketUtilityManager.getFeedAfterSubscribe(this.footerTickerData,'Footer').then((data)=>{
          //this.footer_webSocket_Data =data;
          //console.log("this.webSocket_Data--",this.footer_webSocket_Data.config)
        })
      }else{//----Market watch does not loaded--

      }
    }, err=> {
      // this.common.hideLoading();
    });

  }
  /*set exchange code in order to build keylist to register for feed.*/
  GetExchangeCode(Exchange) {
      var strCode = "0";
      switch (Exchange) {
          case "NSE":
          case "FONSE":
              strCode = "4";
              break;
          case "BSE":
          case "FOBSE":
              strCode = "1";
              break;
          case "ACE":
              strCode = "10";
              break;
          case "CDNSE":
              strCode = "13";
              break;
          case "MCX":
              strCode = "7";
              break;
          case "COMNSE":
              strCode = "5";
              break;
          case "NCDEX":
              strCode = "8";
              break;
          case "MCXSX":
              strCode = "14";
              break;
          case "NSEL":
              strCode = "36";
              break;
          case "MCXSXEQ":
              strCode = "64";
              break;
          case "MCXSXFO":
              strCode = "65";
              break;
          case "CDBSE":
              strCode = "17";
              break;
              case "NEPSE":
                strCode = "25";
            break;
      }
      return (strCode);
  }
  //---Get exchange legend ---
  GetExchangeLegend(Exchange) {
      var strCode = "";
      switch (Exchange) {
          case "NSE":
              strCode = "N";
              break;
          case "BSE":
              strCode = "B";
              break;
          case "FOBSE":
              strCode = "B";
              break;
          case "CDBSE":
              strCode = "B, CU";
              break;
          case "FONSE":
              strCode = "N";
              break;
          case "ACE":
              strCode = "A";
              break;
          case "CDNSE":
              strCode = "N, CU";
              break;
          case "MCX":
              strCode = "M";
              break;
          case "NCDEX":
              strCode = "X";
              break;
          case "MCXSX":
              strCode = "M, CU";
              break;
          case "NSEL":
              strCode = "NS";
              break;
          case "MCXSXEQ":
              strCode = "M, EQ";
              break;
          case "MCXSXFO":
              strCode = "M, FO";
              break;
              case "NEPSE":
                strCode = "25";
            break;
      }
      return (strCode);
  }
  //----Compute script detail---
  computeScripDetails(value, index) {
      var tickertype = 'EQT';
      var ScripExchange = value.exchange;
      var ticker = value.ticker.toUpperCase();

      //identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
      if (ticker.search("~") > 0) {
          tickertype = 'FUT';
          if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
              tickertype = 'OPT';
          }

          if (ticker.search("~S") > 0) {
              tickertype = 'SPD';
          }
      } else {
          tickertype = 'EQT';
      }

      this.footerTickerData[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

      if (tickertype == 'EQT') {
          this.footerTickerData[index].underlying = ticker.toUpperCase();
          this.footerTickerData[index].optType = '';
          this.footerTickerData[index].strikePrice = '';
      }

      if (tickertype == 'FUT') {
          this.footerTickerData[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
          this.footerTickerData[index].optType = 'F';
          this.footerTickerData[index].strikePrice = '';
      }
      if (tickertype == 'SPD') {
          this.footerTickerData[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
          this.footerTickerData[index].strikePrice = '';
          this.footerTickerData[index].optType = 'S';
          this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
          this.footerTickerData[index].strikePrice = this.spreadType.split("~")[0];

      }
      if (tickertype == 'OPT') {
          this.footerTickerData[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
          this.footerTickerData[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
          this.footerTickerData[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);

      }
  }
  //---Footer modal for the filter--
  openFilter(){
    let filterMarketWatchModal = this.modalCtrl.create('FilterMarketWatchModal');
      filterMarketWatchModal.onDidDismiss(data => {
         //console.log(data);
       });
      filterMarketWatchModal.present();
  }
  //---Open market messages page --
  showMarketMsg(){
    this.navCtrl.push('ExchangeInformationPage');
  }

  //---Open Speech recognition page --
  showSpeechRecognizationPage(){
    this.navCtrl.push('VoiceBuySellPage');
  }

  segmentChanged(ev){
    console.log("segment", ev);
    let page = ev.value;
    this.selectedTab = page;
    this.globalVar.setfooterTab(page)
    this.app.getRootNav() ? this.app.getRootNav().setRoot(page) : this.navCtrl.setRoot(page);
  }
}
