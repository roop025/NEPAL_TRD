import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExternalPortfolioDetailsPage } from './external-portfolio-details';
import { FilterPipeModule } from 'ngx-filter-pipe';
@NgModule({
  declarations: [
    ExternalPortfolioDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ExternalPortfolioDetailsPage),FilterPipeModule
  ],
})
export class ExternalPortfolioDetailsPageModule {}
