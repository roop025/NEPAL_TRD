import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { Chart } from 'chart.js';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import { PortfolioManagerProvider } from '../../providers/portfolio-manager/portfolio-manager';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { BackButton } from '@scaffold-digital/ionic-hardware-buttons';
import { ChartsModule } from 'ng2-charts';


@IonicPage()
@Component({
  selector: 'page-external-portfolio-details',
  templateUrl: '../../pages/DionBlack/external-portfolio-details/external-portfolio-details.html'
})
export class ExternalPortfolioDetailsPage {
public folioData:any;
public current_obj:any;
public report_list:any[]=[];
public   filter:any = {
  SchemeName: {
    $or: ['']
  }
}
 

  constructor(public navCtrl    : NavController,
    public navParams    : NavParams,
    public globalVar    : GlobalVariableService,
    private common      : CommonProvider,
    private portfolioManager: PortfolioManagerProvider,
    private userManager: UserManagerProvider,
    public menu         : MenuController){

    }


    ionViewDidLoad()
    {
      this.folioData=this.navParams.data.follio_data;
      console.log("Follio Data",this.folioData);
      this.report_list=this.folioData.ReportTable1 || [];
      this.current_obj=this.navParams.data.current_obj
      console.log("Currrr",this.current_obj);
      this.filter= {
        SchemeName: {
          $or: [this.current_obj.SchemeName]
        }
      }
    }
  }