import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FpOrderFormPage } from './fp-order-form';
import { IonicSelectableModule } from 'ionic-selectable';
@NgModule({
  declarations: [
    FpOrderFormPage,
  ],
  imports: [
    IonicPageModule.forChild(FpOrderFormPage),
    IonicSelectableModule
  ],
})
export class FpOrderFormPageModule {}
