import { Component } from '@angular/core';
import { NavController , IonicPage } from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { ReportProvider } from '../../providers/report/report';
import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-funfManagement',
  templateUrl: '../../pages/DionWhite/fund-management/fund-management.html'
})

export class FundManagementPage {
  // public setName : any;
  tab1Root = 'FundTransferPage';
  tab2Root = 'FundWithdrawlPage';
  tab3Root = 'InterSegmentTransferPage';
  private logoutFrmData : any;
  private   user_logout_result: any = '';
  public userData : any;
  public dpStatus_result : any;
  public ClientName:any;


  constructor(
    public navCtrl: NavController,
    private globalVariableService : GlobalVariableService,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private storage:Storage,
    public getReportManager: ReportProvider,
    ){

    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"FundManagementPage"});
    this.ClientName = globalVariableService.clientName;

  }

  ionViewDidLoad(){
    //console.log("test from login")
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
    });
    if(this.globalVariableService.clientName == 'Canara'){
      this.GetFundDPStatus();
    }
  }

  boifundTransfer(v){
    this.navCtrl.push('FundTransferPage',{"process":v});
  }

  fundWithdrawal(){
    console.log('fundWithdrawal');
  }
  //---GetFundDPStatus
  GetFundDPStatus(){
    this.getReportManager.getDPStatusMsg().then((data) => {
        this.dpStatus_result = data;
        if (this.dpStatus_result.ErrorCode == 0) {
          //this.GetUserPropertyDeatails();
        }else{

          swal({
              title: "Please wait!",
              text: this.dpStatus_result.Message,
              type: "warning",
              showCancelButton: false,
              confirmButtonColor: "#DD6B55",
              confirmButtonText: "Ok"
          });
          this.navCtrl.push('HomePage');
        }
    },err => {
        swal({
            title: "Error!",
            text: "Network Issue...",
            timer: 3000,
            showConfirmButton: false
        });
    });
  }

}
