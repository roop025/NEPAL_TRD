import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InterSegmentTransferPage } from './inter-segment-transfer';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
@NgModule({
  declarations: [
    InterSegmentTransferPage,
  ],
  imports: [
    IonicPageModule.forChild(InterSegmentTransferPage),NgProgressModule,SharedModule
  ],
})
export class InterSegmentTransferPageModule {}
