import { Component } from '@angular/core';
import { NavController , IonicPage } from 'ionic-angular';
import { FundManagementProvider } from '../../providers/fund-management/fund-management';
import swal from 'sweetalert2';
import { NgProgress } from 'ngx-progressbar';
import { Storage } from '@ionic/storage';
import { GlobalVariableService } from '../../providers/common/global-variable';
/**
 * Generated class for the InterSegmentTransferPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-inter-segment-transfer',
  templateUrl: '../../pages/DionWhite/fund-management/inter-segment-transfer.html',
})
export class InterSegmentTransferPage {

  public userData : any;
  public segementDropdown : any;
  public segmentModel : any;
  public exchangeModel : any;
  public exchangeDropdown : any;
  public progressBarColor : any;
  public bank_result : any;
  public BankData : any;
  public bank_acc_result : any;
  public BankAccountNumberData : any;
  public bankAccountNumber : any;
  public freeBalance : any;
  public bankModel : any;
  public bankType : any;
  public transferObject : any={};
  public fundTransfer_result : any;
  public availableFund_result : any;
  public fundWithdrawl_result : any;
  public withdrawl_result : any;
  public WithdrawalReportData : any;
  public message : any;
  public ShownWithdrawalReportData : any;
  public currentDate : any;
  public fundCancel_result : any;
  public ClientName : any;
  selectedDestinationPoint:any;
  InterSegmentTransfer:any={};
  segmentReport:any[]=[];
  constructor(public navCtrl: NavController,
    private storage:Storage,
    private globalVariableService : GlobalVariableService,
    public getFundManagement : FundManagementProvider,
    public ngProgress: NgProgress
    ) {
      this.progressBarColor = 'white'
      // this.ExchangeStatusList=[];
      // this.loadMarketStatus();
      //--Transfer Object --
      this.transferObject={
        Amount:''
      }
      this.ClientName=globalVariableService.clientName
  }

  ionViewDidLoad(){
    //console.log("test from login")
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //---Load Segment --
       this.loadSegmentList();
       //--Load bank code --
       this.GetBankName();
       //--Get withdrawlable amount--
       this.RetriveWidthdrawFund();
       //--Get the withdrwal report data --
       this.WithdrawalReport();
       this.InterSegmentFundTransferReport()
    });
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"NetPositionPage"});

  }

  //--Load segment list --
  loadSegmentList(){
    var segList = '';
    var arr = this.userData.SegmentExchangeList.split(',');
    for (var i = 0; i < arr.length; i++) {

      var arr1 = arr[i].split('|');
      if (i != arr.length - 1)
        segList += arr1[0] + ',';
      else
        segList += arr1[0];
    }
    this.segementDropdown=segList.split(',');
    this.segmentModel=this.segementDropdown[0]
    this.getExchangeName(this.segmentModel);
  }

  toggleSegmentType(segObj){
    console.log("segObj",segObj)
    //--Get exchange name on basis of segment --
    this.getExchangeName(segObj);
    this.RetriveWidthdrawFund();
  }

  //--Get exchange name --
  getExchangeName(segObjName){
    var arr = this.userData.SegmentExchangeList.split(',');
    for (var i = 0; i < arr.length; i++) {
      var arr1 = arr[i].split('|');
      for (var j = 0; j < arr1.length; j++) {
        if (arr1[0] == segObjName)
          this.exchangeDropdown=arr1[1].split('~');

      }
    }
    this.exchangeModel=this.exchangeDropdown[0];
    // console.log("this.exchangeDropdown",this.exchangeDropdown)
  }
  //--Toggle exchange --
  toggleExchangeType(exchangeObj){

  }

  //--Get Bank code --
  GetBankName(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getBankCode("ALL","BankList",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.bank_result = data;
      if(this.bank_result.ErrorCode==0){
        if(this.bank_result.reportTable=="" || this.bank_result.reportTable==null){
          swal({
            title: "Error!",
            text: "No bank code found",
            timer: 2000,
            showConfirmButton: false
          });
        }else{
          this.BankData = JSON.parse(this.bank_result.reportTable);
          this.bankModel=this.BankData[0];
          // console.log("this.BankData",this.BankData)
          // console.log("this.bankModel",this.bankModel)
          this.bankType = this.BankData[0].BankCode;
          //--Get account number --
          this.GetBankAccountNumber();
        }
      }else{
        swal({
          title: "Error!",
          text: this.bank_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //--Get bank account number --
  GetBankAccountNumber(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getBankCode("ALL","BankList",this.userData,this.bankType).then((data)=>{
      this.ngProgress.done();
      this.bank_acc_result = data;
      if(this.bank_acc_result.ErrorCode==0){
        if(this.bank_acc_result.reportTable=="" || this.bank_acc_result.reportTable==null){
          swal({
            title: "Error!",
            text: "No bank code found",
            timer: 2000,
            showConfirmButton: false
          });
        }else{
          this.BankAccountNumberData = JSON.parse(this.bank_acc_result.reportTable);
          this.bankAccountNumber = this.BankAccountNumberData[0].AccountNo;
        }
      }else{
        swal({
          title: "Error!",
          text: this.bank_acc_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //--Toggle bank type --
  toggleBankType(bankObj){
    console.log("bankObj",bankObj)
    //--Load account number --
    this.bankType=bankObj.BankCode
    this.GetBankAccountNumber();
  }

  //---Inisiate fund transfer --
  fundWithdraw(){
    //console.log("this.transferObject",this.transferObject)
    if(this.transferObject.Amount<=499.99 || this.transferObject.Amount===''){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount cannot be less than Rs. 500",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
      return;
    }else if(this.transferObject.Amount>this.freeBalance){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount cannot be greater than Free Balance",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
      return;
    }
    else{
      swal({
        title: 'Are you sure?',
        html: "You want to withdraw <b>Rs :</b> " + this.transferObject.Amount + "  from  <b>Segment :</b> " + this.segmentModel,
        type: 'info',
        showCancelButton: true,
        cancelButtonText: "Cancel!",
        confirmButtonColor: "#387ef5",
        confirmButtonText: "Withdraw",
        showLoaderOnConfirm: true,
        }).then((result) => {
        if (result.value) {
            //---User want to Place order--
            this.WidthdrawFund();
          }
        })
    }
  }
  //--Transfer fund --
  WidthdrawFund(){
    var TransferString = '?BankTrxnObject={';
    TransferString += '"SessionNo":"' + this.userData.SessionNo + '",';
    TransferString += '"Source":"' + '5' + '",';
    TransferString += '"ClientCode":"' + this.userData.ClientCode + '",';
    TransferString += '"RequestedBy":"' + this.userData.ClientCode + '",';
    TransferString += '"SegmentAccount":"' + this.segmentModel + '",';
    TransferString += '"BankName":"' + this.bankModel.BankCode + '",';
    TransferString += '"Amount":"' + this.transferObject.Amount + '",';
    TransferString += '"AccountNo":"' + this.bankAccountNumber + '",';
    TransferString += '}';

    //--Service to Execute fund transfer --
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.executeFundWithdrawl(TransferString).then((data)=>{
      this.ngProgress.done();
      this.fundWithdrawl_result = data;
      if(this.fundWithdrawl_result.ErrorCode==0 && this.fundWithdrawl_result.Message != null){
        swal({
          title: "Successful",
          text: this.fundWithdrawl_result.Message + '" from "' + '"Segment account"' + this.segmentModel + '" Withdrawal balance is RS.' + this.transferObject.Amount,
          type: "success",
          showConfirmButton: true
        })
        this.WithdrawalReport();
        this.RetriveWidthdrawFund();
      }else{
        swal({
          title: "Error!",
          text: this.fundWithdrawl_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
      this.transferObject.Amount = '';
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //---Retrive fund withdrawlable amount available --
  RetriveWidthdrawFund(){
    var RetriveWidthdrawFundString = '{';
    RetriveWidthdrawFundString += '"SessionNo":"' + this.userData.SessionNo + '",';
    RetriveWidthdrawFundString += '"Source":"' + '5' + '",';
    RetriveWidthdrawFundString += '"ClientCode":"' + this.userData.ClientCode + '",';
    RetriveWidthdrawFundString += '"RequestedBy":"' + this.userData.ClientCode + '",';
    RetriveWidthdrawFundString += '"ActionType":"Retrive",';
    RetriveWidthdrawFundString += '"SegmentAccount":"' + this.segmentModel + '"';
    RetriveWidthdrawFundString += '}';
    //console.log("RetriveWidthdrawFundString",RetriveWidthdrawFundString)
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getAvailableFund(RetriveWidthdrawFundString).then((data)=>{
      this.ngProgress.done();
      this.availableFund_result = data;
      if(this.availableFund_result.ErrorCode==0 && this.availableFund_result.Message != null){
        this.freeBalance=this.availableFund_result.WithdrawableAmount
      }else if(this.availableFund_result.ErrorCode == '-1111'){
        swal({
          type: "error",
          title: "Invalid Session",
          text: "Your session is invalid. You've been logged out!",
          timer: 2000,
          showConfirmButton: false
        });
      }
      else{
        swal({
          title: "Error!",
          text: this.availableFund_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //--Fund withdrwawale report--
  WithdrawalReport(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getScripOrderReport("ALL","FundWithdrawalReport",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.withdrawl_result = data;
      if(this.withdrawl_result.reportTable=="" || this.withdrawl_result.reportTable==null){
        this.WithdrawalReportData = '';
        this.message=this.withdrawl_result.Message
      }else{
        this.WithdrawalReportData = JSON.parse(this.withdrawl_result.reportTable);
        if (this.WithdrawalReportData != null) {
          this.ShownWithdrawalReportData=[]
          for (var i = 0; i < this.WithdrawalReportData.length; i++) {
            this.ShownWithdrawalReportData.push({
              AccountNo: this.WithdrawalReportData[i].AccountNo,
              SegmentAccount: this.WithdrawalReportData[i]["Segment Account"],
              RequestID: this.WithdrawalReportData[i]["Request ID"],
              RequestType: this.WithdrawalReportData[i]["Request Type"],
              ToBank: this.WithdrawalReportData[i]["To Bank"],
              CAShWithdrawn: this.WithdrawalReportData[i]["CASh Withdrawn"],
              Status: this.WithdrawalReportData[i].Status,
              DateandTime: this.WithdrawalReportData[i]["Request Date Time"]
            });
          };
        }

        this.currentDate = new Date();
        var dd = this.currentDate.getDate();
        var mm = this.currentDate.getMonth() + 1; //January is 0!
        var yyyy = this.currentDate.getFullYear();
        if (dd < 10) {
          dd = '0' + dd
        }
        if (mm < 10) {
          mm = '0' + mm
        }
        this.currentDate = mm + '/' + dd + '/' + yyyy;
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //---Cancel the fund withdrawl --
  ValidateFundCancel(data){
    swal({
      title: 'Are you sure?',
      html: "You want to cancel withdraw request <b>Rs :</b> "+ data.CAShWithdrawn,
      type: 'info',
      showCancelButton: true,
      cancelButtonText: "Cancel!",
      confirmButtonColor: "#387ef5",
      confirmButtonText: "Ok",
      showLoaderOnConfirm: true,
      }).then((result) => {
      if (result.value) {
          //---User want to Place order--
          this.CancelWidthdrawFundData(data);
        }
      })
  }
  CancelWidthdrawFundData(data){
    var CancelWidthdrawString = '{';
    CancelWidthdrawString += '"SessionNo":"' + this.userData.SessionNo + '",';
    CancelWidthdrawString += '"Source":"' + '5' + '",';
    CancelWidthdrawString += '"ClientCode":"' + this.userData.ClientCode + '",';
    CancelWidthdrawString += '"RequestedBy":"' + this.userData.ClientCode + '",';
    CancelWidthdrawString += '"RequestType":"' + data.RequestID + '",';
    CancelWidthdrawString += '"Amount":"' + data.CAShWithdrawn + '"';
    CancelWidthdrawString += '}';

    //--Service to Execute fund transfer --
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.executeFundCancel(CancelWidthdrawString).then((data)=>{
      this.ngProgress.done();
      this.fundCancel_result = data;
      if(this.fundCancel_result.ErrorCode==0 && this.fundCancel_result.Message != null){
        swal({
          title: "Successful",
          text: this.fundCancel_result.Message,
          type: "success",
          showConfirmButton: true
        })
        this.WithdrawalReport();
        this.RetriveWidthdrawFund();
      }else{
        swal({
          title: "Error!",
          text: this.fundCancel_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
      this.transferObject.Amount = '';
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  ValidateInterSegmentFundTransfer() {

    if (this.segmentModel == this.selectedDestinationPoint) {
      
      swal({
        title: "Error!",
        text: "Source and Destination Segment cannot be same",
        timer: 3000,
        showConfirmButton: false
    });
      
    } else if (this.segmentModel== "COMMODITY" || this.selectedDestinationPoint== "COMMODITY") {
    
      swal({
        title: "Error!",
        text: "Intersegment Transfer Not Allowed for COMMODITY Segment",
        timer: 3000,
        showConfirmButton: false
    });
  
    } else if (!this.selectedDestinationPoint) {
     
      swal({
        title: "Error!",
        text: "Destination Segment cannot be blank",
        timer: 3000,
        showConfirmButton: false
    });
    } else if (this.InterSegmentTransfer.Amount > this.freeBalance) {
      // swal({
      //   title: "Invalid Amount",
      //   text: 'Requested amount cannot be greater than available amount',
      //   type: "error",
      //   showConfirmButton: true,
      //   closeOnConfirm: true
      // })

      swal({
        title: "Error!",
        text: "Requested amount cannot be greater than available amount",
        timer: 3000,
        showConfirmButton: false
    });
      
    } else if (this.InterSegmentTransfer.Amount <= 0 || this.InterSegmentTransfer.Amount === '') {
      // swal({
      //   title: "Invalid Amount",
      //   text: 'Requested amount cannot be less than zero',
      //   type: "error",
      //   showConfirmButton: true,
      //   closeOnConfirm: true
      // })
      swal({
        title: "Error!",
        text: "Requested amount cannot be less than zero",
        timer: 3000,
        showConfirmButton: false
    });
      
    } else {
      // swal({
      //   title: "Are you sure?",
      //   text: "You want to transfer <b>Rs :</b> " + $scope.InterSegmentTransfer.Amount + " from  <b>Segment :</b> " + $scope.withdrawsegment + " to " + $scope.selectedDestinationPoint,
      //   type: "warning",
      //   html: true,
      //   showCancelButton: true,
      //   confirmButtonColor: "#387ef5",
      //   confirmButtonText: "Transfer",
      //   closeOnConfirm: false,
      //   showLoaderOnConfirm: true,
      // },(isConfirm)=> {
      //   if (isConfirm) {
      //     $timeout(()=> {
      //       TransferFundInterSegment();
      //     }, 2000);
      //   }
      // })

      swal({
        title: 'Are you sure?',
        html: `You want to transfer <b>Rs :</b> ${this.InterSegmentTransfer.Amount} from  <b>Segment :</b>  ${this.segmentModel} to ${this.selectedDestinationPoint}`,
        type: 'info',
        showCancelButton: true,
        cancelButtonText: "Cancel!",
        confirmButtonColor: "#387ef5",
        confirmButtonText: "Ok",
        showLoaderOnConfirm: true,
        }).then((result) => {
        if (result.value) {
            //---User want to Place order--
         this.TransferFundInterSegment()
          }
        })
    }

    /*  else {
      TransferFundInterSegment();
    }*/
  };
  TransferFundInterSegment()
  {
    var InterSementqString = '{';
    InterSementqString += '"RequestedBy":"' +this.userData.ClientCode  + '",';
    InterSementqString += '"SessionNo":"' + this.userData.SessionNo + '",';
    InterSementqString += '"ClientCode":"' + this.userData.ClientCode + '",';
    InterSementqString += '"SourceSegment":"' + this.segmentModel + '",';
    InterSementqString += '"DestinationSegment":"' + this.selectedDestinationPoint + '",';
    InterSementqString += '"Action":"1",';
    InterSementqString += '"CashTransferred":"' +this.InterSegmentTransfer.Amount + '",';
    InterSementqString += '}';


    this.getFundManagement.executeSegmentTransfer(InterSementqString).then((_sucess:any)=>{
console.log(" transfer success",_sucess);
if(_sucess.ErrorCode==0)
{
      swal({
          title: "Transfer Successful",
          text: 'Rs.' +this.InterSegmentTransfer.Amount + ' is transfered from "' + this.segmentModel + '" to "' + this.selectedDestinationPoint + '" successfully',
          type: "success",
          timer: 3000,
          showConfirmButton: false
        })

}
else{
  swal({
    title: "",
    text: _sucess.Message,
    type: "error",
    timer: 3000,
    showConfirmButton: false
  })
}
    }).catch(err=>{
      console.log("Error in transfer",err);
      swal({
        title: "",
        text:'Please try again',
        type: "error",
        timer: 3000,
        showConfirmButton: false
      })
    })
    // var InterSegmentTransferurl = configService.TradingServiceURL + configService.ExecuteInterSegmentTransfer + "?SegmentInfo=" + InterSementqString;

    // $scope.progressbar.setColor('White');
    // $scope.progressbar.start();
    // $http({
    //   method: 'GET',
    //   url: InterSegmentTransferurl
    // }).then(function InterSegmentTransfersuccess(data) {
    //   if (data.data.ErrorCode == 0) {
    //     swal({
    //       title: "Transfer Successful",
    //       text: 'Rs.' + $scope.InterSegmentTransfer.Amount + ' is transfered from "' + $scope.withdrawsegment + '" to "' + $scope.selectedDestinationPoint + '" successfully',
    //       type: "success",
    //       showConfirmButton: true,
    //       closeOnConfirm: true
    //     })
    //     $scope.InterSegmentTransfer.Amount = '';
    //     $scope.progressbar.setColor('Green');
    //     InterSegmentFundTransferReport();
    //     $scope.progressbar.complete();
    //     $ionicScrollDelegate.scrollTop();
    //   } else {
    //     swal({
    //       title: "Error",
    //       type: "error",
    //       text: data.data.Message,
    //       showConfirmButton: true,
    //       closeOnConfirm: true
    //     })
    //   }

    // }, function InterSegmentTransfererror(data) {

    //   swal({
    //     title: "Error!",
    //     text: "Oops, Something went wrong.",
    //     timer: 2000,
    //     showConfirmButton: false
    //   });
    //   $scope.progressbar.setColor('Red');
    //   $scope.progressbar.complete();
    //   $scope.reportStatus = "Error occured, Please try again later";
    // });
  }

 


//   SegItems:any[]=[];
//   withdrawsegment:any;
//   InterSegmentTransfer:any={};
//   userData:any;
//   segmentModel:any;
//   public segementDropdown : any;
//   exchangeModel:any;
//   exchangeDropdown:any[]=[];
//   // SegItems:any[]=[]
//   constructor(public navCtrl: NavController, public navParams: NavParams,private storage:Storage,public getFundManagement:FundManagementProvider) {
//   }

//   ionViewDidLoad() {
//     console.log('ionViewDidLoad InterSegmentTransferPage');
//     console.log(">>>>");
//     this.storage.get("userMaster").then((data)=>{
//       if(data!=null && data!=''){
//         this.userData = data;
//         this.loadSegmentList()
//       }
//     })

//   }

//   loadSegmentList(){
//     var segList = '';
//     var arr = this.userData.SegmentExchangeList.split(',');
//     for (var i = 0; i < arr.length; i++) {

//       var arr1 = arr[i].split('|');
//       if (i != arr.length - 1)
//         segList += arr1[0] + ',';
//       else
//         segList += arr1[0];
//     }
//     this.segementDropdown=segList.split(',');
//     this.segmentModel=this.segementDropdown[0]
//     this.getExchangeName(this.segmentModel);
//     this.RetriveWidthdrawFund()
//   }

//   getWithdrawBalance() {
//     // $scope.withdrawsegment = this.withdrawsegment;
//     this.RetriveWidthdrawFund();
//   }


//   RetriveWidthdrawFund() {


//     let obj={
//       SessionNo:this.userData.SessionNo,
//       Source:'5',
//       ClientCode:this.userData.ClientCode,
//       RequestedBy:this.userData.ClientCode,
//       ActionType:'Retrive',
//       SegmentAccount:this.segmentModel 
//     }

// this.getFundManagement.getAvailableFund(JSON.stringify(obj)).then(data=>{
// console.log("withdrow fund",data);

// })

//     // var RetriveWidthdrawFundString = '{';

//     // RetriveWidthdrawFundString += '"SessionNo":"' + LoginService.LoginDetails.SessionNo + '",';


//     // RetriveWidthdrawFundString += '"Source":"' + LoginService.login.Source + '",';
//     // RetriveWidthdrawFundString += '"ClientCode":"' + LoginService.LoginDetails.ClientCode + '",';
//     // RetriveWidthdrawFundString += '"RequestedBy":"' + LoginService.LoginDetails.ClientCode + '",';
//     // RetriveWidthdrawFundString += '"ActionType":"Retrive",';
//     // RetriveWidthdrawFundString += '"SegmentAccount":"' + $scope.withdrawsegment + '"';

//     // RetriveWidthdrawFundString += '}';


//     // var RetriveWidthdrawFundurl = configService.TradingServiceURL + configService.ExecuteFundWithdrawal + "?BankTrxnObject=" + RetriveWidthdrawFundString;

//     // $http({
//     //   method: 'GET',
//     //   url: RetriveWidthdrawFundurl
//     // }).then(function RetriveWidthdrawFundsuccess(data) {
//     //   if (data.data.ErrorCode == '0' && data.data.Message != null) {

//     //     $scope.WithDrawable = data.data.WithdrawableAmount;

//     //   } else if(data.data.ErrorCode == '-1111') {
//     //     swal({
//     //       title: "Invalid Session",
//     //       text: "Your session is invalid. You've been logged out!",/**/
//     //       type: "error",
//     //       showConfirmButton: true,
//     //       closeOnConfirm: true
//     //     })
//     //      $state.go("login");
//     //   }
//     //   else {
//     //     swal({
//     //       title: "error",
//     //       text: data.data.Message,
//     //       type: "error",
//     //       showConfirmButton: true,
//     //       closeOnConfirm: true
//     //     })
//     //   }





//     // }, function RetriveWidthdrawFunderror(data) {

//     //   swal({
//     //     title: "Error!",
//     //     text: "Oops, Something went wrong.",
//     //     timer: 2000,
//     //     showConfirmButton: false
//     //   });
//     //   $scope.progressbar.setColor('Red');
//     //   $scope.progressbar.complete();
//     //   $scope.reportStatus = "Error occured, Please try again later";
//     // });
//   }


//   getExchangeName(segObjName){
//     var arr = this.userData.SegmentExchangeList.split(',');
//     for (var i = 0; i < arr.length; i++) {
//       var arr1 = arr[i].split('|');
//       for (var j = 0; j < arr1.length; j++) {
//         if (arr1[0] == segObjName)
//           this.exchangeDropdown=arr1[1].split('~');

//       }
//     }
//     this.exchangeModel=this.exchangeDropdown[0];
//     // console.log("this.exchangeDropdown",this.exchangeDropdown)
//   }

 InterSegmentFundTransferReport() {

  var qString = '{';
  qString += '"ReportName":"InterSegmentFundTransferReport",';
  qString += '"ClientCode":"' + this.userData.ClientCode + '",';
  qString += '"SessionNo":"' + this.userData.SessionNo + '"}';




 this.progressBarColor = 'white'
 this.ngProgress.start();
this.getFundManagement.getScripOrderReport("ALL","InterSegmentFundTransferReport",this.userData,"").then((data:any)=>{
  this.ngProgress.done();
console.log("Transfer report",data);
if(data.ErrorCode==0)
{
  // console.log();
  this.segmentReport=JSON.parse(data.reportTable)
}
}).catch(err=>{
  console.log("Errr",err);
  
})
 }
}
