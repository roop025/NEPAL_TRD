import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FundManagementPage } from './fund-management';

@NgModule({
  declarations: [
    FundManagementPage
  ],
  imports: [
    IonicPageModule.forChild(FundManagementPage),
  ],
})
export class FundManagementPageModule {}
