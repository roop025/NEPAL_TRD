import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FundWithdrawlPage } from './fund-withdrawl';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    FundWithdrawlPage
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    IonicPageModule.forChild(FundWithdrawlPage),
  ],
})
export class FundWithdrawlPageModule {}
