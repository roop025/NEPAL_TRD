import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FundTransferPage } from './fund-transfer';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    FundTransferPage
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    IonicPageModule.forChild(FundTransferPage),
  ],
})
export class FundTransferPageModule {}
