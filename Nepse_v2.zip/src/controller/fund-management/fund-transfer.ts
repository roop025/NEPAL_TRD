import { Component } from '@angular/core';
import { NavController , IonicPage,NavParams } from 'ionic-angular';
import { FundManagementProvider } from '../../providers/fund-management/fund-management';
import swal from 'sweetalert2';
import { NgProgress } from 'ngx-progressbar';
import { Storage } from '@ionic/storage';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { InAppBrowser } from '@ionic-native/in-app-browser';


@IonicPage()
@Component({
  selector: 'page-funfManagement',
  templateUrl: '../../pages/DionWhite/fund-management/fund-transfer.html'
})

export class FundTransferPage {
  public userData : any;
  public segementDropdown : any;
  public segmentModel : any;
  public exchangeModel : any;
  public actionModel : any;
  public exchangeDropdown : any;
  public progressBarColor : any;
  public bank_result : any;
  public BankData : any;
  public bank_acc_result : any;
  public BankAccountNumberData : any;
  public bankAccountNumber : any;
  public bankModel : any;
  public bankType : any;
  public transferObject : any;
  public fundTransfer_result : any;
  public actionDropdown : any;
  public lienBal_result : any;
  public GetLienAvailableBalance : any;
  public fundHold_result : any;
  public fundRelease_result : any;
  public paymentProccess:any;
  public bank_codeFlg:any;

  constructor(public navCtrl: NavController,
    private storage:Storage,
    private globalVariableService : GlobalVariableService,
    public getFundManagement : FundManagementProvider,
    public ngProgress: NgProgress,
    public navParams: NavParams,
    public inAppBsr : InAppBrowser

    ) {
     

      this.progressBarColor = 'white'
      // this.ExchangeStatusList=[];
      // this.loadMarketStatus();
      //--Transfer Object --
      this.transferObject={
        Amount:'',
        releaseAmount:''
      }
      this.actionDropdown = ['Hold', 'Release'];
      this.actionModel=this.actionDropdown[0];
      // console.log("this.actionModel",this.actionModel)

      this.paymentProccess = this.navParams.get("process");
      if(this.paymentProccess =='BOI'){
        this.bank_codeFlg = false
      }else{
        this.bank_codeFlg = true;
      }

      console.log(this.paymentProccess);

  }

  ionViewDidLoad(){
    //console.log("test from login")
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //---Load Segment --
       this.loadSegmentList();
       //--Load bank code --
       this.GetBankName();
       //---Get lien balance ---
       if(this.globalVariableService.clientName == 'Canara'){
         this.GetLienBalance();
       }
    });
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"FundTransferPage"});

  }

  //--Load segment list --
  loadSegmentList(){
    var segList = '';
    var arr = this.userData.SegmentExchangeList.split(',');
    for (var i = 0; i < arr.length; i++) {

      var arr1 = arr[i].split('|');
      if (i != arr.length - 1)
        segList += arr1[0] + ',';
      else
        segList += arr1[0];
    }
    this.segementDropdown=segList.split(',');
    this.segmentModel=this.segementDropdown[0]
    this.getExchangeName(this.segmentModel);
  }

  toggleSegmentType(segObj){
    //console.log("segObj",segObj)
    //--Get exchange name on basis of segment --
    this.getExchangeName(segObj);
  }

  toggleActionType(accObj){
    this.GetLienBalance()
  }
  //--Get exchange name --
  getExchangeName(segObjName){
    var arr = this.userData.SegmentExchangeList.split(',');
    for (var i = 0; i < arr.length; i++) {
      var arr1 = arr[i].split('|');
      for (var j = 0; j < arr1.length; j++) {
        if (arr1[0] == segObjName)
          this.exchangeDropdown=arr1[1].split('~');

      }
    }
    this.exchangeModel=this.exchangeDropdown[0];
    // console.log("this.exchangeDropdown",this.exchangeDropdown)
  }
  //--Toggle exchange --
  toggleExchangeType(exchangeObj){

  }

  //--Get Bank code --
  GetBankName(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getBankCode("ALL","BankList",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.bank_result = data;
      if(this.bank_result.ErrorCode==0){
        if(this.bank_result.reportTable=="" || this.bank_result.reportTable==null){
          swal({
            title: "Error!",
            text: "No bank code found",
            timer: 2000,
            showConfirmButton: false
          });
        }else{
          this.BankData = JSON.parse(this.bank_result.reportTable);
          this.bankModel=this.BankData[0];
          // console.log("this.BankData",this.BankData)
          // console.log("this.bankModel",this.bankModel)
          this.bankType = this.BankData[0].BankCode;
          //--Get account number --
          this.GetBankAccountNumber();
        }
      }else{
        swal({
          title: "Error!",
          text: this.bank_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //---Get Lien balance ---
  GetLienBalance(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getLienBal(this.actionModel,this.segmentModel,this.userData).then((data)=>{
      this.ngProgress.done();
      this.lienBal_result = data;
      if(this.lienBal_result.ErrorCode==0){
        this.GetLienAvailableBalance= this.lienBal_result.Message;
      }else{
        swal({
          title: "Error!",
          text: this.lienBal_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }
  //--Get bank account number --
  GetBankAccountNumber(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.getBankCode("ALL","BankList",this.userData,this.bankType).then((data)=>{
      this.ngProgress.done();
      this.bank_acc_result = data;
      if(this.bank_acc_result.ErrorCode==0){
        if(this.bank_acc_result.reportTable=="" || this.bank_acc_result.reportTable==null){
          swal({
            title: "Error!",
            text: "No bank code found",
            timer: 2000,
            showConfirmButton: false
          });
        }else{
          this.BankAccountNumberData = JSON.parse(this.bank_acc_result.reportTable);
          this.bankAccountNumber = this.BankAccountNumberData[0].AccountNo;
        }
      }else{
        swal({
          title: "Error!",
          text: this.bank_acc_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //--Toggle bank type --
  toggleBankType(bankObj){
    //console.log("bankObj",bankObj)
    //--Load account number --
    this.bankType=bankObj.BankCode
    this.GetBankAccountNumber();
  }

  //---Inisiate fund transfer --
  fundTransfer(){
    if(this.transferObject.Amount<=49.99 || this.transferObject.Amount===''){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount cannot be less than Rs. 50",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
      return;
    }else{
      swal({
        title: 'Transfer Details',
        html: "'<b>'Segment:'</b>' " + this.segmentModel + " , <b>Bank:</b> " + this.bankModel.BankCode + ", <b>A/c: </b> " + this.bankAccountNumber + ", <b>Amount:</b> " + this.transferObject.Amount + "",
        type: 'info',
        showCancelButton: true,
        cancelButtonText: "Cancel!",
        confirmButtonColor: "#387ef5",
        confirmButtonText: "Transfer"
        }).then((result) => {
        if (result.value) {
            //---User want to Place order--
            this.TransferFund();
          }
        })
    }
  }
  //--Transfer fund --
  TransferFund(){
    let enterAmt = this.transferObject.Amount

    var TransferString = '?BankTrxnObject={';
    TransferString += '"SessionNo":"' + this.userData.SessionNo + '",';
    TransferString += '"Source":"' + '5' + '",';
    TransferString += '"ClientCode":"' + this.userData.ClientCode + '",';
    TransferString += '"RequestedBy":"' + this.userData.ClientCode + '",';
    TransferString += '"SegmentAccount":"' + this.segmentModel + '",';
    TransferString += '"BranchCode":"",';
    if(this.globalVariableService.clientName == 'Ajcon' && this.bank_codeFlg == false){
      TransferString += '"PaymentGateway":"BOI",';
    }
    else if(this.globalVariableService.clientName == 'FirstGlobal' || this.globalVariableService.clientName=='Arch'){
      TransferString += '"PaymentGateway":"ATOM",';
    } else if(this.globalVariableService.clientName == 'Bgse'){
      TransferString += '"PaymentGateway":"RazorPay",';
        enterAmt = (this.transferObject.Amount * 100)
      // this.transferObject.Amount = (this.transferObject.Amount * 100)

    } else{  TransferString += '"PaymentGateway":"TPSL",'; }
    TransferString += '"Remarks":"",';
    TransferString += '"BankName":"' + this.bankModel.BankCode + '",';
    TransferString += '"Amount":"' + enterAmt + '",';
    TransferString += '"AccountNo":"' + this.bankAccountNumber + '",';
    TransferString += '"Exchange":"' + this.exchangeModel + '",';
    TransferString += '"ProductID":"' + this.exchangeModel + '"';
    TransferString += '}';

    // if(this.globalVariableService.clientName == 'Ajcon'){
    //   TransferString['PaymentGateway'] = 'BOI';
    // }else{
    //   TransferString['PaymentGateway'] = 'TPSL'
    // }

    //--Service to Execute fund transfer --
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.executeFundTransfer(TransferString).then((data)=>{
      this.ngProgress.done();
      this.fundTransfer_result = data;
      if(this.fundTransfer_result.ErrorCode==0){

        if(this.globalVariableService.clientName == 'Ajcon' && this.bank_codeFlg == false){
          swal({
            title: "Success!",
            text: this.fundTransfer_result.Message+', Ref No: '+this.fundTransfer_result.ReferenceNumber,
            type: 'success',
            showCancelButton: false,
            cancelButtonText: "Cancel!",
            confirmButtonColor: "#387ef5",
            confirmButtonText: "OK"
          });
        }else{
          if (this.globalVariableService.clientName == 'Bgse') {
          const winUrl = URL.createObjectURL(
              new Blob([this.fundTransfer_result.FundTransferURL], { type: "text/html" })
          );
          
          const win = window.open(
              winUrl,
              "win",
              `width=800,height=400,screenX=200,screenY=200`
          );

          } else {
          window.open(this.fundTransfer_result.FundTransferURL, '_blank', 'location=yes');
          }
        }
       

        this.transferObject.Amount = '';
      }else{
        swal({
          title: "Error!",
          text: this.fundTransfer_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //---ValidateHoldRequest --
  ValidateHoldRequest(){
    //console.log("this. ",this.transferObject)
    if(this.transferObject.Amount<=0 || this.transferObject.Amount === ''|| this.transferObject.Amount ===undefined){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount cannot be less than Rs. 0",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
      return;
    }else{
      swal({
        title: 'Fund Hold Details',
        html: "'<b>'Segment:'</b>' " + this.segmentModel + " , <b>Bank:</b> " + this.bankModel.BankCode + ", <b>Amount:</b> " + this.transferObject.Amount + "",
        type: 'info',
        showCancelButton: true,
        cancelButtonText: "Cancel!",
        confirmButtonColor: "#387ef5",
        confirmButtonText: "Hold"
        }).then((result) => {
        if (result.value) {
            //---User want to Place order--
            this.FundHold();
          }
        })
    }
  }
  FundHold(){
    var TransferString = '?RequestObject={';
    TransferString += '"SessionNo":"' + this.userData.SessionNo + '",';
    TransferString += '"Source":"' + '5' + '",';
    TransferString += '"ClientCode":"' + this.userData.ClientCode + '",';
    TransferString += '"Segment":"' + this.segmentModel + '",';
    TransferString += '"BankName":"' + this.bankModel.BankCode + '",';
    TransferString += '"Amount":"' + this.transferObject.Amount + '",';
    TransferString += '}';

    //--Service to Execute fund transfer --
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.executeFundHold(TransferString).then((data)=>{
      this.ngProgress.done();
      this.fundHold_result = data;
      if(this.fundHold_result.ErrorCode==0 && this.fundHold_result.Message != null){
        swal({
          title: "Fund Hold Successful",
          text: this.fundHold_result.Message,
          type: "success",
          showConfirmButton: true,
      })
        this.transferObject.Amount = '';
        this.GetLienBalance();
      }else if (this.fundHold_result.ErrorCode == '-100') {
          swal({
              title: "Error!",
              text: "Fund transfer rejected by Bank",
              timer: 3000,
              showConfirmButton: false
          });
      }
      else{
        swal({
          title: "Error!",
          text: this.fundHold_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //---ValidateRelease--
  ValidateRelease(){
    if(this.transferObject.releaseAmount == this.GetLienAvailableBalance){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount should be less then .1 paisa from availabe amount.",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
      return;
    }
    if(this.transferObject.releaseAmount<=0 || this.transferObject.releaseAmount === ''|| this.transferObject.releaseAmount ===undefined){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount cannot be less than Rs. 0",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
    }else if(this.transferObject.releaseAmount > this.GetLienAvailableBalance){
      swal({
          title: "Invalid Amount",
          type: "error",
          text: "Requested amount cannot be greater than available balance",
          timer: 1500,
          allowOutsideClick: true,
          showConfirmButton: true
      });
    }else{
      swal({
        title: 'Fund Release Details',
        html: "'<b>'Segment:'</b>' " + this.segmentModel + " , <b>Bank:</b> " + this.bankModel.BankCode + ", <b>Amount:</b> " + this.transferObject.releaseAmount + "",
        type: 'info',
        showCancelButton: true,
        cancelButtonText: "Cancel!",
        confirmButtonColor: "#387ef5",
        confirmButtonText: "Release"
        }).then((result) => {
        if (result.value) {
            //---User want to Place order--
            this.FundRelease();
          }
        })
    }
  }

  //---Fund Release --
  FundRelease(){
    var TransferString = '?RequestObject={';
    TransferString += '"SessionNo":"' + this.userData.SessionNo + '",';
    TransferString += '"Source":"' + '5' + '",';
    TransferString += '"ClientCode":"' + this.userData.ClientCode + '",';
    TransferString += '"Segment":"' + this.segmentModel + '",';
    TransferString += '"BankName":"' + this.bankModel.BankCode + '",';
    TransferString += '"Amount":"' + this.transferObject.releaseAmount + '",';
    TransferString += '}';

    //--Service to Execute fund transfer --
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getFundManagement.executeFundRelease(TransferString).then((data)=>{
      this.ngProgress.done();
      this.fundRelease_result = data;
      if(this.fundRelease_result.ErrorCode==0 && this.fundRelease_result.Message != null){
        swal({
          title: "Fund Release Successful",
          text: this.fundRelease_result.Message,
          type: "success",
          showConfirmButton: true,
      })
        this.transferObject.releaseAmount = '';
        this.GetLienBalance();
      }else if (this.fundHold_result.ErrorCode == '-100') {
          swal({
              title: "Error!",
              text: "Fund transfer rejected by Bank",
              timer: 3000,
              showConfirmButton: false
          });
      }
      else{
        swal({
          title: "Error!",
          text: this.fundHold_result.Message,
          timer: 2000,
          showConfirmButton: false
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  
}
