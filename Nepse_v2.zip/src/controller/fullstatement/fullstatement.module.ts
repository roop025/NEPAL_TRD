import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FullstatementPage } from './fullstatement';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    FullstatementPage,
  ],
  imports: [SharedModule,
    IonicPageModule.forChild(FullstatementPage),
  ],
})
export class FullstatementPageModule {}
