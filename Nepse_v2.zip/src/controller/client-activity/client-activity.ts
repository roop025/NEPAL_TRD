import { Component } from '@angular/core';
import { NavController , IonicPage} from 'ionic-angular';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { NgProgress } from 'ngx-progressbar';
import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';

@IonicPage()
@Component({
  selector: 'page-history-report',
  templateUrl: '../../pages/DionWhite/client-activity/client-activity.html'
})

export class ClientActivityPage {
  //public setName : any;
  public userData : any;
  public progressBarColor : any;
  public client_activity_result : any;
  public items : any;
  public message : any;
  public totalHoldingValue : any;
  public ClientName : any;
  private logoutFrmData : any;
  private showWithAutoAms1 : any;
  private   user_logout_result: any = '';
  shownGroup = null;

  public selectExchange:any = '';
  public scriptName:any;
  public fromDate:any = 'dd/mm/yyyy';
  public toDate:any = 'dd/mm/yyyy';
  public allExchange: any;
  public availableExchangearray: any;
  public userAllowedExchange: any;


  constructor(public navCtrl: NavController,
  public getReportManager : ReportProvider,
  public ngProgress: NgProgress,
  private storage:Storage,
  private common:CommonProvider,
  private userManager:UserManagerProvider,
  private globalVariableService : GlobalVariableService,
  ) {
    this.totalHoldingValue=0.00;
    this.showWithAutoAms1=false;
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"HoldingsPage"});
    this.ClientName = globalVariableService.clientName;
    this.userAllowedExchange=[];
    this.scriptName = '';

  }
  ionViewDidLoad(){
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
         console.log("this.userData",this.userData)
         this.showWithAutoAms1=true;
       }
       //---Load net position --
       this.loadAllowExchaneg();
    });

    //console.log("test from login")

  }

  loadAllowExchaneg(){
    this.allExchange=this.userData.ExchangeMarketSegmentList;
    //---Split the section for exchange value and extract the allowed exchange from the even index of the ExchangeMarketSegmentList--
    this.availableExchangearray=this.allExchange.split("^");
    for(var i = 0; i < this.availableExchangearray.length; i += 2) {  // take every second element
        this.userAllowedExchange.push(this.availableExchangearray[i]);
    }
  }

  //---Load Asset report --
  loadClientActivityReport(){
    var ValidityFromDate = this.formatDate(this.fromDate);
    var ValidityToDate = this.formatDate(this.toDate);
    this.userData['ValidityFromDate'] = ValidityFromDate;
    this.userData['ValidityToDate'] = ValidityToDate;
    this.userData['exchangeName'] = this.selectExchange;
    this.userData['scriptName'] = this.scriptName;

    console.log(this.userData);

    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getClientActivityReport("ALL","PendingOrder",this.userData,"").then((data)=>{  
      this.ngProgress.done();
      this.client_activity_result = data;
      if(this.client_activity_result.reportTable=="" || this.client_activity_result.reportTable==null){
        this.items = '';
        this.message=this.client_activity_result.Message
      }else{
        this.items = JSON.parse(this.client_activity_result.reportTable);
        // console.log("this.orderitems",this.items)
        //---call function to identify underlying,expiry,option and strike
        this.totalHoldingValue=0;
        this.items.forEach((value, index) => {
          // this.items[index]["exchange"]=this.items[index].Exchange;
          // this.items[index]["ticker"]=this.items[index].underlying;
          this.globalVariableService.setData({ watchlistItems: this.items });

          //---Calculation of totalHoldingValue--
          this.totalHoldingValue += parseFloat(value.MarketValue);

        });

      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }




  //---//--pull down to refresh --
  doRefresh(refresher) {
    // this.loadAssetReport()
    setTimeout(() => {
      refresher.complete();
    }, 1000);
  }


 //--Function to format date --
 formatDate(date) {
  var dd = new Date(date),
      month = '' + (dd.getMonth() + 1),
      day = '' + dd.getDate(),
      year = dd.getFullYear();
  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;
  return [year, month, day].join('-');
  }
}
