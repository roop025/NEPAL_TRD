import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClientActivityPage } from './client-activity';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    ClientActivityPage,
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    IonicPageModule.forChild(ClientActivityPage),
  ],
})
export class ClientActivityPageModule {}
