import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinancialDataPage } from './financial-data';
//import { quoteHeaderPage } from '../quote-header/quote-header';
import { NvD3Module } from 'ng2-nvd3';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';
// import { ProgressBarComponent } from '../../components/progress-bar/progress-bar';
import { ComponentsModule } from '../../components/components.module';
@NgModule({
  declarations: [
    FinancialDataPage
    //quoteHeaderPage
  ],
  imports: [
    ComponentsModule,
    NvD3Module,
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(FinancialDataPage)
  ],
})
export class MarketDepthPageModule {}
