import { Component, ViewChild, ChangeDetectorRef, ElementRef } from '@angular/core';
import { NavController, IonicPage, NavParams, Events, Navbar, PopoverController, FabButton, Slides, ViewController } from 'ionic-angular';
import { MarketDepthProvider } from '../../providers/market-depth/market-depth';
import { ReportProvider } from '../../providers/report/report';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import { QuoteHeaderProvider } from '../../providers/quote-header/quote-header';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import swal from 'sweetalert2';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { MfContentProvider } from '../../providers/mf-content/mf-content';

@IonicPage()
@Component({
  selector: 'page-financial-data',
  templateUrl: '../../pages/DionWhite/financial-data/financial-data.html'
})

export class FinancialDataPage {

  public item: any;
  public GetCompanyInformationData: any;
  public clientUserData: any;
  public scripOrderReport_result: any;
  public orderitems: any;
  public tradeOrderReport_result: any;
  public tradeitems: any;
  public marketDepth_result: any;
  public TotalBuyQty: any;
  public TotalSellQty: any;
  public ClientName: any;
  public tabsSection: any;
  public headingName: any;
  public itemNews: any;
  selectedTabIndex: any;
  activeInd: any = 1;

  public newsData: any;
  newsId: any;
  newsDetails: any;
  options;
  data;
  public newsList: any[] = [];
  public volumeAnalysis: any;
  public priceAnalysis: any;
  public movingAverage: any;
  public financial_data: any[] = [];
  f_reportType: any = 'c';
  pivot_points: any = {};
  pivot_type: any = 'Classic';
  loadProgress = 100
  ISIN: any
  exchange: any
  ticker: any
  // finance_report_keys:any[]

  @ViewChild(Navbar) navBar: Navbar;
  @ViewChild(Slides) slides: Slides;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public marketDepthManager: MarketDepthProvider,
    public getReportManager: ReportProvider,
    public socket: WebsocketProvider,
    private clientMarketWatchList: GlobalVariableService,
    private commonService: CommonProvider,
    public popoverCtrl: PopoverController,
    private quoteHeaderManager: QuoteHeaderProvider,
    private theInAppBrowser: InAppBrowser,
    private ev: Events,
    public websocketUtilityManager: WebsocketUtilityService,
    private changeDetectorRef: ChangeDetectorRef,
    public eref: ElementRef,
    public mfContentProvider: MfContentProvider, public viewCtrl: ViewController
  ) {

    //console.log("this.depthdata",this.depthdata)
    this.ev.subscribe('checkBiddersData', data => {
      // this.onLoginRegister();
      this.TotalBuyQty = this.clientMarketWatchList.getTotalBuyers();
    });
    this.ev.subscribe('checkSellersData', data => {
      // this.onLoginRegister();
      this.TotalSellQty = this.clientMarketWatchList.getTotalSellers();
    });
    this.ClientName = clientMarketWatchList.clientName;

  }

  ionViewDidLoad() {
    // this.headingName = 'Finacial'
    this.item = this.navParams.get('userMWDepthData');
    this.clientUserData = this.navParams.get('clientUserData');
    this.tabsSection = this.navParams.get('selected_segment')

    this.ticker = this.item.ticker
    this.exchange = this.item.exchange
    this.ISIN = this.item.ISIN

    this.getNewsAndEvents();
    this.getFInanceReport();
    this.volumeAnalysisReport();
    this.priceAnalysisReport()
    this.getPivotReport()

    // if (this.tabsSection == 'financialTab') {
    //   this.slides.slideTo(2)
    // }
    // this.segmentChanged(this.tabsSection)
  }


  ionViewDidEnter() {
     if (this.tabsSection == 'technicalTab') {
      this.slides.slideTo(0)
    }if (this.tabsSection == 'financialTab') {
      this.slides.slideTo(2)
    }if (this.tabsSection == 'newsEventTab') {
      this.slides.slideTo(3)
    }if (this.tabsSection == 'priceVolTab') {
      this.slides.slideTo(1)
    }
    //clearInterval(this.intervalId);
  }


  //  --------------------------Change status for Active Inactive




  change(value) {
    if (value.length > 10) {
      return true;
    } else {
      return false;
    }

  }



  onSlideDidChange() {
    let currentIndex = this.slides.getActiveIndex();
    console.log('Current index is', currentIndex);
    if (currentIndex == 0) {
      this.tabsSection = 'technicalTab';
    }
    else if (currentIndex == 2) {
      this.tabsSection = 'financialTab';
    }
    else if (currentIndex == 3) {
      this.tabsSection = 'newsEventTab';
    }
    else if (currentIndex == 1) {
      this.tabsSection = 'priceVolTab';
    }
    //  else {
    //   this.tabsSection = 'technicalTab';
    // }
  }


  segmentChanged(value) {
    console.log(value._value)
    if (value._value == 'technicalTab') {
      this.slides.slideTo(0)
    }
    else if (value._value == 'financialTab') {
      this.slides.slideTo(2)
    }
    else if (value._value == 'newsEventTab') {
      this.slides.slideTo(3)
    }
    else if (value._value == 'priceVolTab') {
      this.slides.slideTo(1)
    }

    // else {
    //   this.slides.slideTo(0)
    // }
  }



  getNewsAndEvents() {
    this.mfContentProvider.getCompanyNews(this.ISIN).then((compny_news: any) => {
      console.log("Company news", compny_news);
      if (compny_news.ErrorCode == 0) {
        this.newsData = JSON.parse(compny_news.ReportTable)
        console.log("News List", this.newsData);

      }
    }).catch(err => {
      console.log("Errrrrrrr", err);

    })



  }




  async getNewsContent(news, id) {
    this.newsId = id;
    this.newsDetails = '';
    await this.mfContentProvider.getCompanyNewsDetails(news.NewsId).then((compny_news: any) => {
      console.log("Company news", compny_news);
      if (compny_news.ErrorCode == 0) {
        let newsData = JSON.parse(compny_news.ReportTable)
        console.log("Deatils List", newsData[0].NewsText);
        this.newsDetails = newsData[0].NewsText
        // return nd
      }
      else {
        // return ''
      }
    }).catch(err => {
      console.log("Errrrrrrr", err);
      // return ''
    })

  }

  f_arrr: any[] = []

  async getFInanceReport() {
    // this.f_arrr=['Mar 19','Mar 18','Mar 17','Mar 16','Mar 15'];
    await this.mfContentProvider.getFinancialData(this.ISIN, this.f_reportType).then((finance_d: any) => {
      console.log("Finane d", finance_d);
      if (finance_d.ErrorCode == 0) {
        let newsData = JSON.parse(finance_d.ReportTable)
        console.log("Overall Financial report consolidated", JSON.stringify(newsData));
        this.financial_data = newsData.IncomeStatement;
        // for(let f of this.financial_data)
        // {
        Object.keys(this.financial_data[0]).forEach((key) => {
          console.log('Key : ' + key + ', Value : ' + this.financial_data[0][key])
          this.f_arrr.push(key)
        })

        // }
        console.log("<??????>>>>>>>>>>>", this.f_arrr);

        // return nd
      }
      else {
        // return ''
      }
    }).catch(err => {
      console.log("Errrrrrrr", err);
      // return ''
    })

  }

  async volumeAnalysisReport() {
    await this.mfContentProvider.getVolumeAnalysis(this.ISIN, this.exchange).then((finance_d: any) => {
      console.log("Finane d", finance_d);
      if (finance_d.ErrorCode == 0) {
        let newsData = JSON.parse(finance_d.ReportTable)
        console.log("Volum Annalysis", newsData);
        if (newsData.length > 0)
          this.volumeAnalysis = newsData[0];
        // return nd
      }
      else {
        // return ''
      }
    }).catch(err => {
      console.log("Errrrrrrr", err);
      // return ''
    })

  }

  async priceAnalysisReport() {
    await this.mfContentProvider.getPriceAnalysis(this.ISIN, this.exchange).then((finance_d: any) => {
      console.log("Finane d", finance_d);
      if (finance_d.ErrorCode == 0) {
        let newsData = JSON.parse(finance_d.ReportTable)
        console.log("Price Analysis", newsData);
        if (newsData.length > 0)
          this.priceAnalysis = newsData[0];
        // return nd
      }
      else {
        // return ''
      }
    }).catch(err => {
      console.log("Errrrrrrr", err);
      // return ''
    })

  }




  async movingAverageReport() {
    await this.mfContentProvider.getMovingAverage(this.ISIN, this.exchange).then((finance_d: any) => {
      console.log("Finane d", finance_d);
      if (finance_d.ErrorCode == 0) {
        let newsData = JSON.parse(finance_d.ReportTable[0])
        console.log("Overall dddddd", newsData);
        this.movingAverage = newsData;

        // return nd
      }
      else {
        // return ''
      }
    }).catch(err => {
      console.log("Errrrrrrr", err);
      // return ''
    })

  }

  financeReportType(value) {
    this.f_reportType = value;
    this.getFInanceReport();
  }

  getPivotReport() {
    this.mfContentProvider.GetPivotPoint(this.exchange, this.ticker, this.pivot_type).then((data: any) => {
      if (data.ErrorCode == 0) {
        let newsData = JSON.parse(data.data)
        console.log("Overall dddddd", newsData);
        this.pivot_points = newsData;
        // this.movingAverage=newsData;

        // return nd
      }
      else {
        // return ''
      }
    }).catch(err => {

    })
  }

  changePivote() {
    this.getPivotReport()
  }
  backMe() {
    this.viewCtrl.dismiss()
  }

}
