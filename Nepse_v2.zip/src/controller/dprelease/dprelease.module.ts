import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DpreleasePage } from './dprelease';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';
// import { HeatMapDirective } from '../../directives/heat-map/heat-map';
// import { BidAskHighlighterDirective } from '../../directives/bidaskhighlighter/bidaskhighlighter';


@NgModule({
  declarations: [
    DpreleasePage,
    // HeatMapDirective,
    // BidAskHighlighterDirective
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(DpreleasePage),
  ],
})
export class DpreleasePageModule {}
