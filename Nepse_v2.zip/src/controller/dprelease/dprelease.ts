import { Component } from '@angular/core';
import { NavController , IonicPage,Events } from 'ionic-angular';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';

import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';

@IonicPage()
@Component({
  selector: 'page-dprelease',
  templateUrl: '../../pages/DionWhite/dprelease/dprelease.html'
})

export class DpreleasePage {

  public progressBarColor : any;
  public userData : any;
  public netPosition_result : any;
  public items : any;
  public message : any;
  public spreadType : any;
  public m2m : any;
  public bpl : any;
  public filterargs : any;
  public ClientName : any;
  public negativeVal : any;
  public ticker_result : any;
  public footerTickerData : any;
  private logoutFrmData : any;
  private   user_logout_result: any = '';
  shownGroup = null;

  constructor(public navCtrl: NavController,
    public ngProgress: NgProgress,
    private globalVariableService : GlobalVariableService,
    public getReportManager : ReportProvider,
    public websocketUtilityManager: WebsocketUtilityService,
    public socket: WebsocketProvider,
    private marketWatchManager:MarketWatchProvider,
    private storage:Storage,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private ev:Events
  ) {
    this.m2m=0.00;
    this.bpl=0.00;

    this.ev.subscribe('checkFilterArgument',data=>{
      //alert(data.indexSel)
      if(data.indexSel == "Exchange"){
        this.filterargs = {exchange: data.valueSel};
      }else if(data.indexSel == "Scrip"){
        this.filterargs = {underlying: data.valueSel};
      }else if(data.indexSel == "TradingAccount"){
        this.filterargs = {TradingAccount: data.valueSel};
      }else if(data.indexSel == "Status"){
        this.filterargs = {OrderStatus: data.valueSel};
      }else if(data.indexSel == "BuySellType"){
        this.filterargs = {BuySellType: data.valueSel};
      }
      else{
        this.filterargs = {all: data.valueSel};
      }
    });
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"NetPositionPage"});
    this.ClientName = globalVariableService.clientName;
  }

  ionViewDidLoad(){
    //this.negativeVal=false;
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //---Load net position --
       this.loadReleaseList();
    });

  }

  loadReleaseList(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getScripOrderReport("ALL","DPFreeStock",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.netPosition_result = data;
      if(this.netPosition_result.reportTable=="" || this.netPosition_result.reportTable==null){
        this.items = '';
        this.message=this.netPosition_result.Message
      }else{
        this.items = JSON.parse(this.netPosition_result.reportTable);
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });

  }


  goToRelease(obj){
    console.log(obj);
    this.navCtrl.push('DpreleasereportPage',{"holdObj":obj},null);
  }




  //---//--pull down to refresh --
  doRefresh(refresher) {
    //this.loadNetPosition()
    setTimeout(() => {
      refresher.complete();
    }, 1000);
  }


    /*set exchange code in order to build keylist to register for feed.*/
    GetExchangeCode(Exchange) {
        var strCode = "0";
        switch (Exchange) {
            case "NSE":
            case "FONSE":
                strCode = "4";
                break;
            case "BSE":
            case "FOBSE":
                strCode = "1";
                break;
            case "ACE":
                strCode = "10";
                break;
            case "CDNSE":
                strCode = "13";
                break;
            case "MCX":
                strCode = "7";
                break;
            case "COMNSE":
                strCode = "5";
                break;
            case "NCDEX":
                strCode = "8";
                break;
            case "MCXSX":
                strCode = "14";
                break;
            case "NSEL":
                strCode = "36";
                break;
            case "MCXSXEQ":
                strCode = "64";
                break;
            case "MCXSXFO":
                strCode = "65";
                break;
            case "CDBSE":
                strCode = "17";
                break;
        }
        return (strCode);
    }
    toggleGroup(group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
        } else {
            this.shownGroup = group;
        }
      };
      isGroupShown(group) {
        return this.shownGroup === group;
      };
}
