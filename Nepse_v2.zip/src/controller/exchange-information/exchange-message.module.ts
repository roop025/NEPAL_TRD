import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExchangeMessagePage } from './exchange-message';

@NgModule({
  declarations: [
    ExchangeMessagePage
  ],
  imports: [
    IonicPageModule.forChild(ExchangeMessagePage),
  ],
})
export class ExchangeMessagePageModule {}
