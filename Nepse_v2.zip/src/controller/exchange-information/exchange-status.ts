import { Component } from '@angular/core';
import { NavController , IonicPage } from 'ionic-angular';
import { ExchangeInformationProvider } from '../../providers/exchange-information/exchange-information';
import swal from 'sweetalert2';
import { NgProgress } from 'ngx-progressbar';


@IonicPage()
@Component({
  selector: 'page-exchangeInformation',
  templateUrl: '../../pages/DionWhite/exchange-information/exchange-status.html'
})

export class ExchangeStatusPage {
  public ExchangeStatusList : any;
  public ExchangeStatusFullList : any;
  public exc_result : any;
  public progressBarColor : any;

  constructor(public navCtrl: NavController,
    private exchangeInformationManager:ExchangeInformationProvider,public ngProgress: NgProgress) {
      this.progressBarColor = 'white'
      this.ExchangeStatusList=[];
      this.loadMarketStatus();
  }

  ionViewDidLoad(){
    //console.log("test from login")

      // PreOpen Market
      // Regular Market
      // PostClose Market
      // PreOpen Matching
      // After Market Order
      // Market Close 
  }

  loadMarketStatus(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.ExchangeStatusList=[];
    this.exchangeInformationManager.getExchInfo().then((data)=>{
      this.exc_result = data;
      if(this.exc_result.ErrorCode==0){
        this.ExchangeStatusFullList = JSON.parse(this.exc_result.data);
        this.ExchangeStatusList=this.ExchangeStatusFullList  
        // this.ExchangeStatusFullList.forEach((value, index) => {
        //     if(this.ExchangeStatusFullList[index].Exchange==="NSE"){
        //          this.ExchangeStatusFullList[index].Exchange="NSE Cash";
        //         this.ExchangeStatusList.push(this.ExchangeStatusFullList[index]);
        //     }
        //     if(this.ExchangeStatusFullList[index].Exchange==="BSE"){
        //          this.ExchangeStatusFullList[index].Exchange="BSE Cash";
        //         this.ExchangeStatusList.push(this.ExchangeStatusFullList[index]);
        //     }
        //     if(this.ExchangeStatusFullList[index].Exchange==="FONSE"){
        //          this.ExchangeStatusFullList[index].Exchange="NSE F&O";
        //         this.ExchangeStatusList.push(this.ExchangeStatusFullList[index]);
        //     }
        //     if(this.ExchangeStatusFullList[index].Exchange==="CDNSE"){
        //          this.ExchangeStatusFullList[index].Exchange="NSE Curr";
        //         this.ExchangeStatusList.push(this.ExchangeStatusFullList[index]);
        //     }
        // });
        this.progressBarColor = 'Green'
        this.ngProgress.done();
      }

    }, err=> {
      // this.common.hideLoading();
      swal({
          // title: "Error!",
          text: "Oops, Something went wrong.",
          timer: 2000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });

  }
  doRefresh(refresher){
    this.loadMarketStatus();
    setTimeout(() => {
      refresher.complete();
    }, 500);

  }
}
