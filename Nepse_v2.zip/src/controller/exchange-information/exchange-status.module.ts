import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExchangeStatusPage } from './exchange-status';
import { NgProgressModule } from 'ngx-progressbar';

@NgModule({
  declarations: [
    ExchangeStatusPage
  ],
  imports: [
    NgProgressModule,
    IonicPageModule.forChild(ExchangeStatusPage),
  ],
})
export class ExchangeStatusPageModule {}
