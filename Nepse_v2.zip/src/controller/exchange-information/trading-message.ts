import { Component } from '@angular/core';
import { NavController , IonicPage,Events } from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';


@IonicPage()
@Component({
  selector: 'page-exchangeInformation',
  templateUrl: '../../pages/DionWhite/exchange-information/trading-message.html'
})

export class TradingMessagePage {

  public showMarketMsg : any;
  public ClientName : any;
  constructor(public navCtrl: NavController,private ev:Events,private clientMarketWatchList : GlobalVariableService,) {
    this.ClientName = clientMarketWatchList.clientName;
    this.showMarketMsg = this.clientMarketWatchList.getTradingMessages();
    this.ev.subscribe('checkTradingMessageData',data=>{
      this.showMarketMsg = this.clientMarketWatchList.getTradingMessages();
      console.log("this.showMarketMsg",this.showMarketMsg)
    });
    console.log("this.showMarketMsg",this.showMarketMsg)
  }

  ionViewDidLoad(){
    //console.log("test from login")
    this.ev.subscribe('checkTradingMessageData',data=>{
      this.showMarketMsg = this.clientMarketWatchList.getTradingMessages();
      console.log("this.showMarketMsg",this.showMarketMsg)
    });
  }

}
