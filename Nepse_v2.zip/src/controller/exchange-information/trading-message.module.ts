import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TradingMessagePage } from './trading-message';

@NgModule({
  declarations: [
    TradingMessagePage
  ],
  imports: [
    IonicPageModule.forChild(TradingMessagePage),
  ],
})
export class TradingMessagePageModule {}
