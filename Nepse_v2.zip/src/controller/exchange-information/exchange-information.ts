import { Component } from '@angular/core';
import { NavController , IonicPage } from 'ionic-angular';




@IonicPage()
@Component({
  selector: 'page-exchangeInformation',
  templateUrl: '../../pages/DionWhite/exchange-information/exchange-information.html'
})

export class ExchangeInformationPage {
  // public setName : any;
  tab1Root = 'ExchangeMessagePage';
  tab2Root = 'ExchangeStatusPage';
  tab3Root = 'TradingMessagePage';
  constructor(public navCtrl: NavController) {


  }

  ionViewDidLoad(){
    //console.log("test from login")
  }

}
