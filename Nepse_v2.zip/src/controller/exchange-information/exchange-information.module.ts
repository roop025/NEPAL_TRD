import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExchangeInformationPage } from './exchange-information';

@NgModule({
  declarations: [
    ExchangeInformationPage
  ],
  imports: [
    IonicPageModule.forChild(ExchangeInformationPage),
  ],
})
export class ExchangeInformationPageModule {}
