import { Component,ViewChild } from '@angular/core';
import { NavController , IonicPage, ViewController ,Navbar,Events} from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { Storage } from '@ionic/storage';
// import  data  from  '../../assets/DionBlack/contactInfo.json';

declare var require:any
declare var Camera:any
declare var navigator:any

@IonicPage()
@Component({
  selector: 'page-accounting',
  templateUrl: '../../pages/DionWhite/accounting/accounting.html'
})

export class AccountingPage { 

  @ViewChild(Navbar) navBar: Navbar;

  public setName : any;
  public ClientName : any;
  public fromDate:any;
  public toDate:any;
  public userData : any;
  public activeClientData:any;

  constructor(
    public navCtrl: NavController,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    private ev: Events,
    private userManager:UserManagerProvider,
    private storage:Storage,public viewCtrl: ViewController
    ) {

    this.ClientName = globalVar.clientName;
    // this.activeClient = globalVar.getActiveClientData(globalVar.activeClient);

  }

  ionViewDidLoad(){
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
    });

    this.ev.subscribe('closePopup', data => {
      this.closed();
    });
  }

  ngOnInit(){
    this.activeClientData = require("../../assets/DionBlack/contactInfo.json");
  }

  closed(){
    this.viewCtrl.dismiss({adults:"0"})
  }

  public withdrawl(){
    let alerttext = 'hhhkhh'
    swal({
        html: "<p class='swvalue'> 46698876.09 </p> <p id='gTradePwS' class='swvlbl'>Available Collateral</p> <br>",
        input: 'number',
        inputPlaceholder: "Enter the withdrawal amount",
      // type: 'question',
      //footer:this.textMessage[0],
      customClass: 'withdwlCss',
      showCancelButton: true,
      cancelButtonText: "RESET",
      confirmButtonColor: "rgb(254 203 47)",
      confirmButtonText: "WITHDRAW"
  }).then((result) => {
      if (result.value) {
          //---User want to Place order--
         
      }
  })

  }




  public gotoFullstatment(){
    this.navCtrl.push('FullstatementPage');

  }


// public abcd(){
//   document.addEventListener("DOMContentLoaded", this.onDeviceReady, false);

// }

public click(){
    
  document.addEventListener('deviceready', function() {

  //   <div style="text-align: center;">                                                   
  //   <video id="video" style="text-align: center; border-radius: 20px;"></video>
  // </div>
  // <div  style="text-align: center;">
  //     <button type="button" class="btn btn-warning" onclick="clickPhoto();">Take Photo</button>
  //  </div>
  //  <div style="text-align: center;">
  //     <canvas id="myCanvas" width="300" height="300" style="text-align: center; border-radius: 20px;"></canvas>
  // </div>

    // cameraBtn.addEventListener('click', function() {
        // if (!navigator.camera) alert("Camera unavailable")
        // else if (!navigator.camera.getPicture) alert(navigator.camera)
        // navigator.camera.getPicture(
        //     function(imgData) { // success
        //     },
        //     function(msg) { // fail
        //     },
        //     {
        //         quality: 60,
        //         destinationType: Camera.DestinationType.DATA_URL,
        //         sourceType: Camera.PictureSourceType.CAMERA,
        //         mediaType: Camera.MediaType.PICTURE,
        //         encodingType: Camera.EncodingType.JPEG,
        //         cameraDirection: Camera.Direction.BACK,
        //         correctOrientation: true,
        //         targetWidth: 512,
        //         targetHeight: 512
        //     }
        // );
    // });
    if(navigator && navigator.mediaDevices){
      const options = { audio: false, video: { facingMode: "user", width: 300, height: 300  } }
      navigator.mediaDevices.getUserMedia(options)
      .then(function(stream) {
        console.log(stream)
          // video = document.querySelector('video');
          // video.srcObject = stream;
          // video.onloadedmetadata = function(e) {
          //   video.play();
          // };
          // canvas = document.getElementById("myCanvas");
          // ctx = canvas.getContext('2d');
      })
      .catch(function(err) {
          //Handle error here
        console.log("err--->",err)

      });
  }else{
      console.log("camera API is not supported by your browser")
  }
}); 
	
}



}
