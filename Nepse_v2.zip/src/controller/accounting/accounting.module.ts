import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AccountingPage } from './accounting';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    AccountingPage,
  ],
  imports: [SharedModule,
    IonicPageModule.forChild(AccountingPage),
  ],
})
export class FullstatementPageModule {}
