import { Component,ElementRef,ViewChild } from '@angular/core';
import { NavController , IonicPage ,NavParams } from 'ionic-angular';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';


@IonicPage()
@Component({
  selector: 'page-changePasswordFirst',
  templateUrl: '../../pages/DionWhite/changePasswordFirst/changePasswordFirst.html'
})

export class ChangePasswordFirstPage {
  @ViewChild("newpassword") public newpassword: ElementRef;
  @ViewChild("confirmPassword") public confirmPassword: ElementRef;
  public changePasswordFirstFrmData : any;
  public password : any;
  private userLoginData : any;
  private userLoginPassword : any;
  private user_change_password_result : any;
  private firstWords : any;
  private ClientName : any;
  private showPassword : any;
  private showTradePassword : any;
  public activeClient:any
  public activeClientData:any


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private userManager:UserManagerProvider,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    ) {
      
    this.ClientName = globalVar.clientName;

    this.userLoginData = this.navParams.get('useLogindata');
    //console.log("this.userLoginData",this.userLoginData)
    this.firstWords = [];
    this.firstWords = this.userLoginData.Message.replace(/ .*/,'');

    //console.log("this.firstWords ",this.firstWords )
    this.userLoginPassword = this.navParams.get('userPassword');
    this.activeClient = globalVar.getActiveClientData(globalVar.activeClient);


    this.password = {
      newPassword1: '',
      newPassword2: ''
    }
    this.changePasswordFirstFrmData = {
      userId:this.firstWords,
      password:this.userLoginPassword,
      NewPassword:this.password.newPassword1,
      TradePassword:'',
      NewTradePassword:'',
      Source:5,
      Action:'CHANGEPASSWORD',
      ClientIPAddress:'',
      SessionNo:this.userLoginData.SessionNo
    };


    //-----
    this.showPassword=false
    this.showTradePassword=false
  }

  ionViewDidLoad(){
    localStorage.clear();
    //console.log("test from login")
  }

  ngOnInit(){
    // this.activeClientData = require("../../assets/DionBlack/contactInfo.json");
    // this.activeClientData = data
    this.activeClientData = "";
    this.readJsonData()
  }

  readJsonData(){    
    fetch("../../assets/"+this.ClientName+"/contactInfo.json").then(res=>res.json()).then(json=>{
        console.log("OUTPUT: ", json);
        this.activeClientData = json;

        debugger
        //DO YOUR STAFF
    });
}

  frmSubmit(){
    if(this.changePasswordFirstFrmData.userId==''){
      swal({
          //title: "OOPS!",
          text: "All fields are required fields.",
          //type: "error"
      });
    }else if(this.password.newPassword1=='' ){
      swal({
          text: "Please Enter Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.newpassword;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.newpassword;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.password.newPassword2 == ''){
      swal({
          text: "Please Enter Confirm Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.confirmPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.confirmPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }
    else if(this.password.newPassword1!=this.password.newPassword2){
      swal({
          //title: "OOPS!",
          text: "Password and Confirm Password mismatch !",
          //type: "error"
      });
      this.password.newPassword1 ='';
      this.password.newPassword2 ='';
    }else{
      this.changePasswordFirstFrmData.NewPassword = this.password.newPassword1;
      if(this.changePasswordFirstFrmData.SessionNo===''){this.changePasswordFirstFrmData.SessionNo='Forced pwdChangeonLogin'}
      this.common.showLoading();
      this.userManager.changePasswordFirst(this.changePasswordFirstFrmData).then((data)=>{
        this.user_change_password_result = data;
        this.common.hideLoading();
        //----Successfully login ---
        if(this.user_change_password_result.ErrorCode == '0'){
          //console.log("this.user_change_password_result",this.user_change_password_result);
          swal({
              title: "Password Changed",
              type: "success"
          });
          this.navCtrl.push('LoginPage');
        }else if(this.user_change_password_result.ErrorCode == '-1011005'){ //---Login successfully but password expired--
          swal({
              //title: 'OOPS!', //text: 'Modal with a custom image.',
              text: "Invalid password length. Password length allowed minimum 6 & maximum 12 characters.",
              //type: "error"
          });
          this.password.newPassword1 ='';
          this.password.newPassword2 ='';
        }else{//----User does not able to login --
          swal({
              //title: "OOPS!",
              text: "Could not change password." + this.user_change_password_result.Message,
              //type: "error"
          });
        }
      }, err=> {
        this.common.hideLoading();
      });
    }
  }

  //----Hide show password function --\
  hideShowPassword(){
    this.showPassword = !this.showPassword;
  }
  hideShowTradePassword(){
    this.showTradePassword = !this.showTradePassword;
  }
}
