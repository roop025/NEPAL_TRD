import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangePasswordFirstPage } from './changePasswordFirst';

@NgModule({
  declarations: [
    ChangePasswordFirstPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangePasswordFirstPage),
  ],
})
export class ChangePasswordFirstPageModule {}
