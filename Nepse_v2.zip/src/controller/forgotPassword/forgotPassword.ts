import { Component , ViewChild,ElementRef} from '@angular/core';
import { NavController , IonicPage,NavParams } from 'ionic-angular';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { CommonProvider } from '../../providers/common/common';
import swal from 'sweetalert2';
import { GlobalVariableService } from '../../providers/common/global-variable';
// import  data  from  '../../assets/DionBlack/contactInfo.json';


declare var require:any

@IonicPage()
@Component({
  selector: 'page-forgotPassword',
  templateUrl: '../../pages/DionWhite/forgotPassword/forgotPassword.html'
})

export class ForgotPasswordPage {
  @ViewChild("userIdField") public userIdField: ElementRef;
  @ViewChild("userPanField") public userPanField: ElementRef;
  @ViewChild("userBankField") public userBankField: ElementRef;
  public forgotFrmData : any;
  public ForgotPasswordOptions : any;
  public user_ip_result : any;
  public user_forgotForm_result : any;
  public ClientName : any;
  public userLoginFieldData : any;
  public activeClientData:any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private userManager:UserManagerProvider,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    ) {
      this.userLoginFieldData = this.navParams.get('useLogindata');
      // this.activeClient = globalVar.getActiveClientData(globalVar.activeClient);

      //console.log("this.userLoginFieldData",this.userLoginFieldData)
      this.ForgotPasswordOptions = [
        {value: "Login",id: 1,TagType: 'L'},
        {value: "Trade",id: 2,TagType: 'T'}
      ];
      this.forgotFrmData = {
        userId: this.userLoginFieldData.userId,
        password: '',
        Source: 5,
        Action: 'LOGIN',
        TradePassword: '',
        NewPassword: '',
        ClientIPAddress: '',
        SessionNo: '',
        PAN: '',
        ValidateThrough: '',
        DPID: '',
        TagType:'',
        bankaccount:''
      };
      this.ClientName = globalVar.clientName;
  }

  
  ngOnInit(){
    // this.activeClientData = data
    this.activeClientData = require("../../assets/DionWhite/contactInfo.json");

  }

  ionViewDidLoad(){
    //console.log("test from login")
    // this.common.showLoading();
    // this.userManager.getIPAddress().then((data)=>{
    //   this.user_ip_result = data;
    //   this.common.hideLoading();
    //   //----Successfully fetch the ip address of the user ---
    //   this.forgotFrmData.ClientIPAddress = this.user_ip_result;
    // }, err=> {
    //   this.common.hideLoading();
    // });
    this.forgotFrmData.TagType = 'L'
  }

  frmForgotPasswordSubmit(){
    //console.log("this.ClientName",this.ClientName)
    if(this.forgotFrmData.userId==''){
      swal({
          text: "Please Enter User Id",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.userIdField;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.userIdField;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.forgotFrmData.PAN==''){
      swal({
          text: "Please Enter User PAN Number",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.userPanField;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.userPanField;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.forgotFrmData.bankaccount == '' && this.ClientName === 'Canara'){
      if(this.ClientName === 'Canara'){
        this.forgotFrmData.TagType = 'L';
        if(this.forgotFrmData.bankaccount == ''){
          swal({
              text: "Please Enter Bank Account number",
          }).then((result) => {
              if (result.value) {
                setTimeout(() => {
                  var elem:any = this.userBankField;
                  elem._native.nativeElement.focus();
                }, 100);
              }else{
                setTimeout(() => {
                  var elem:any = this.userBankField;
                  elem._native.nativeElement.focus();
                }, 100);
              }
          })
          return
        }
      }
    }else if(this.ClientName === 'Ajcon' && this.forgotFrmData.TagType == ''){
      if(this.forgotFrmData.TagType == ''){
        swal({
            text: "Please Select reset password for option",
        })
      }
    }
    else{
      //--Condition to set the ValidateThrough parameter i.e. client want to reset with email or useId --
      if (this.forgotFrmData.userId.indexOf("@") < 0) {
        this.forgotFrmData.ValidateThrough = 'U';
      } else {
        this.forgotFrmData.ValidateThrough = 'E';
      };
      //--------Calling of forgot password API----------------
        this.common.showLoading();
        this.userManager.forgotPasswrod(this.forgotFrmData).then((data)=>{
          this.user_forgotForm_result = data;
          this.common.hideLoading();
          //----Successfully Forgot password section ---
          if(this.user_forgotForm_result.ErrorCode == '0'){
            swal({
                title: "Reset Successful",
                text: this.user_forgotForm_result.Message,
                type: "success"
            });
            this.navCtrl.push('LoginPage');
          }else{//----User does not able to login --
            swal({
                //title: "OOPS!",
                text: this.user_forgotForm_result.Message,
                //type: "error"
            });
          }
        }, err=> {
          this.common.hideLoading();
        });
    }
  }
}
