import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CapitalGainLossPage } from './capital-gain-loss';

@NgModule({
  declarations: [
    CapitalGainLossPage,
  ],
  imports: [
    IonicPageModule.forChild(CapitalGainLossPage),
  ],
})
export class CapitalGainLossPageModule {}
