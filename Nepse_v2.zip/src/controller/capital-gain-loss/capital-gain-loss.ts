import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController, ActionSheetController } from 'ionic-angular';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { PlaceorderManagerProvider } from '../../providers/placeorder-manager/placeorder-manager';

/**
 * Generated class for the CapitalGainLossPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-capital-gain-loss',
  templateUrl: '../../pages/Bgse/capital-gain-loss/capital-gain-loss.html'

})
export class CapitalGainLossPage {
  private reqObjForCapitalGainLoss: any;
  private capitalGainLossResult: any;
  private userPan: any;
  public showNoData: any;

  constructor(public globalVar: GlobalVariableService,
      public navParams: NavParams,
      private common: CommonProvider,
      public actionSheetCtrl: ActionSheetController,
      private placeorderManager: PlaceorderManagerProvider,
      public menu : MenuController) {
        this.menu.enable(true);
        this.capitalGainLossResult = [];
        // this.userPan = this.globalVar.userDetailFromGetInvestor[0].vcClientPANNo;
        this.userPan = this.globalVar.userPanCard;

        this.loadCapitalGainLossReport();
  }

  loadCapitalGainLossReport(){
    console.log("vcClientPANNo" + this.userPan);
    // console.log("this.globalVar.userDetailFromGetInvestor" + this.globalVar.userDetailFromGetInvestor[0].vcClientPANNo)

    this.reqObjForCapitalGainLoss = {
      FromDate : '',
      ToDate :'',
      PANNo : this.userPan,// jQuery.parseJSON(localStorage.InvestorDetailsObj).PANNo;
      AsOn : '',
      SchemeCodes : '',
      ReportName: "RealizedGLDetail",
      RequestedBy:this.globalVar.clientId,
      ClientCode:this.globalVar.clientId,
      Status:"-1",
      ResponseType : "2",
    }

    this.common.showLoading();
    var capitalGainLossResult: any;
    this.placeorderManager.FundBossDownloadReport((this.reqObjForCapitalGainLoss)).then((data) => {
      this.common.hideLoading();
      capitalGainLossResult = data;
    console.log(data);
    
      if(capitalGainLossResult.ErrorCode == '0'){
        if(capitalGainLossResult.ReportTable != null){
          this.capitalGainLossResult = capitalGainLossResult.ReportTable;
        }
        if(this.capitalGainLossResult.length == 0){
          this.showNoData = true;
        } else this.showNoData = false;
      console.log("this.capitalGainLossResult"+ JSON.stringify(this.capitalGainLossResult));
      }
      // else{
      // }
    },(err) =>{
      // console.log("err" + err)
      this.common.hideLoading();
      swal({
        title: 'OOPS!',
        text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
        type: "error"
      });
      this.common.hideLoading();
  })
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad CapitalGainLossPage');
  }

}
