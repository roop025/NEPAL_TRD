import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController, ActionSheetController } from 'ionic-angular';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { PlaceorderManagerProvider } from '../../providers/placeorder-manager/placeorder-manager';
import { AlertController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-cart',
  templateUrl: '../../pages/DionBlack/cart/cart.html',
})
export class CartPage {
  private reqObjForCart: any;
  public cartResult : any[]=[];
  public placeMultipleOrder_result: any;
  public deleteFromCart: boolean
  public selectedCount : any;
  public successCount : any;
  public isPlaceOrderApiCalled : boolean;

  private sipOrderCount = 0;
  private fpOrderCount = 0;
  private showNoData:boolean = false;

  private selectedOrderList: any;
  private selectedOrderCount: any;

  constructor(public globalVar: GlobalVariableService,
      public navParams: NavParams,
      private common: CommonProvider,
      public actionSheetCtrl: ActionSheetController,
      private placeorderManager: PlaceorderManagerProvider,
      public navCtrl: NavController,
      private alertCtrl: AlertController,
      public menu : MenuController) {
        this.cartResult = [];
        this.getCartList();
        this.deleteFromCart = false;
        this.selectedOrderList =  [];
        this.selectedOrderCount = 0;
      }

      updateToPlaceOrder(obj){
        console.log("obj" + JSON.stringify(obj));
        var index = this.selectedOrderList.indexOf(obj.TxnID);
        if(index == -1){
          if(obj.isSelected){
              this.selectedOrderList.push(obj.TxnID)
          }
        }
        else{
            if(!obj.isSelected){
              this.selectedOrderList.splice(index, 1);
            }
        }

        this.selectedOrderCount = this.selectedOrderList.length;
      }

      twoDigino(deg)
      {
     let num= ('0' + deg).slice(-2);
     return num
      }

  getCartList(){
    let  days=15; // Days you want to subtract
    let date = new Date();
    let last = new Date(date.getTime() - (days * 24 * 60 * 60 * 1000));
    let day:number =last.getDate();
    let month:number=last.getMonth()+1;
    let year=last.getFullYear();
    let from_date= this.twoDigino(day)+'/'+this.twoDigino(month)+'/'+year;
    console.log("from_date",from_date);
    
    let current = new Date();
    let c_day:number =current.getDate();
    let c_month:number=current.getMonth()+1;
    let c_year=current.getFullYear();
    let to_date= this.twoDigino(c_day)+'/'+this.twoDigino(c_month)+'/'+c_year;
    console.log("to_date",to_date);


        this.reqObjForCart = {
          FromDate : from_date,
          ToDate :to_date,
          Status : 'CART',
          ReportName: "OrderBook",
          RequestedBy:this.globalVar.clientId,
          ClientCode:this.globalVar.clientId,
          ResponseType : "2",
        }

        this.common.showLoading();
        let cartResult: any;
        this.placeorderManager.getBSEStarMFServicesDownloadReport((this.reqObjForCart)).then((data) => {
          this.common.hideLoading();
          cartResult = data;
          this.showNoData = true;
          console.log("Cart list",data)
          let cartResultWithoutCheck = cartResult.ReportTable;
          if(cartResult.ErrorCode == '0'){
          this.cartResult = cartResult.ReportTable;
          if(this.cartResult.length == 0){
            this.showNoData = true;
          } else this.showNoData = false
          this.cartResult = cartResultWithoutCheck.map((el)=> {
            let o = Object.assign({}, el);
            o.isSelected = false;
            return o;
          })
          console.log("this.cartResult"+ JSON.stringify(this.cartResult));
          }
          else
          {
            this.cartResult = cartResult.ReportTable;
            if(this.cartResult.length == 0){
              this.showNoData = true;
            } 
          }

        },(err) =>{
          this.common.hideLoading();
          swal({
            title: 'OOPS!',
            text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
            type: "error"
          });
      })
  }

deleteFromCartButton(){
  if(this.selectedOrderCount != 0){
    swal({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, remove it!',
      }).then((result) => {
      if (result.value) {
        this.deleteFromCart = true;
        this.placeOrder()
      } else{
        this.deleteFromCart = false;
        // this.navCtrl.push('CartPage');
      }
  })

} else{

   swal({
       title: 'Notice',
       text: 'Please select a row to remove order',
       type: "error"
     });
 }


}

placeOrderButton(){
  this.deleteFromCart = false;
  if(this.selectedOrderCount != 0){
    this.placeOrder();
  }
  else{
     swal({
         title: 'Notice',
         text: 'Please select a row to place order',
         type: "error"
       });
   }
}

placeOrder(){
  this.selectedCount = 0;
  this.successCount = 0;
  this.isPlaceOrderApiCalled = false;
  this.sipOrderCount = 0;
  this.fpOrderCount = 0;

  for(let x = 0; x < this.cartResult.length; x++){
    if(this.cartResult[x].isSelected){
      this.selectedCount = this.selectedCount + 1;
      var objOrder: any;
      console.log("Cart Result i",this.cartResult[x]);
      
      objOrder = {
        Token: this.cartResult[x].Token,
        ISININo: this.cartResult[x].ISIN,
        ClientCode: this.globalVar.getClientId(),
        Units: this.cartResult[x].Units || '0',
        Amount: this.cartResult[x].Amount,
        CloseAccountFlag: 'N',
        ReinvestmentFlag: 'Z',
        SessionID: this.globalVar.getSessionNo(),
        RequestedBy: this.globalVar.getClientId(),
        KYCFlag: 1,
        FolioNo: this.cartResult[x].FolioNo,
        OrderType:this.cartResult[x].OrderType,
        TxnType: this.cartResult[x].ShortTxnType,
        TXNID: this.cartResult[x].TxnID,
        DPC: this.cartResult[x].DPC,
        EUINFlag: this.cartResult[x].EUINFlag,
        EUINNumber: this.cartResult[x].EUINNumber,
        inBatchID: this.cartResult[x].inBatchID,
        inSubBatchID: this.cartResult[x].inSubBatchID,
        PhysicalFlag: this.cartResult[x].PhysicalFlag,
        RedeemDate: (this.cartResult[x].RedeemDate == null) ? " " : this.cartResult[x].RedeemDate,
        RedeemAmount: this.cartResult[x].RedeemAmount,
        vcRemarks: '',
        MinRedeemFlag: this.cartResult[x].MinRedeemFlag,
        IsSpread: this.cartResult[x].IsSpread,
        OrderSource: 'Mobile',
        StartDay: this.cartResult[x].StartDay,
        StartDate: (this.cartResult[x].StartDate == null) ? " " : this.cartResult[x].StartDate,
        EndDate: (this.cartResult[x].EndDate == null) ? " " : this.cartResult[x].EndDate,
        SIPFrequency: this.cartResult[x].SIPFrequency,
        Tenure: this.cartResult[x].Tenure,
        GenrateToday: this.cartResult[x].GenrateToday,
        MandateID: this.cartResult[x].MandateID,
        Brokerage: 0,
        ExchangeReferneceNo: '',
        SwitchSchemeISIN: '',
        SwitchSchemeSchemeCode: '',
        SchemeCode: this.cartResult[x].SchemeCode,
        Mode: this.cartResult[x].Mode,
        ValidateMargin: 'N',
        BrokerRefNo: '',
        LimitValidation: 'Y',
        CheckHoldings: 'Y',
        MFIMFD: this.cartResult[x].MFIMFDFlag,
        ModelPortFolioName: this.cartResult[x].ModelPortFolioName,
      };

      if(this.deleteFromCart){
         objOrder.OrderType = 'Cancel',
         objOrder.TxnType='cart'    
          }

      this.common.showLoading();
      this.placeorderManager.PlaceOrder(objOrder).then((data) => {
        this.placeMultipleOrder_result = data;
        console.log("PlaceOrder", data);
        this.common.hideLoading();
        this.isPlaceOrderApiCalled = true;

        if(this.placeMultipleOrder_result.ErrorCode == '0'){
          this.successCount = this.successCount + 1;
          if(this.cartResult[x].ShortTxnType == "XSIP" || this.cartResult[x].ShortTxnType == "SIP" || this.cartResult[x].ShortTxnType == "ISIP"){
            this.sipOrderCount = this.sipOrderCount + 1;
          } else{
            this.fpOrderCount = this.fpOrderCount + 1;
          }
          this.showSwal();


        } else{

          swal({
            title: 'OOPS!',
            text: this.placeMultipleOrder_result.ErrorMessage,
            type: "error"
          });
        }

      }, err => {
        this.common.hideLoading();
        console.log("err" + err)
        swal({
          title: 'OOPS!',
          text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
          type: "error"
        });
      });
    }
  }

  if(this.selectedCount == 0){
     if(this.deleteFromCart){
      swal({
          title: 'Notice',
          text: 'Please select a row to remove order',
          type: "error"
        });
    }
     else {
      swal({
          title: 'Notice',
          text: 'Please select a row to place order',
          type: "error"
        });
    }
  }
}

showSwal(){
  this.common.getCartCount();
  if(this.isPlaceOrderApiCalled){
    if(this.selectedCount == this.successCount){
      if(this.deleteFromCart){
     swal({
         title: 'Notice',
         text: 'Selected orders removed successfully',
         type: "success"
       });
      //  this.navCtrl.push('CartPage');
      this.getCartList()

     } else if(this.fpOrderCount == 0){
       swal({
           title: 'Notice',
           text: 'Selected orders placed successfully',
           type: "success"
         })
          // this.navCtrl.push('SipOrderbookPage');
          this.getCartList()
     }

     else{
       swal({
           title: 'Notice',
           text: 'Selected orders placed successfully',
           type: "success"
         })
          // this.navCtrl.push('MfOrderBookPage');
          this.getCartList()
     }
   }

   else if(this.successCount == 0 && this.selectedCount > 0){
       if(this.deleteFromCart){
      swal({
          title: 'Notice',
          text: 'Failed to remove selected orders. Please try again',
          type: "error"
        });
        // this.navCtrl.push('CartPage');

      }else if(this.fpOrderCount == 0 && this.successCount != 0){
        swal({
            title: 'Notice',
            text: 'Selected orders placed successfully',
            type: "success"
          })
          this.getCartList()
          //  this.navCtrl.push('SipOrderbookPage');
      }
       else{
        swal({
            title: 'Notice',
            text: 'Failed to place orders. Please try again',
            type: "success"
          })
          //  this.navCtrl.push('MfOrderBookPage');
      }
    }
   else {
      if(this.deleteFromCart){
     swal({
         title: 'Notice',
         text: this.successCount + ' / ' + this.selectedCount +  ' orders deleted successfully',
         type: "success"
       })
    //  this.navCtrl.push('CartPage');
    this.getCartList()

   } else if(this.fpOrderCount == 0 && this.successCount != 0){
     swal({
         title: 'Notice',
         text: 'Selected orders placed successfully',
         type: "success"
       })
        this.navCtrl.push('SipOrderbookPage');
   }
    else{
     swal({
         title: 'Notice',
         text: this.successCount + ' / ' + this.selectedCount +  ' orders placed successfully',
         type: "success"
       })
        // this.navCtrl.push('MfOrderBookPage');
        this.getCartList()
   }
  }

}
}
  ionViewDidLoad() {
    console.log('ionViewDidLoad CartPage');
  }

}
