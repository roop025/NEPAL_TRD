import { Component ,ViewChild,ElementRef } from '@angular/core';
import { NavController , IonicPage ,NavParams } from 'ionic-angular';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';

@IonicPage()
@Component({
  selector: 'page-generateTradePassword',
  templateUrl: '../../pages/DionWhite/generateTradePassword/generateTradePassword.html'
})

export class GenerateTradePasswordPage {
  @ViewChild("userIdField") public userIdField: ElementRef;
  @ViewChild("userPasswordField") public userPasswordField: ElementRef;
  public forgotFrmData : any;
  public ForgotPasswordOptions : any;
  public user_ip_result : any;
  public user_forgotForm_result : any;
  public ClientName : any;
  public user_generatePassword_result : any;
  public generateTradeData : any;
  public showPassword : any;
  public userLoginFieldData : any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private userManager:UserManagerProvider,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    ) {
      this.userLoginFieldData = this.navParams.get('useLogindata');
      this.ForgotPasswordOptions = [
        {value: "Login",id: 1,TagType: 'L'},
        {value: "Trade",id: 2,TagType: 'T'}
      ];
      this.forgotFrmData = {
        userId: this.userLoginFieldData.userId,
        password: this.userLoginFieldData.password,
        Source: 5,
        Action: 'LOGIN',
        TradePassword: '',
        NewPassword: '',
        ClientIPAddress: '',
        SessionNo: '',
        PAN: '',
        ValidateThrough: 'U',
        DPID: '',
        TagType:'',
        bankaccount:''
      };
      this.ClientName = globalVar.clientName;
      this.showPassword=false;
  }

  ionViewDidLoad(){
    //console.log("test from login")
    // this.common.showLoading();
    // this.userManager.getIPAddress().then((data)=>{
    //   this.user_ip_result = data;
    //   this.common.hideLoading();
    //   //----Successfully fetch the ip address of the user ---
    //   this.forgotFrmData.ClientIPAddress = this.user_ip_result;
    // }, err=> {
    //   this.common.hideLoading();
    // });
  }

  frmForgotPasswordSubmit(){
    // console.log("this.ClientName",this.ClientName)
    // if(this.ClientName === 'Canara'){
    //   this.forgotFrmData.TagType = 'L';
    //   if(this.forgotFrmData.bankaccount == ''){
    //     swal({
    //         title: "OOPS!",
    //         text: "All fields are required fields.",
    //         type: "error"
    //     });
    //     return
    //   }
    // }
    if(this.forgotFrmData.userId==''){
      swal({
          text: "Please Enter User Id",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.userIdField;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.userIdField;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.forgotFrmData.password==''){
      swal({
          text: "Please Enter Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.userPasswordField;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.userPasswordField;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }
    else{
      //--Condition to set the ValidateThrough parameter i.e. client want to reset with email or useId --
      if (this.forgotFrmData.userId.indexOf("@") < 0) {
        this.forgotFrmData.ValidateThrough = 'U';
      } else {
        this.forgotFrmData.ValidateThrough = 'E';
      };
      //--------Calling of generate password API----------------
        this.common.showLoading();
        this.userManager.login(this.forgotFrmData).then((data)=>{
          this.user_forgotForm_result = data;
          this.common.hideLoading();
          //----Successfully Forgot password section ---
          if(this.user_forgotForm_result.ErrorCode == '0'){
            this.generateTradeData={
              userId: this.forgotFrmData.userId,
              password: this.forgotFrmData.password,
              Source: 5,
              Action: 'LOGIN',
              ClientIPAddress: '',
              SessionNo: this.user_forgotForm_result.SessionNo,
            }
            swal({
              title: 'Are you sure ?',
              text: 'Want to process your request..',
              type: 'warning',
              showCancelButton: true,
              cancelButtonText: "No",
              showLoaderOnConfirm: true,
              confirmButtonColor: "rgba(244, 12, 12, 0.97)",
              confirmButtonText: "Yes, Process!"
              }).then((result) => {
              if (result.value) {
                this.common.showLoading();
                this.userManager.generateTradePassword(this.generateTradeData).then((data)=>{
                  this.common.hideLoading();
                  this.user_generatePassword_result = data;
                  //----Successfully login ---
                  if(this.user_generatePassword_result.ErrorCode == '0'){
                    swal({
                      title: "Success",
                      text: this.user_generatePassword_result.Message,
                      type: "success",
                      timer:15000
                    })
                    this.navCtrl.push('LoginPage',{useLogindataFromGenerateTradePassword:this.forgotFrmData});
                  }else{//----User does not able to login --
                    swal({
                        //title: "OOPS!",
                        text: this.user_generatePassword_result.Message,
                        //type: "error"
                    });
                  }
                }, err=> {
                  this.common.hideLoading();
                });
              } else if (result.dismiss === swal.DismissReason.cancel) {
                //---User does not want to logout--
              }
              })
            // this.navCtrl.push('LoginPage');
          }else if(this.user_forgotForm_result.ErrorCode == '-1008015'){ //---Login successfully but password expired--
            swal({
                title: 'Password Expired',
                text: this.user_forgotForm_result.Message,
                type: "warning"
            });
            this.navCtrl.push('ChangePasswordFirstPage',{useLogindata:this.user_forgotForm_result,userPassword:this.forgotFrmData.password});
          }
          else{//----User does not able to login --
            swal({
                //title: "OOPS!",
                text: this.user_forgotForm_result.Message,
                //type: "error"
            });
          }
        }, err=> {
          this.common.hideLoading();
        });
    }
  }

  hideShowPassword(){
    this.showPassword = !this.showPassword;
  }
}
