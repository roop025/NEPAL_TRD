import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GenerateTradePasswordPage } from './generateTradePassword';

@NgModule({
  declarations: [
    GenerateTradePasswordPage,
  ],
  imports: [
    IonicPageModule.forChild(GenerateTradePasswordPage),
  ],
})
export class GenerateTradePasswordPageModule {}
