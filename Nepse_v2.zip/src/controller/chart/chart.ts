import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavParams, Platform, ViewController, NavController, IonicPage } from "ionic-angular";
import { ScreenOrientation } from '@ionic-native/screen-orientation';
import { GlobalConfigService } from '../../providers/common/configService';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';
import '../../util/JXG';
import { StatusBar } from '@ionic-native/status-bar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { AddScripProvider } from '../../providers/add-scrip/add-scrip';
declare var JXG: any;

declare var TradingView: any;

@IonicPage()
@Component({
  selector: 'page-chart',
  templateUrl: '../../pages/DionWhite/chart/chart.html',
})
export class ChartPage implements OnInit, OnDestroy {
    public isPage: boolean = true;
    private _symbol: string = 'ACC';
    // private _symbol: ChartingLibraryWidgetOptions['symbol'] = 'Bitfinex:BTC/USD';
    
    private _interval: any['interval'] = '1';
    // BEWARE: no trailing slash is expected in feed URL
    //   private _datafeedUrl: string = 'https://demo_feed.tradingview.com';
    private _libraryPath: string = '../../assets/lib/charting_library/';
    private _chartsStorageUrl: any = 'https://saveload.tradingview.com';
    private _chartsStorageApiVersion: any = '1.1';
    private _clientId: any = 'tvchart@dionglobal.com';
    private _userId: any = 'public_user_id';
    private _fullscreen: any = true;
    private _autosize: any = true;
    private _containerId: any = 'mini_tv_chart_container';
    private _tvWidget: any | null = null;
    
    private lastBarsCache: any;
    private subscriptionItem: any;
    private scripList:any=[];
    private exchangeList = [
          {
              exchange: "NSE",
              code: "4"
          },
          {
              exchange: "FONSE",
              code: "4"
          },
          {
              exchange: "BSE",
              code: "1"
          },
          {
              exchange: "FOBSE",
              code: "1"
          },
          {
              exchange: "ACE",
              code: "10"
          },
          {
              exchange: "CDNSE",
              code: "13"
          },
          {
              exchange: "MCX",
              code: "7"
          },
          {
              exchange: "COMNSE",
              code: "5"
          },
          {
              exchange: "NCDEX",
              code: "8"
          },
          {
              exchange: "MCXSX",
              code: "14"
          },
          {
              exchange: "NSEL",
              code: "36"
          },
          {
              exchange: "MCXSXEQ",
              code: "64"
          },
          {
              exchange: "MCXSXFO",
              code: "65"
          },
          {
              exchange: "CDBSE",
              code: "17"
          }
    ];
  //   , "120", "180", "D", "W",  "M"
    private configurationData: any = {
      supported_resolutions: [
          "1" , 
          "2" , 
          "3" , 
          "4" , 
          "5" , 
          "10", 
          "15", 
          "30", 
          "60", 
          "120"
      ],
      exchanges: [
          {
              value: 'NSE',
              name: 'NSE',
              desc: 'NSE',
          },
          {
              // `exchange` argument for the `searchSymbols` method, if a user selects this exchange
              value: 'BSE',
  
              // filter name
              name: 'BSE',
  
              // full exchange name displayed in the filter popup
              desc: 'BSE',
          },
          ],
          symbols_types: [{
              name: 'stock',
  
              // `symbolType` argument for the `searchSymbols` method, if a user selects this symbol type
              value: 'stock',
          },
      ],
      currency_codes: ['INR'],
      supports_marks: true,
      supports_time: true,
      supports_timescale_marks: true,
  
    };
  
  
  
  constructor(
      private platform: Platform,
      private ws: WebsocketProvider,
      private wsUtil: WebsocketUtilityService,
      private cb: GlobalConfigService,
      private gv: GlobalVariableService,
      public viewCtrl: ViewController,
      public navParams: NavParams,
      private screenOrientation: ScreenOrientation,
      public statusBar: StatusBar,
      public navCtrl: NavController,
      private addScripManager:AddScripProvider,
  ){
      if(navParams.get('isPage')){
          this.isPage = true;
          this._containerId = 'tv_chart_container';
          this.statusBar.hide();
          console.log("platforms:", platform.platforms());
          if(platform.is('android') || platform.is("ios")){
              this.screenOrientation.unlock();
            //   this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.LANDSCAPE);
          }
      }else{
          this.isPage = false;
          this._containerId = 'mini_tv_chart_container';
      }
  }
  
  
  
      async getAllSymbols() {
          let allSymbols = [];
          let cData = await localStorage.getItem("ChartData");
          let chartData = JSON.parse(cData);
          let s= `STOCK:${chartData.symbol}:${chartData.exchange}`;
          console.log("ChartData getAllSymbols:", chartData, s);
          return [...allSymbols, {
              symbol: chartData.symbol,
              full_name: chartData.symbol,
              description: chartData.symbol,
              exchange: chartData.exchange,
              type: 'stock',
          }];
      }
  
  
      async makeApi(path: any) {
          try {
              let BASE_URL, response, url;
              BASE_URL = this.cb.TradingServiceProtocol + this.cb.TradingServiceIP +':'+ this.cb.TradingServicePort;
              url = `${BASE_URL}/FeedAPI/${path}`;
              response = await fetch(url);
          
              return response.json();	
          } catch (error) {
              console.log(error);
              throw new Error(`Unknown Error: ${error.status}`);
          }
      }
  
    DataFeed: any = (()=>{
      return {
          onReady: (callback) => {
              let cData = localStorage.getItem("ChartData");
              let chartData = JSON.parse(cData);
              console.log('[onReady]: Method call', chartData);
              setTimeout(() => callback(this.configurationData));
          },
      
          searchSymbols: async (
              userInput,
              exchange,
              symbolType,
              onResultReadyCallback,
          ) => {
            this.addScripManager.searchScrip([exchange],userInput,false).then((data)=>{
               
                this.scripList =[];
                let user_search_result:any = data;
                if(user_search_result.data.data == "" || user_search_result.data.data == null){
                  //---do nothing    
              }else{
                let tmpscripList = JSON.parse(user_search_result.data.data);
                tmpscripList.forEach((search_tempObj, index) => {
                  
                  this.scripList.push({
                    symbol: search_tempObj.ID,
                    full_name: search_tempObj.ID,
                    description:search_tempObj.Name,
                      exchange: exchange,
                      type:symbolType
                  });                
                });
              }
              console.log('[searchSymbols]: Method call');
              onResultReadyCallback(this.scripList);
              })             
          },
      
          resolveSymbol: async (
              symbolName,
              onSymbolResolvedCallback,
              onResolveErrorCallback,
          ) => {
              // console.log('[resolveSymbol]: Method call', symbolName);
             let currentSymb = this.scripList.find(x=>x.full_name == symbolName);
             if(currentSymb){
              localStorage.setItem("ChartData",JSON.stringify({"symbol":currentSymb.symbol,"exchange":currentSymb.exchange}))
             }
              const symbols = await this.getAllSymbols();
              // console.log('[resolveSymbol]: Method call', symbols);
              const symbolItem = symbols.find(({
                  full_name,
              }) => full_name === symbolName);
              if (!symbolItem) {
                  // console.log('[resolveSymbol]: Cannot resolve symbol', symbolName);
                  onResolveErrorCallback('cannot resolve symbol');
                  return;
              }
              let cData = await localStorage.getItem("ChartData");
              let chartData = JSON.parse(cData);
              const symbolInfo = {
                  ticker: symbolItem.full_name,
                  name: symbolItem.symbol,
                  description: symbolItem.description,
                  type: symbolItem.type,
                  session: '24x7',
                  timezone: 'Asia/Katmandu',
                  exchange: chartData.exchange,
                  minmov: 1,
                  pricescale: 100,
                  minmove2: 0,
                  has_intraday: true,
                  has_no_volume: true,
                  intraday_multipliers:['1'],
                  has_ticks: false,
                  has_weekly_and_monthly: false,
                  supported_resolutions: this.configurationData.supported_resolutions,
                  volume_precision: 2,
                  data_status: 'streaming',
              };
      
              console.log('[resolveSymbol]: Symbol resolved', symbolInfo);
              onSymbolResolvedCallback(symbolInfo);
          },
          getBars: async (symbolInfo, resolution, periodParams, onHistoryCallback, onErrorCallback) => {
              const { from, to, firstDataRequest, countBack } = periodParams;
              console.log("periodParams", periodParams);
              let recordDate:any = [];
              // console.log('[getBars]: Method call', resolution, new Date(from*1000), new Date(to*1000));
              let cData = await localStorage.getItem("ChartData");
              let chartData = JSON.parse(cData);
              try {
      
                  let compressedData = await this.makeApi(`Services.GetHistoricalChartData?Exchange=${chartData.exchange}&Scrip=${chartData.symbol}&Days=90`);
                  let rows = JSON.parse(compressedData.data);
                  console.log("compressedData", rows);
                  let bars = [];
                  if (!rows || (rows.length == 0)) {
  
                      onHistoryCallback([], {
                          noData: true
                      });
                      return;
                  }
  
                  // if (bars.length == 0) {
  
                  //     onHistoryCallback([], {
                  //         noData: true
                  //     });
                  //     return;
                  // }
  
     
                  if(compressedData){
                      
                      // console.log(rows);
                      rows.map((row)=>{
                          // console.log("Date::::::", row.date, recordDate);
                          if(row && !recordDate.includes(row.date)){
                              recordDate.push(row.date);
                              let rowDate = row.date;
                              let rowUnCompressed = JXG.decompress(row.chartdata);
                              let feeds = rowUnCompressed.split('\n');
                              // console.log("ROW:",rowUnCompressed);
                              feeds.map((feedD, index)=>{
                                //   console.log("Index:", index);
                                  
                                  if(feedD){
                                      let feed = feedD.split(',')
                                      let tickTime = feed[0];
                                      
                                      let barTime = new Date(rowDate.substr(0,4), parseInt(rowDate.substr(4,2))-1, rowDate.substr(6,2));
                                      barTime.setHours(tickTime.substr(0,2), tickTime.substr(2,2));
                                      let time = barTime.getTime();
      
                                      let hBar = {
                                          time: time,
                                          open: feed[1],
                                          high: feed[2],
                                          low: feed[3],
                                          close: feed[4],
                                          volume: feed[5]
                                      };
                                    
                                    //   if(bars.length >= 5)
                                    //   return;

                                      bars.push(hBar);
                                  }
                              });
                          }
                      });
                  }
  
                  
                    this.lastBarsCache = bars[bars.length-1];
                    console.log("this.lastBarsCache", this.lastBarsCache);
                    console.log(`[getBars]: returned ${bars.length}, bars:`,bars);
                    
                    if (firstDataRequest && (bars.length > countBack)) {
                        onHistoryCallback(bars, {
                            noData: false
                        });
                    }else{                       
                        onHistoryCallback([], {
                            noData: true
                        });
                        return;
                    }

                   

                  
                  
              } catch (error) {
                  console.log('[getBars]: Get error', error);
                  onErrorCallback(error);
              }
          },
      
       subscribeBars:async (
              symbolInfo,
              resolution,
              onRealtimeCallback,
              subscribeUID,
              onResetCacheNeededCallback,
          ) => {
              console.log('[subscribeBars]: Method call with subscribeUID:', subscribeUID, symbolInfo, "Resolution:", resolution);
  
              let cData = await localStorage.getItem("ChartData");
              let chartData = JSON.parse(cData);         
  
              let exchange = this.exchangeList.find((e)=> e.exchange == chartData.exchange);
              // let ticker = `${exchange.code}.1!${chartData.symbol}`;
              let socketStr = `ADD^1^${exchange.code}.1!${chartData.symbol}`;
              this.ws.connect();
              this.ws.send(socketStr);
            //   this.ws.send(socketStr, this.gv.WS_FEED_TYPES.DOT_ONE_NOT);
              let handler = {
                  id: subscribeUID,
                  callback: (bar)=>{
                      console.log("PAGE::BAR:::::",bar);
                      onRealtimeCallback(bar);
                  },
              };
  
              if(this.lastBarsCache)
              this.wsUtil.getFeedAfterSubscribeChart(
                  true,
                  chartData.symbol,
                  resolution,
                  handler,
                  this.lastBarsCache
              );
  
          
  
          },
          
          unsubscribeBars: async (subscriberUID) => {
              console.log('[unsubscribeBars]: Method call with subscriberUID:', subscriberUID);
              // unsubscribeFromStream(subscriberUID);
              let cData = await localStorage.getItem("ChartData");
              let chartData = JSON.parse(cData);
            
              let exchange = this.exchangeList.find((e)=> e.exchange == chartData.exchange);
              //let socketDeleteStr = `DELETE^1^${exchange.code}.1!${chartData.symbol}`;
              // let socketDeleteStr = `DELETE^*`;
  
             // this.ws.send(socketDeleteStr);
            //   this.wsUtil.getFeedAfterSubscribeChart(
            //       false
            //   );
              
          },
      }
  })();
  
     ngOnInit() {
        let cData = localStorage.getItem("ChartData");
        let chartData = JSON.parse(cData);
      //   this._symbol= `STOCK:${chartData.symbol}:${chartData.exchange}`;
        this._symbol = chartData.symbol;
        console.log("ChartData", chartData, this._symbol);
        this._libraryPath = (this.platform.is('android') || this.platform.is('ios')) ? 'assets/lib/charting_library/' : '../../assets/lib/charting_library/';
        function getLanguageFromURL() {
            const regex = new RegExp('[\\?&]lang=([^&#]*)');
            const results = regex.exec(location.search);
  
            return results === null ? null : decodeURIComponent(results[1].replace(/\+/g, ' '));
        }
  
        console.log("version", TradingView.version(), this.isPage);
        // this._containerId = this.isPage ? 'tv_chart_container':'mini_tv_chart_container';
     
        const widgetOptions = {
            debug: false,
            symbol: this._symbol,
            datafeed: this.DataFeed,
            interval: this._interval,
            container_id: this._containerId,
            timezone: "Asia/Kolkata",
            container: this._containerId,
            library_path: this._libraryPath,
            timeframe: '1D',
            theme: "light",
            // theme: 'Dark',
            locale: getLanguageFromURL() || 'en',
            time_frames: [
              { text: "1d", resolution: "1", description: "1 Day" },
              { text: "5d", resolution: "5", description: "5 Days" },
              { text: "1m", resolution: "30", description: "1 Month" }
            ],
            disabled_features: this.isPage ? [
                'use_localstorage_for_settings',
                // "header_symbol_search",
                "header_compare",
                "header_undo_redo",
                "header_saveload",
                "go_to_date",
                "edit_buttons_in_legend",
                "object_tree_legend_mode",
                "study_templates",
                // "left_toolbar",
                "drawing_templates",
                "auto_enable_symbol_labels",
                "delete_button_in_legend",    
                "adaptive_logo",
                "header_screenshot",
                "timezone_menu",
                "header_fullscreen_button",
                "border_around_the_chart",
                "header_settings",
                // 'main_series_scale_menu', 
            ] : ['main_series_scale_menu'],
            enabled_features: this.isPage ? [
                "header_widget",
                "header_resolutions",
                "header_indicators",
                "header_chart_type",
                "header_in_fullscreen_mode",
                "timeframes_toolbar",
                "custom_resolutions",
                "left_toolbar",
                "header_symbol_search",
            ] : ['no_min_chart_width'],
            charts_storage_url: this._chartsStorageUrl,
            charts_storage_api_version: this._chartsStorageApiVersion,
            client_id: this._clientId,
            user_id: this._userId,
            fullscreen: this._fullscreen,
            autosize: this._autosize,
            widgetbar:{details: true},
            preset: 'mobile',
            time_scale:{min_bar_spacing:5}
        };
        console.log("version 2", TradingView.version());
        const tvWidget = new TradingView.widget(widgetOptions);
        this._tvWidget = tvWidget;
        console.log("version 3", TradingView.version());
        tvWidget.onChartReady(() => {
            if(!this.isPage){
                tvWidget.applyOverrides({
                    "paneProperties.vertGridProperties.color": "rgba(42, 46, 57, 0.6)",
                    "paneProperties.horzGridProperties.color": "rgba(42, 46, 57, 0.6)",
                    "scalesProperties.lineColor": "rgba(42, 46, 57, 0.2)"
                }); 
            }
        });
  
    }
  
    async ngOnDestroy() {
        if (this._tvWidget !== null) {
            this._tvWidget.remove();
            this._tvWidget = null;
        }
        if(this.isPage){
          this.statusBar.show();
          if(this.platform.is('android') || this.platform.is("ios")){
            //   this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);
            this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT)
          }
          
        }
    }
    
    back() {
        this.navCtrl.pop();
    }

}



