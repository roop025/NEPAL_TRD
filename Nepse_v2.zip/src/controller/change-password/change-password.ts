import { Component,ViewChild,ElementRef } from '@angular/core';
import { NavController , IonicPage ,NavParams } from 'ionic-angular';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
// import  data  from  '../../assets/DionBlack/contactInfo.json';
declare var require:any

@IonicPage()
@Component({
  selector: 'page-changePassword',
  templateUrl: '../../pages/DionWhite/change-password/change-password.html'
})

export class ChangePasswordPage {
  @ViewChild("oldPassword") public oldPassword: ElementRef;
  @ViewChild("newPassword") public newPassword: ElementRef;
  @ViewChild("confirmNewPassword") public confirmNewPassword: ElementRef;
  public changePasswordFrmData : any;
  public password : any;
  private userLoginData : any;
  private user_change_password_result : any;
  public ForgotPasswordOptions : any;
  public ClientName : any;
  public showPassword : any;
  public showTradePassword : any;
  public showConfirmPassword : any;
  public oldPass:any = 'Old Login Password';
  public newPass:any;
  public confirmNewPass:any;
  public activeClientData:any


  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private userManager:UserManagerProvider,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    ) {
    this.userLoginData = this.navParams.get('useLogindata');
    this.oldPass = 'Old Login Password';
    this.newPass = 'New Login Password';
    this.confirmNewPass = 'New Confirm Password';
    // this.activeClient = globalVar.getActiveClientData(globalVar.activeClient);


    this.ForgotPasswordOptions = [
      {value: "Login",id: 1,TagType: 'L'},
      {value: "Trade",id: 2,TagType: 'T'}
    ];
    this.password = {
      newPassword1: '',
      newPassword2: ''
    }
    this.changePasswordFrmData = {
      userId:this.userLoginData.ClientCode,
      password:'',
      Source:5,
      Action:'CHANGEPASSWORD',
      TradePassword:'',
      NewPassword:this.password.newPassword1,
      ClientIPAddress:'',
      TagType:'',
      SessionNo:this.userLoginData.SessionNo
    };

    this.ClientName = globalVar.clientName;

    this.showPassword=false
    this.showTradePassword=false
    this.showConfirmPassword=false
  }

  
  ngOnInit(){
    this.activeClientData = require("../../assets/DionBlack/contactInfo.json");
    // this.activeClientData = data
  }

  ionViewDidLoad(){
    this.changePasswordFrmData.TagType = 'L'
    //console.log("test from login")
  }
  changeType(ev){
    if(ev == 'T'){
      this.oldPass = 'Login Password';
      this.newPass = 'New Trade Password';
      this.confirmNewPass = 'New Confirm Trade Password';
     // console.log(ev);
      }else{
        this.oldPass = 'Old Login Password';
        this.newPass = 'New Login Password';
        this.confirmNewPass = 'New Confirm Password';
        //console.log(ev);
    }

  }

  changePasswordSubmit(){
    // if(this.changePasswordFrmData.TagType==''){
    //   swal({
    //       //title: "OOPS!",
    //       text: "Please select reset password for option !",
    //       //type: "error"
    //   });
    // }
    if(this.changePasswordFrmData.password==''){
      swal({
          text: "Please Enter Old Login Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.oldPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.oldPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }
    else if(this.password.newPassword1==''){
      swal({
          text: "Please Enter New Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.newPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.newPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.password.newPassword2 == ''){
      swal({
          text: "Please Enter Confirm New Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.confirmNewPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.confirmNewPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }
    else if(this.password.newPassword1!=this.password.newPassword2){
      swal({
          //title: "OOPS!",
          text: "Password and Confirm Password mismatch !",
          //type: "error"
      });
      // this.password.newPassword1 ='';
      // this.password.newPassword2 ='';
    }else{
      this.changePasswordFrmData.NewPassword = this.password.newPassword1;
      this.common.showLoading();
      this.userManager.changeUserPassword(this.changePasswordFrmData).then((data)=>{
        this.user_change_password_result = data;
        this.common.hideLoading();
        //----Successfully login ---
        if(this.user_change_password_result.ErrorCode == '0'){
          //console.log("this.user_change_password_result",this.user_change_password_result);
          swal({
              title: "Password Changed",
              type: "success"
          });
          this.navCtrl.push('SettingPage');
        }else if(this.user_change_password_result.ErrorCode == '-1011005'){
          swal({
              //title: 'OOPS!',
              text: "Invalid password length. Password length allowed minimum 6 & maximum 12 characters.",
              //type: "error"
          });
          this.password.newPassword1 ='';
          this.password.newPassword2 ='';
        }else{//----User does not able to login --
          swal({
              //title: "OOPS!",
              text: "Could not change password." + this.user_change_password_result.Message,
              //type: "error"
          });
        }
      }, err=> {
        this.common.hideLoading();
      });
    }
  }

  //----Hide show password function --\
  hideShowPassword(){
    this.showPassword = !this.showPassword;
  }
  hideShowTradePassword(){
    this.showTradePassword = !this.showTradePassword;
  }
  hideShowConfirmPassword(){
    this.showConfirmPassword = !this.showConfirmPassword;
  }
}
