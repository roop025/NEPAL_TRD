import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConvertPage } from './convert';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    ConvertPage,
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(ConvertPage),
  ],
})
export class ConvertPageModule {}
