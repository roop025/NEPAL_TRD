import { Component,ViewChild,ElementRef } from '@angular/core';
import { NavController , IonicPage,NavParams } from 'ionic-angular';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { ConvertProvider } from '../../providers/convert/convert';
import {BuySellProvider} from "../../providers/buy-sell/buy-sell";

@IonicPage()
@Component({
  selector: 'page-convert',
  templateUrl: '../../pages/DionWhite/convert/convert.html'
})

export class ConvertPage {

  @ViewChild("quantityField") public quantityField: ElementRef;
  public userData : any;
  public convertData : any;
  public specifiedQuote_result : any;
  public item : any;
  public Price : any;
  public Quantity : any;
  public orderObject : any;
  public originalQuantity : any;
  public BuySellIndicator : any;
  public BuySellType : any;
  public products : any;
  public defaultTradingAccount : any;
  public productTypeSelected : any;
  public AUTOAMS : any;
  public lotSize : any;
  public disablePlusButton : any;
  public tradeType : any;
  public alerttext : any;
  public convert_order_result : any;
  public companyInfo_result : any;
  public showDisclosedQty : any;
  public tickertype : any;
  public isIndex : any;
  public ViewlotSize : any;
  public lotSize_result: any;

  constructor(public navCtrl: NavController,
    public ngProgress: NgProgress,
    public buySellManager : BuySellProvider,
    private globalVariableService : GlobalVariableService,
    public convertManager : ConvertProvider,
    public navParams: NavParams,
  ) {
    this.products={
        availableOptions:[]
    }
    this.defaultTradingAccount = {
      TradingAccount: ''
    }
    this.orderObject={
      Quantity:0
    }
    this.lotSize=1;
    this.disablePlusButton=false;
  }

  ionViewDidLoad(){
    this.userData = this.navParams.get('clientUserData');
    this.convertData = this.navParams.get('userConvertData');
    //console.log("this.convertData",this.convertData)
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"ConvertPage"});
    //console.log("from convert", this.convertData)
    this.originalQuantity = Number(this.convertData.OpenQuantity);
    this.BuySellIndicator = 'B';
    this.BuySellType = 'Buy';
    if (this.convertData.OpenPosition == 'S') {
        this.BuySellIndicator = 'S';
        this.BuySellType = 'Sell';
    }
    this.Quantity = this.originalQuantity;
    this.getSpecifiedQuoteData();
    this.AUTOAMS = this.userData.CustomerName.split("-")[1];
  }

  //---Cnahge Product type --
  changeProductType(proObj){
    this.products.availableOptions.forEach((value, index) => {
      if(value.TradingAccount==proObj.TradingAccount){
        this.orderObject.TradingAccount = value.TradingAccount
        this.orderObject.DeliveryFlag = value.DeliveryFlag
      }
    });
  }
  //---Inc quantity function --
  qtyPlus(){
    // if (this.orderObject.Quantity === '') {
    //     this.orderObject.Quantity = 0;
    // }
    // // if (this.orderObject.Quantity != NaN) {
    // //   this.orderObject.Quantity = 0;
    // // }
    // if(this.orderObject.Quantity>=this.originalQuantity){
    //   this.disablePlusButton=true;
    // }else{
    //   //this.orderObject.Quantity = Number(this.orderObject.Quantity) + Number(this.lotSize);
    //   this.ViewlotSize = parseInt(this.ViewlotSize)
    //   var ViewlotSize = parseInt(this.ViewlotSize);

    //   var wholeLot = Number(this.orderObject.Quantity) % Number(ViewlotSize);
    //   this.orderObject.Quantity =( Number(this.orderObject.Quantity) + Number(ViewlotSize)) - wholeLot;
    // }

    if (this.orderObject.Quantity === '') {
      this.orderObject.Quantity = 0;
  }

  if (parseInt(this.orderObject.Quantity) >= parseInt(this.originalQuantity)) {
      this.disablePlusButton = true;
  } else {
      var wholeLot = Number(this.orderObject.Quantity) % Number(this.lotSize);
      this.orderObject.Quantity = (Number(this.orderObject.Quantity) + Number(this.lotSize)) - wholeLot;
  }

  }
  //---Dec quantity --
  qtyMinus(){
    // if (this.orderObject.Quantity === '') {
    //     this.orderObject.Quantity = 0;
    // }
    // // if (this.orderObject.Quantity != NaN) {
    // //   this.orderObject.Quantity = 0;
    // // }
    // if(this.orderObject.Quantity<=this.originalQuantity){
    //   this.disablePlusButton=false;
    // }
    // //console.log("Number(this.ViewlotSize)",Number(this.ViewlotSize))
    // if (Number(this.orderObject.Quantity) - Number(this.lotSize) > 0) {
    //   this.ViewlotSize = parseInt(this.ViewlotSize)
    //   var ViewlotSize = parseInt(this.ViewlotSize);
    //     var wholeLot = Number(this.orderObject.Quantity) % Number(ViewlotSize);
    //     //console.log("wholeLot",wholeLot)
    //     // if(wholeLot === undefined){
    //     //   this.orderObject.Quantity =0;
    //     // }
    //     if(wholeLot != 0){
    //       this.orderObject.Quantity = Number(this.orderObject.Quantity) - wholeLot;
    //     }else{
    //       this.orderObject.Quantity = Number(this.orderObject.Quantity) - Number(ViewlotSize);
    //     }
    // }else{
    //   this.orderObject.Quantity =0;
    // }

    if (this.orderObject.Quantity === '') {
      this.orderObject.Quantity = 0;
  }
  if (parseInt(this.orderObject.Quantity) <= parseInt(this.originalQuantity)) {
      this.disablePlusButton = false;
  }
  if (Number(this.orderObject.Quantity) - Number(this.lotSize) >= 0) {
      var wholeLotMinus = Number(this.orderObject.Quantity) % Number(this.lotSize);
      //console.log("wholeLotMinus",wholeLotMinus)
      this.orderObject.Quantity = (Number(this.orderObject.Quantity) - Number(this.lotSize)) - wholeLotMinus;
  }

  }

  getSpecifiedQuoteData(){
    this.convertManager.getSpecifiedQuote(this.convertData.Scrip,this.convertData.exchange).then((data)=>{
      this.specifiedQuote_result = data;
      if(this.specifiedQuote_result.ErrorCode==0){
        var scripSet = JSON.parse(this.specifiedQuote_result.data);
        this.item = scripSet[0];
        this.tickertype = 'EQT';
        this.isIndex = false;
        this.item.DateTime = this.item.LastTradeTime;
        this.Price = Number(this.item.OfferPrice);
        this.orderObject = {
            SessionNo: this.userData.SessionNo
            , ClientCode: this.userData.ClientCode
            , OrderPlacedBy: this.userData.ClientCode
            , Source: 5
            , TradingAccount: ''
            , Exchange: this.item.exchange
            , Scrip: this.item.ticker
            , Quantity: Number(this.originalQuantity)
            , Price: Number(this.item.OfferPrice)
            , Market: 0
            , OrderTerms: 'DAY'
            , BuySellIndicator: this.BuySellIndicator
            , BuySellType: this.BuySellType
            , TriggerPrice: ''
            , DeliveryTerms: 'D'
            , MarketSegment: 'RL'
            , DeliveryFlag: ''
            , OrderCategory: 'NORMAL'
            , OrderType: 'DELIVERY'
            , AccRefCode: 'SELF'
            , TermValidity: ''
            , DisclosedQuantity: ''
            , SettlementKey: ''
            , OldModifiedProduct: this.convertData.TradingAccount
        };
        //console.log(" this.orderObject" + JSON.stringify( this.orderObject))
        this.BindProductType();
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
    });
  }

  //---Bind product type --
  BindProductType(){
    //this.loginServiceData = LoginService.LoginDetails;
    // this.products = {
    //     availableOptions: []
    // };
    var VTD;
    var ExchangePermit = 0;
    var ProductTypeList = '';
    var ProductType = this.userData.TradingAccountExchangeList.split('^');

    for (var i = 0; i < ProductType.length; i++) {
        if (ProductType[i].split('$')[0] == this.item.exchange) {
            ProductTypeList = ProductType[i].split('$')[1];
            ExchangePermit = 1;
            break;
        }
    }

    if (ExchangePermit == 1) {
        //console.log("this.orderObject.OldModifiedProduct",this.orderObject.OldModifiedProduct)
        var ProductTerms = ProductTypeList.split('|')[1].split('~');
        if (VTD == 1) {
            var VTDAllowd = this.userData.VTDAllowedToProducts;
            for (var tempi = 0; tempi < ProductTerms.length; tempi++) {
                if (VTDAllowd.indexOf(ProductTerms[tempi].split(',')[0]) > -1) {

                    //check for current item.TradingAccount and ignore that but bind the others
                    if (ProductTerms[tempi].split(',')[0].toUpperCase() != this.orderObject.OldModifiedProduct.toUpperCase()) {
                        this.products.availableOptions.push({
                            TradingAccount: ProductTerms[tempi].split(',')[0]
                            , DeliveryFlag: ProductTerms[tempi].split(',')[1]
                        });
                    }
                }
            }
        } else {
            for (var tempi1 = 0; tempi1 < ProductTerms.length; tempi1++) {
                //check for current item.TradingAccount and ignore that but bind the others
                if (ProductTerms[tempi1].split(',')[0].toUpperCase() != this.orderObject.OldModifiedProduct.toUpperCase()) {
                    this.products.availableOptions.push({
                        TradingAccount: ProductTerms[tempi1].split(',')[0]
                        , DeliveryFlag: ProductTerms[tempi1].split(',')[1]
                    });
                }
            }
        }
    } else {
        swal({
            title: "Error!"
            , text: "Exchange " + this.item.exchange + " is not mapped to the user."
            , type: "error"
            , //timer: 1500,
            allowOutsideClick: true
            , showConfirmButton: true
        });
    }
    console.log("this.products.availableOptions",this.products.availableOptions)
    if (this.productTypeSelected==undefined) {
      this.productTypeSelected = this.products.availableOptions[0];
      this.defaultTradingAccount = {TradingAccount:this.products.availableOptions[0].TradingAccount}
      this.orderObject.TradingAccount = this.products.availableOptions[0].TradingAccount
      this.orderObject.DeliveryFlag = this.products.availableOptions[0].DeliveryFlag

    };

    //if no other product types are available for product conversion, then give an error and return user to netposition window
    if (this.products.availableOptions.length === 0) {
        swal({
            title: "Error!"
            , text: "Cannot convert product as no other options are available for this exchange"
            , type: "error"
            , //timer: 1500,
            allowOutsideClick: true
            , showConfirmButton: true
        });
        //--Redirect to net position page--
        //$state.go("app.netposition");
    }

    //----lot size management --
    if (this.item.Scrip != undefined) {
        this.getLotSize(this.item.Scrip, this.item.exchange);
        this.getCompanyInformation(this.convertData.ticker, this.convertData.exchange);
    } else {
        this.getLotSize(this.item.ticker, this.item.exchange);
        this.getCompanyInformation(this.convertData.ticker, this.convertData.exchange);
    }
  }

  //---Convert Order ---
  convertOrder(){
    //console.log("this.orderObject",this.orderObject)
    if (this.orderObject.Quantity < 1) {
        swal({
            title: "Error!"
            , text: "Invalid Quantity entered, Open Quantity is " + this.originalQuantity
            , timer: 1500
            , allowOutsideClick: true
            , showConfirmButton: true
        });
        return;
    }
    if (this.orderObject.Quantity % 1 != 0) {
        swal({
            title: "Error!"
            , text: "Invalid Quantity entered, decimals not allowed"
            , timer: 1500
            , showConfirmButton: true
        });
        return;
    }
    if (this.orderObject.Quantity > this.originalQuantity) {
        swal({
            title: "Error!"
            , text: "Invalid Quantity entered, cannot convert more than" + this.originalQuantity
            , timer: 1500
            , allowOutsideClick: true
            , showConfirmButton: true
        });
        return;
    }
    if(this.orderObject.Exchange=="BSE" || this.orderObject.Exchange=="NSE"){
      if(this.orderObject.BuySellIndicator == 'S') //& OrderService.DeliveryFlag == 'DEL')
        {
          if(this.AUTOAMS == "1")
            {
              this.tradeType =  'Auto';
            }
          else
            {
              this.tradeType = "DPF";
            }
        }
      else{
        this.tradeType = this.orderObject.DeliveryFlag
        }
      }else{
        this.tradeType = this.orderObject.DeliveryFlag;
    }

    var convertOrderqString = '{';
    convertOrderqString += '"SessionNo":"' + this.orderObject.SessionNo + '",';
    convertOrderqString += '"ClientCode":"' + this.orderObject.ClientCode + '",';
    convertOrderqString += '"OrderPlacedBy":"' + this.orderObject.OrderPlacedBy + '",';
    convertOrderqString += '"Source":"' + this.orderObject.Source + '",';
    convertOrderqString += '"TradingAccount":"' + this.orderObject.TradingAccount + '",';
    convertOrderqString += '"Exchange":"' + this.orderObject.Exchange + '",';
    convertOrderqString += '"Scrip":"' + encodeURIComponent(this.orderObject.Scrip) + '",';
    convertOrderqString += '"Quantity":"' + this.orderObject.Quantity + '",';
    convertOrderqString += '"Price":"' + this.orderObject.Price + '",';
    convertOrderqString += '"Market":"' + this.orderObject.Market + '",';
    convertOrderqString += '"OrderTerms":"' + this.orderObject.OrderTerms + '",';
    convertOrderqString += '"BuySellIndicator":"' + this.orderObject.BuySellIndicator + '",';
    convertOrderqString += '"BuySellType":"' + this.orderObject.BuySellType + '",';
    convertOrderqString += '"TriggerPrice":"' + this.orderObject.TriggerPrice + '",';
    convertOrderqString += '"DeliveryTerms":"' + this.orderObject.DeliveryTerms + '",';
    convertOrderqString += '"MarketSegment":"' + this.orderObject.MarketSegment + '",';
    convertOrderqString += '"DeliveryFlag":"' + this.tradeType + '",';
    convertOrderqString += '"OrderCategory":"' + this.orderObject.OrderCategory + '",';
    convertOrderqString += '"OrderType":"' + this.orderObject.OrderType + '",';
    convertOrderqString += '"AccRefCode":"' + this.orderObject.AccRefCode + '",';
    convertOrderqString += '"TermValidity":"' + this.orderObject.TermValidity + '",';
    convertOrderqString += '"DisclosedQuantity":"' + this.orderObject.DisclosedQuantity + '",';
    convertOrderqString += '"SettlementKey":"' + this.orderObject.SettlementKey + '",';
    convertOrderqString += '"OldModifiedProduct":"' + this.orderObject.OldModifiedProduct + '"}';

    //---Swal alert text section --
    this.alerttext = "You are placing an order to convert" + "<br>";
    this.alerttext += this.orderObject.Quantity + " shares from " + this.orderObject.OldModifiedProduct + " to " + this.orderObject.TradingAccount + "<br>" +
    "for Scrip :" + this.orderObject.Scrip;

    swal({
      title: 'Convert Order?',
      html: this.alerttext,
      type: 'info',
      showCancelButton: true,
      cancelButtonText: "No, let it be!",
      confirmButtonColor: "#387ef5",
      confirmButtonText: "Yes, Convert order!"
      }).then((result) => {
      if (result.value) {
          //---User want to Place order--
          this.convertManager.convertOrder(convertOrderqString).then((data)=>{
            this.convert_order_result = data;
            if(this.convert_order_result.ErrorCode == '0'){
              swal({
                  title: "Order Status",
                  text: JSON.stringify(this.convert_order_result.Message),
                  type: "info",
                  showCancelButton: true,
                  cancelButtonText: "Close",
                  confirmButtonColor: "#387ef5",
                  confirmButtonText: "Net Position"
              }).then((result) => {
                  if (result.value) {
                    swal({
                        title: "Redirecting",
                        text: "Loading Net Position Page",
                        type: "success",
                        showConfirmButton: false,
                        timer: 350
                    });
                    //---Code to redirect to order Detail page goes here --
                    // this.navCtrl.push('NetPositionPage');
                    this.navCtrl.pop()
                  }
              })
            }else{
              swal({
                  title: "Error!"
                  , text: JSON.stringify(this.convert_order_result.Message)
                  , showConfirmButton: true
                  , allowOutsideClick: true
              });
            }
          }, err=> {});
        }
      })

  }


    buyItem(){
      //--Apply the logic of valid trade password for login --
      this.globalVariableService.setQuoteHeaderData({ quoteItem: this.convertData });
      this.navCtrl.push('BuyPage',{userbuyData:this.convertData,clientUserData:this.userData});
    }
    sellItem(){
      //--Apply the logic of valid trade password for login --
      this.globalVariableService.setQuoteHeaderData({ quoteItem: this.convertData });
      this.navCtrl.push('SellPage',{usersellData:this.convertData,clientUserData:this.userData});
    }
    marketDepth(){
      this.globalVariableService.setQuoteHeaderData({ quoteItem: this.convertData });
      this.navCtrl.push('MarketDepthPage',{userMWDepthData:this.convertData,clientUserData:this.userData});
    }

    //---get lot size and company information --
    getCompanyInformation(security, exchange){
      this.buySellManager.getCompanyInfo(security,exchange).then((data)=>{
        this.companyInfo_result = data
        if(this.companyInfo_result.ErrorCode==0){
          if (JSON.parse(this.companyInfo_result.data)[0]['Market Lot'] != undefined) {
              this.ViewlotSize = JSON.parse(this.companyInfo_result.data)[0]['Market Lot'];
          } else if (JSON.parse(this.companyInfo_result.data)[0].MarketLot != undefined) {
              this.ViewlotSize = JSON.parse(this.companyInfo_result.data)[0].MarketLot;
          } else if (JSON.parse(this.companyInfo_result.data)[0].MinimumLotQty != undefined) {
              this.ViewlotSize = JSON.parse(this.companyInfo_result.data)[0].MinimumLotQty
          } else {
              this.ViewlotSize = this.lotSize;
          }
        }else{
          this.ViewlotSize = 1;
          this.lotSize = 1;
        }
        //console.log("this.ViewlotSize ",this.ViewlotSize )
      },err=>{});
    }

    qtyBoxClick(){
      var elem:any = this.quantityField;
      elem._native.nativeElement.focus();
      // input.focus(); //sets focus to element
      var val = this.orderObject.Quantity; //store the value of the element
      this.orderObject.Quantity = ''; //clear the value of the element
      setTimeout(() => {
        this.orderObject.Quantity = val; //set that value back.
        this.disablePlusButton=false;
      }, 10);
    }

     //---get lot size and company information --
     getLotSize(security, exchange) {
      security = security.replace('NIFTY 50', 'Nifty');
      security = security.replace('NIFTY BANK', 'BANKNIFTY');
      security = security.replace('BANK NIFTY', 'BANKNIFTY');
      security = security.replace('NIFTY IT', 'NiftyIT');
      security = security.replace('NIFTY MIDCAP 50', 'NIFTYMID50');
      security = security.replace('NIFTY PSE', 'NIFTYPSE');
      security = security.replace('NIFTY INFRA', 'NIFTYINFRA');
      //---get lot size from service
      this.buySellManager.getLotSize(security, exchange).then((data) => {
          this.lotSize_result = data;
          if (this.lotSize_result.ErrorCode == 0) {
              this.lotSize = Number(this.lotSize_result.data);
              if (this.lotSize == 0)
                  this.lotSize = 1;
              if (this.lotSize > 1) {
                  this.showDisclosedQty = false;
              }
          }
      }, err => {
          console.log("error in retrieving lot size data");
      });
  }

}
