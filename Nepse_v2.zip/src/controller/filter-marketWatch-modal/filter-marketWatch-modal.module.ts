import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FilterMarketWatchModal } from './filter-marketWatch-modal';


@NgModule({
  declarations: [
    FilterMarketWatchModal,
  ],
  imports: [
    IonicPageModule.forChild(FilterMarketWatchModal),
  ],
})
export class FilterMarketWatchModalModule {}
