import { Component, ɵConsole } from '@angular/core';
import { NavController , IonicPage ,ViewController,Events } from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import { json } from 'd3';



@IonicPage()
@Component({
  selector: 'modal-FilterMarketWatchModal',
  templateUrl: '../../pages/DionWhite/filter-marketWatch-modal/filter-marketWatch-modal.html'
})

export class FilterMarketWatchModal {
  exchange: string;
  underlying: string;
  TradingAccount: string;
  OrderStatus: string;
  BuySellType: string;
  SegmentAccount: string;

  public tickerList : any;
  public ticker_result : any;
  private showPercentageRupees : any;
  private filterTickerData : any;
  private selectedIndex1 : any;
  private ContainsAllValues : any;
  private selectedIndex : any;
  private AllItems : any;
  // private TickerItem : any;
  // private ExchangeItems : any;
  private CorrespondingItemsOfSelect : any;
  private filterHeader : any;
  private ClientName : any;

  constructor(public navCtrl: NavController,public viewCtrl: ViewController, private globalVariableService : GlobalVariableService,private marketWatchManager:MarketWatchProvider,private ev:Events) {
    this.showPercentageRupees = globalVariableService.currentFilterValue;
    //---get the list of market watch item --
    this.AllItems = this.globalVariableService.getData().watchlistItems;
    console.log("this.allItems",this.AllItems)
    // this.TickerItem = [];
    // this.ExchangeItems = [];
    this.filterHeader=''
    this.ClientName = globalVariableService.clientName;
    //this.selectedIndex1=[]
  }

  ionViewDidLoad(){
    //console.log("test from modal")
    //---service to load the BSE and NSE scrip ---
      this.tickerList = "NSE.NIFTY 50^BSE.SENSEX";
      // var indexData;
      this.marketWatchManager.listTicker(this.tickerList).then((data)=>{
        this.ticker_result = data;
        //----Successfully loaded market watch list ---
        if(this.ticker_result.ErrorCode == '0'){
          this.filterTickerData = JSON.parse(this.ticker_result.data);
        }
        //console.log("this.filterTickerData ",this.filterTickerData )
      }, err=> {
        // this.common.hideLoading();
      });
      // this.CorrespondingItemsOfSelect = this.ContainsAllValues;
      //---Get page name--
      if(this.globalVariableService.getPageName().currentPageName=="MarketWatchPage"){
        //---set of selectedIndex first parameter --
        this.filterHeader="FILTER MARKET WATCH REPORT"
        this.selectedIndex1 = ['All','Scrip','Exchange'];
      }
      if(this.globalVariableService.getPageName().currentPageName=="OrderBookPage"){
        //---set of selectedIndex first parameter --
        this.filterHeader="FILTER ORDER BOOK REPORT"
        this.selectedIndex1 = ['All','Scrip', 'Exchange', 'TradingAccount', 'Status', 'BuySellType']
      }
      if(this.globalVariableService.getPageName().currentPageName=="TradeBookPage"){
        //---set of selectedIndex first parameter --
        this.filterHeader="FILTER TRADE BOOK REPORT"
        this.selectedIndex1 = ['All','Scrip', 'Exchange', 'TradingAccount', 'SegmentAccount']
      }
      if(this.globalVariableService.getPageName().currentPageName=="NetPositionPage"){
        //---set of selectedIndex first parameter --
        this.filterHeader="FILTER NETPOSITION REPORT"
        this.selectedIndex1 = ['All','Scrip', 'Exchange', 'TradingAccount', 'SegmentAccount']
      }
      //console.log("this.selectedIndex1",this.selectedIndex1)
      if(typeof(this.selectedIndex1) == "undefined"){
        this.selectedIndex1 = ['All','Scrip', 'Exchange', 'TradingAccount', 'SegmentAccount']
        this.selectedIndex = this.selectedIndex1[0];
      }else{
          this.selectedIndex = this.selectedIndex1[0];
      }

  }
  //--close trading message modal and pass the data --
  closeTradingMessageModal(){
    this.viewCtrl.dismiss();
  }

  updateFilter(){
    this.showPercentageRupees = !this.showPercentageRupees;
    this.globalVariableService.toogleFilterData();
  }

  //---Change filter value --
  changeFilter(filterObj){
    //console.log("test",this.selectedIndex)
    //---If scrip is selected ---uniqueMWRecords
    if (this.selectedIndex == "Scrip") {
        this.ContainsAllValues = [];
        this.AllItems.forEach((value, index) => {
          if (this.ContainsAllValues.indexOf(this.AllItems[index].underlying) == -1) {
              //this.TickerItem.push(this.AllItems[index].underlying);
              this.ContainsAllValues.push(this.AllItems[index].underlying);
              this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
          };
        });
    };
    //---If Exchange is selected ---
    if (this.selectedIndex == "Exchange") {
        this.ContainsAllValues = [];
        //---Condition for checking of case sensetive in case of Exchange--
        if(this.globalVariableService.getPageName().currentPageName=="MarketWatchPage"){
          this.AllItems.forEach((value, index) => {
            if (this.ContainsAllValues.indexOf(this.AllItems[index].exchange) == -1) {
                //this.TickerItem.push(this.AllItems[index].underlying);
                this.ContainsAllValues.push(this.AllItems[index].exchange);
                this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
            };
          });
        }else{
          this.AllItems.forEach((value, index) => {
            if (this.ContainsAllValues.indexOf(this.AllItems[index].Exchange) == -1) {
                //this.TickerItem.push(this.AllItems[index].underlying);
                this.ContainsAllValues.push(this.AllItems[index].Exchange);
                this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
            };
          });
        }
    };
    //---If TradingAccount is selected ---
    if (this.selectedIndex == "TradingAccount") {
        this.ContainsAllValues = [];
        this.AllItems.forEach((value, index) => {
          if (this.ContainsAllValues.indexOf(this.AllItems[index].TradingAccount) == -1) {
              //this.TickerItem.push(this.AllItems[index].underlying);
              this.ContainsAllValues.push(this.AllItems[index].TradingAccount);
              this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
          };
        });
    };
    //---If Status is selected ---
    if (this.selectedIndex == "Status") {
        this.ContainsAllValues = [];
        this.AllItems.forEach((value, index) => {
          if (this.ContainsAllValues.indexOf(this.AllItems[index].OrderStatus) == -1) {
              //this.TickerItem.push(this.AllItems[index].underlying);
              this.ContainsAllValues.push(this.AllItems[index].OrderStatus);
              this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
          };
        });
    };
    //---If Status is selected ---
    if (this.selectedIndex == "BuySellType") {
        this.ContainsAllValues = [];
        this.AllItems.forEach((value, index) => {
          if (this.ContainsAllValues.indexOf(this.AllItems[index].BuySellType) == -1) {
              //this.TickerItem.push(this.AllItems[index].underlying);
              this.ContainsAllValues.push(this.AllItems[index].BuySellType);
              this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
          };
        });
    };
    //---If Status is selected ---
    if (this.selectedIndex == "SegmentAccount") {
        this.ContainsAllValues = [];
        this.AllItems.forEach((value, index) => {
          if (this.ContainsAllValues.indexOf(this.AllItems[index].SegmentAccount) == -1) {
              //this.TickerItem.push(this.AllItems[index].underlying);
              this.ContainsAllValues.push(this.AllItems[index].SegmentAccount);
              this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
          };
        });
    };
    //---If %Change is selected--
    if(this.selectedIndex == "%Change") {
        this.ContainsAllValues = [];
        this.ContainsAllValues = ['Gainers', 'Losers'];
        this.CorrespondingItemsOfSelect = this.ContainsAllValues[0];
    };
    //---If selected all --
    if(this.selectedIndex == "All") {
        this.ContainsAllValues = [];
    };
  }

  //---Apply filter button click --
  applyFilter(){
    //console.log("Filter Parameter:",this.selectedIndex,this.CorrespondingItemsOfSelect)
    this.ev.publish('checkFilterArgument',{indexSel:this.selectedIndex,valueSel:this.CorrespondingItemsOfSelect});
    this.viewCtrl.dismiss();
  }
}
