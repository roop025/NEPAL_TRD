import { Component,ViewChild,ElementRef } from '@angular/core';
import { NavController, IonicPage, NavParams, Events, Navbar, MenuController, FabButton, Slides, ViewController } from 'ionic-angular';
// import { NavController , IonicPage ,MenuController} from 'ionic-angular';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';

import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { Chart } from 'chart.js';


declare var google:any;

@IonicPage()
@Component({
  selector: 'page-dashboard',
  templateUrl: '../../pages/DionWhite/dashboard/dashboard.html'
})

export class DashboardPage {
  public setName : any;
  public isMenuEnabled : any;
  public ClientName : any;
  public userData : any;
  public progressBarColor : any;
  public marginReport_result : any;
  public items : any;
  public itemsNetPos : any;
  public message : any;
  public defaultSegmentAccount : any;
  public defaultExchangeAccount : any;
  public defaultIndicesAccount : any;
  public percentageValue: any;
  public holdingsItems: any;
  public holdings_result: any;
  public ordersItems: any;
  public orderReport_result: any;
  public tradeReport_result: any;
  public spreadType: any;
  public tradeItems: any;
  public allExchange: any;
  public availableExchangearray: any;
  public userAllowedExchange: any;
  public indicesDetail_result: any;
  public indicesDetailData: any;
  public indisesVal: any;
  public indices_result: any;
  public listTickerData: any;
  public userIndisesArray: any;
  public indicesLocalData: any;
  public keylist: any;
  public indices_webSocket_Data: any;
  public showAddSection: any;
  public tickerList: any;
  public ticker_result: any;
  public footerTickerData: any;
  public netPosition_result: any;
  public m2m: any;
  public bpl: any;
  public negativeVal: any;
  public summationCollateral: any;
  public summationMarketVal: any;
  public summationAvlQty: any;
  public orderDoughnutChartLabels:any;
  public orderDoughnutChartData:any;
  public tradeDoughnutChartLabels:any;
  public tradeDoughnutChartData:any;
  public orderDataTepm:any;
  public tradeDataTepm:any;
  public prev:any;
  public a:any;
  public b:any;
  public prevVal:any;
  public a1:any;
  public b1:any;
  public orderDoughnutChartType:string = 'pie';
  public tradeDoughnutChartType:string = 'pie';
  newArr:any;

  private dounoughtChartOptions:any = {};
  private   logoutFrmData: any = '';
  private   user_logout_result: any = '';

  public chartD:any;
  public lbl:any = [];
  public val:any = [];
  public lbl2:any = [];
  public val2:any = [];

  @ViewChild(Navbar) navBar: Navbar;
  @ViewChild(Slides) slides: Slides;
  // @ViewChild('shareHolderChart') shareHolderChart;
  @ViewChild('shareHolderChart') public shareHolderChart: ElementRef;
  // @ViewChild("shareHolderChart",{read: ElementRef}) shareHolderChart: ElementRef;


  constructor(public navCtrl: NavController,
    public globalVariableService:GlobalVariableService,
    private menu: MenuController,
    public getReportManager : ReportProvider,
    private marketWatchManager:MarketWatchProvider,
    public ngProgress: NgProgress,
    public socket: WebsocketProvider,
    public websocketUtilityManager: WebsocketUtilityService,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private storage:Storage) {
      this.orderDoughnutChartLabels=[] ;
      this.orderDoughnutChartData=[] ;
      this.tradeDoughnutChartLabels=[] ;
      this.tradeDoughnutChartData=[] ;
      this.orderDataTepm=[] ;
      this.tradeDataTepm=[] ;
      this.a=[] ;
      this.b=[] ;
      this.a1=[] ;
      this.b1=[] ;
      this.isMenuEnabled = true;
      this.menu.enable(true);
      this.ClientName = globalVariableService.clientName;
      this.percentageValue = function(value: number): string {
        return `${Math.round(value)} / ${this['max']}`;
      };

      this.defaultSegmentAccount = {
        SelectedSegment: '',
        ItemsVal:{M2M:'0.00',BPL:'0.00',CASHAVAILABLE:'0.00'}
      }
      this.userAllowedExchange=[]
      this.userIndisesArray=[]
      this.defaultExchangeAccount = {
        SelectedExchange: '',
      }
      this.defaultIndicesAccount = {
        SelectedIndices: '',
      }
      this.showAddSection=false;
      //---Set page name as orderbook--
      this.globalVariableService.setPageName({currentPageName:"DashboardPage"});

      this.summationCollateral = 0.00;
      this.summationMarketVal = 0.00;
      this.summationAvlQty = 0.00;

      this.dounoughtChartOptions = {
        legend: {
          labels: {
            fontColor: this.getLegendColor(),
            usePointStyle:true
          },
          position: 'right'
        },
        elements: {
          arc: {
            borderWidth: 1
          }
        }
      };

    }

  ionViewDidLoad(){
    // this.chartss(1,3)

    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //---Load margin report --
       this.loadMarginReport();
       //--Load asset repot--
       this.loadAssetReport();
       //--Load order book
       this.loadOrderBook();
       //---Load trade book--
       this.loadTradeBook();
       //---Load indices section --
       this.loadIndicesValue();
       //---Load indices section --
       this.loadNetPosition();
    });
    //--Get user indices data --
    this.storage.get("userIndicesMaster").then((data)=>{
      if(data!=null && data!=''){
        this.indicesLocalData = data;
      }else{
        //---Call default indices in case of no indices is set in the local storage...
        this.getDefaultIndices();
      }
      //console.log("this.indicesLocalData",this.indicesLocalData)
      if(this.indicesLocalData!=undefined){
        this.userIndisesArray=this.indicesLocalData
        setTimeout(() => {
          //this.socket.send('DELETE^*')
          this.subscribeTofeed()
        }, 2500);
      }
      //console.log("this.userIndisesArray",this.userIndisesArray)
    });
    // this.chartss(1,3)
  }
  //---load indices section --
  loadIndicesValue(){
    this.allExchange=this.userData.ExchangeMarketSegmentList;
    //---Split the section for exchange value and extract the allowed exchange from the even index of the ExchangeMarketSegmentList--
    this.availableExchangearray=this.allExchange.split("^");
    for(var i = 0; i < this.availableExchangearray.length; i += 2) {  // take every second element
      if(this.ClientName === 'Canara'){
        if(this.availableExchangearray[i]=="BSE" || this.availableExchangearray[i]=="NSE"){
            this.userAllowedExchange.push(this.availableExchangearray[i]);
        }
      }else{
        if(this.availableExchangearray[i]=="BSE" || this.availableExchangearray[i]=="NSE" || this.availableExchangearray[i]=="MCX" || this.availableExchangearray[i]=="NCDEX"){
            this.userAllowedExchange.push(this.availableExchangearray[i]);
        }
      }


    }
    //console.log("this.userAllowedExchange",this.userAllowedExchange)
    //--Load all the indices on the basis of exchange from Services.GetIndicesDetails endpoint and store in the arry respectively--
    this.defaultExchangeAccount = {SelectedExchange:this.userAllowedExchange[0]}
    //console.log("this.defaultExchangeAccount",this.defaultExchangeAccount)
    //---Service to get the detail of the scrip--
    // this.getIndicesDetails(this.defaultExchangeAccount);

  }


  // getIndicesDetails(selectedexchangeObj){
  //   this.getReportManager.getIndicesDetilsForExchange(selectedexchangeObj.SelectedExchange).then((data)=>{
  //     this.indicesDetail_result = data;
  //     if(this.indicesDetail_result.ErrorCode == 0 && this.indicesDetail_result.data!='[]'){
  //       this.indicesDetailData = JSON.parse(this.indicesDetail_result.data);
  //       //console.log("indicesDetailData",this.indicesDetailData)
  //       this.defaultIndicesAccount = {SelectedIndices:this.indicesDetailData[0].DisplayIndex}
  //       //console.log("this.defaultIndicesAccount",this.defaultIndicesAccount)
  //     }else{
  //       swal({
  //           title: "Error!",
  //           text: this.indicesDetail_result.Message,
  //           timer: 3000,
  //           showConfirmButton: false
  //       });
  //       this.defaultExchangeAccount = {SelectedExchange:this.userAllowedExchange[0]}
  //     }
  //   },err=>{
  //     swal({
  //         title: "Error!",
  //         text: "Network Issue...",
  //         timer: 3000,
  //         showConfirmButton: false
  //     });
  //     this.progressBarColor = 'Red'
  //     this.ngProgress.done();
  //   });
  // }
  //--Show Indices add --
  showIndicesAdd(){
    this.showAddSection=!this.showAddSection
  }
  //---Load Quotes page --
  loadMarketWatch(quotesObj){
    this.navCtrl.push('QuotesPage',{Quotes:quotesObj});
  }
  //--change exchange type--
  changeExchangeType(exObj){
    this.userAllowedExchange.forEach((value, index) => {
      if(value==exObj){
        this.defaultExchangeAccount = {SelectedExchange:value}
      }
    });
    //console.log("this.defaultExchangeAccount",this.defaultExchangeAccount)
    // this.getIndicesDetails(this.defaultExchangeAccount);
  }




  
  //---Change indices ntype --
  changeIndicesType(indicesObj){
    this.indicesDetailData.forEach((value, index) => {
      if(value.DisplayIndex==indicesObj.SelectedIndices){
        this.defaultIndicesAccount = {SelectedIndices:value.DisplayIndex}
      }
    });
  }
  //---Add scrip and exchange and subscribe to feed --
  addScrip(){
    //console.log("this.defaultExchangeAccount",this.defaultExchangeAccount.SelectedExchange)
    //console.log("this.defaultIndicesAccount",this.defaultIndicesAccount.SelectedIndices)
    //---Call the get specified quote end point and find the LTP--
    this.indisesVal=this.defaultExchangeAccount.SelectedExchange+"."+this.defaultIndicesAccount.SelectedIndices;
    //console.log("this.indisesVal",this.indisesVal)
    var indexData;
    this.marketWatchManager.listTicker(this.indisesVal).then((data)=>{
      this.indices_result = data;
      //----Successfully loaded market watch list ---
      if(this.indices_result.ErrorCode == '0'){
        this.listTickerData = JSON.parse(this.indices_result.data);
        indexData = JSON.parse(this.indices_result.data);
        for (var temp = 0; temp < indexData.length; temp++) {
            if (indexData[temp].Close == 0 || indexData[temp].Close == '' || indexData[temp].LTP == '' || indexData[temp].LTP == 0) {
                indexData[temp].Change = 0;
            } else {
                indexData[temp].Change = indexData[temp].LTP - indexData[temp].Close;
                indexData[temp]['%change'] = (indexData[temp].LTP - indexData[temp].Close) / indexData[temp].Close;
            }
        }
        this.listTickerData = indexData;

        var newArr = JSON.parse(this.indices_result.data);
        var newIndArr = JSON.stringify(this.userIndisesArray);
        var newIndPrseData = JSON.parse(newIndArr);
        var len = newIndPrseData.length;
        // console.log("this.userIndisesArray",newA);
        // console.log("this.userIndisesArray",newIndArr);
        for(var j=0; j < len; j++){
         if(newIndArr.indexOf(newArr[0].ticker) > -1){
          // console.log('string exit..');
          for(var k=len; k > 4; k--){
            this.userIndisesArray.pop();
          }
          this.storage.set("userIndicesMaster",this.userIndisesArray).then(()=>{
            // this.ev.publish('checkUserMasterData',this.user_login_result);
             // this.navCtrl.push('DashboardPage');
          });

          swal({
            title: "Duplicate",
            text: "Indices Already exists",
            type: "error",
            timer: 1250,
            allowOutsideClick: true,
            showConfirmButton: true
        });
        return
         }else{
          //  console.log('String not exit...');
           this.userIndisesArray.unshift(newArr[0]);
           var len = this.userIndisesArray.length;
           if(len > 4){
            for(var p=len; p > 4; p--){
              this.userIndisesArray.pop();
            }
           }
           this.storage.set("userIndicesMaster",this.userIndisesArray).then(()=>{
                      // this.ev.publish('checkUserMasterData',this.user_login_result);
                       // this.navCtrl.push('DashboardPage');
            });
           break;

         }
        }


        // this.listTickerData.forEach((value, index) => {
        //   if (this.myIndexOf(this.listTickerData[index].ticker) == -1) {
        //       this.userIndisesArray.unshift(this.listTickerData[index]);
        //       this.storage.set("userIndicesMaster",this.userIndisesArray).then(()=>{
        //           // this.ev.publish('checkUserMasterData',this.user_login_result);
        //           // this.navCtrl.push('DashboardPage');
        //       });
        //   }else{
        //     swal({
        //         title: "Duplicate",
        //         text: "Indices Already exists",
        //         type: "error",
        //         timer: 1250,
        //         allowOutsideClick: true,
        //         showConfirmButton: true
        //     });
        //     return
        //   }
        //   //console.log("this.myIndexOf(this.listTickerData[index].ticker)",this.myIndexOf(this.listTickerData[index].ticker))
        // });


        //console.log("userIndisesArray",this.userIndisesArray)
        this.storage.set("userIndicesMaster",this.userIndisesArray).then(()=>{
            // this.ev.publish('checkUserMasterData',this.user_login_result);
            // this.navCtrl.push('DashboardPage');
        });
        /*on successful binding of data from response, create scriplist variable to subscribe to feed server*/
        this.subscribeTofeed();
        this.showAddSection=false;
      }else{//----Market watch does not loaded--

      }
    }, err=> {
      // this.common.hideLoading();
    });
  }

  myIndexOf(o) {
    //console.log("o",o)
    for (var i = 0; i < 4; i++) {
      if (this.userIndisesArray[i].ticker == o) {
      return i;
      }
    }
    return -1;
  }
  subscribeTofeed(){
    // var ScripCode = "";
    var scripList = "";
    //var i = 0;
    var counter = 0;

    this.userIndisesArray.forEach((marketWatchListItems_Obj, index) => {
        var ScripExchange = marketWatchListItems_Obj.exchange;
        var ticker = marketWatchListItems_Obj.ticker.toUpperCase();
        if (ScripExchange !== '') {
            scripList = scripList + this.GetExchangeCode(ScripExchange) + '.1!' + ticker.toUpperCase() + '^';
            counter = counter + 1;
        }
        this.computeScripDetailsForIndices(marketWatchListItems_Obj, index);
    });

    this.keylist = 'ADD^' + counter + '^' + scripList;
    //console.log("KeyList from INDICES-->", this.keylist);
    //---Service to connect with the websocket --
    this.socket.connect();
    this.socket.send(this.keylist.toUpperCase());
    this.websocketUtilityManager.getFeedAfterSubscribe(this.userIndisesArray,'Dashboard').then((data)=>{
      this.indices_webSocket_Data =data;
      //console.log("this.indices_webSocket_Data--",this.indices_webSocket_Data.config)
    })

  }
  //---Load margin report --
  loadMarginReport(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getScripOrderReport("ALL","ClientBuyingPowerReport",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.marginReport_result = data;
      if(this.marginReport_result.reportTable=="" || this.marginReport_result.reportTable==null){
        this.items = '';
        this.message=this.marginReport_result.Message
      }else{
        this.items = JSON.parse(this.marginReport_result.reportTable);
        //this.defaultSegmentAccount = {SelectedSegment:this.items[0].SEGMENTACCOUNT,ItemsVal:this.items[0]}
        var len = this.items.length;
        if(this.ClientName === 'Ajcon' && len > 1){
        this.defaultSegmentAccount = {SelectedSegment:this.items[1].SEGMENTACCOUNT,ItemsVal:this.items[1]}
        }else{
          this.defaultSegmentAccount = {SelectedSegment:this.items[0].SEGMENTACCOUNT,ItemsVal:this.items[0]}
        }
        //console.log("this.defaultSegmentAccount",this.defaultSegmentAccount)
        //console.log("this.items",this.items)
        //this.bindDataAccordion();
        // this.chartss(this.items[0].GROSSAVAILABLEEXPOSURE ,this.items[0].GROSSUSEDEXPOSURE)
        this.createChart(["Available",'Utilized',],[parseFloat(this.items[0].GROSSAVAILABLEEXPOSURE),parseFloat(this.items[0].GROSSUSEDEXPOSURE)])

      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

  //---Cnahge Segment type --
  changeSegmentType(proObj){
    this.items.forEach((value, index) => {
      if(value.SEGMENTACCOUNT==proObj.SelectedSegment){
        this.defaultSegmentAccount = {SelectedSegment:value.SEGMENTACCOUNT,ItemsVal:value}
        //this.bindDataAccordion();
      }
    });
    //console.log("this.defaultSegmentAccount",this.defaultSegmentAccount)
  }

  //---Load Asset report --
  loadAssetReport(){
    // this.progressBarColor = 'white'
    // this.ngProgress.start();
    this.getReportManager.getScripOrderReport("ALL","Assets",this.userData,"").then((data)=>{
      // this.ngProgress.done();
      this.holdings_result = data;
      if(this.holdings_result.reportTable=="" || this.holdings_result.reportTable==null){
        this.holdingsItems = '';
        this.message=this.holdings_result.Message
      }else{
        this.holdingsItems = JSON.parse(this.holdings_result.reportTable);
        this.holdingsItems.forEach((value, index) => {
          // this.items[index]["exchange"]=this.items[index].Exchange;
          // this.items[index]["ticker"]=this.items[index].underlying;
          this.globalVariableService.setData({ watchlistItems: this.holdingsItems });
          this.summationCollateral += parseInt(value.CollateralValue);
          this.summationMarketVal += parseInt(value.MarketValue);
          this.summationAvlQty += parseInt(value.AvailableQty);
        });

      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      // this.progressBarColor = 'Red'
      // this.ngProgress.done();
    });
  }
  //---Show holding page--
  showAssetDetail(){
    this.navCtrl.push('HoldingsPage');
  }
  //---Load order book --
  //--- Service to call order book --
  loadOrderBook(){
    // this.progressBarColor = 'white'
    // this.ngProgress.start();
   

    this.getReportManager.getScripOrderReport("ALL","PendingOrder",this.userData,"").then((data)=>{
      //this.ngProgress.done();
      this.orderReport_result = data;
      if(this.orderReport_result.reportTable=="" || this.orderReport_result.reportTable==null){
        this.ordersItems = '';
        this.message=this.orderReport_result.Message
      }else{
        this.ordersItems = JSON.parse(this.orderReport_result.reportTable);
        //console.log("this.orderitems",this.ordersItems)
        //---call function to identify underlying,expiry,option and strike
        this.ordersItems.forEach((value, index) => {
          this.computeScripDetails(value, index);
        });
        this.ordersItems.forEach((value, index) => {
          this.ordersItems[index]["exchange"]=this.ordersItems[index].Exchange;
          this.ordersItems[index]["ticker"]=this.ordersItems[index].underlying;
          this.globalVariableService.setData({ watchlistItems: this.ordersItems });

          //---Find all the order status--
          if(this.orderDoughnutChartLabels.indexOf(value.OrderStatus) === -1) {
              this.orderDoughnutChartLabels.push(value.OrderStatus)
          }
          //--Calculate all the order type --
          this.orderDataTepm.push(value.OrderStatus)
        });

        //---First sort the array --
        this.orderDataTepm.sort();
        this.orderDoughnutChartLabels.sort();
        // console.log("this.orderDataTepm",this.orderDataTepm)
        // console.log("this.orderDoughnutChartLabels",this.orderDoughnutChartLabels)
        for ( var i = 0; i < this.orderDataTepm.length; i++ ) {
            if ( this.orderDataTepm[i] !== this.prev ) {
                this.a.push(this.orderDataTepm[i]);
                this.b.push(1);
            } else {
                this.b[this.b.length-1]++;
            }
            this.prev = this.orderDataTepm[i];
        }
        this.orderDoughnutChartData=this.b;
        var test = [];
        this.orderDoughnutChartData.forEach((value, index) => {
          test.push(this.orderDoughnutChartLabels[index] + '(' + value + ')');
          this.lbl.push(this.orderDoughnutChartLabels[index])
          this.val.push(value)
        });

        this.orderDoughnutChartLabels = test;
      //  this.loadTradeBook();

        // console.log("this.orderDoughnutChartData",this.orderDoughnutChartData)
        // console.log("test",test)
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      // this.progressBarColor = 'Red'
      // this.ngProgress.done();
    });
  }

  //--Show order detail --
  showOrderDetail(){
    this.navCtrl.push('OrderBookPage');
  }
  showTradeDetail(){
    this.navCtrl.push('TradeBookPage');
  }

  //--load trade report --
  loadTradeBook(){
    // this.progressBarColor = 'white'
    // this.ngProgress.start();
    this.getReportManager.getScripTradeReport("ALL","TradeLog",this.userData,"").then((data)=>{
      // this.ngProgress.done();
      this.tradeReport_result = data;
      if(this.tradeReport_result.reportTable=="" || this.tradeReport_result.reportTable==null){
        this.tradeItems = '';
        this.message=this.tradeReport_result.Message
      }else{
        this.tradeItems = JSON.parse(this.tradeReport_result.reportTable);
        // console.log("this.orderitems",this.items)
        //---call function to identify underlying,expiry,option and strike
        this.tradeItems.forEach((value, index) => {
          this.computeScripDetailsTrade(value, index);
        });
        this.tradeItems.forEach((value, index) => {
          this.tradeItems[index]["exchange"]=this.tradeItems[index].Exchange;
          this.tradeItems[index]["ticker"]=this.tradeItems[index].underlying;
          this.globalVariableService.setData({ watchlistItems: this.tradeItems });

          //---Find all the order status--
          if(this.tradeDoughnutChartLabels.indexOf(value['B/S']) === -1) {
              this.tradeDoughnutChartLabels.push(value['B/S'])
          }
          //--Calculate all the order type --
          this.tradeDataTepm.push(value['B/S'])
        });

        this.tradeDoughnutChartLabels.sort();
        this.tradeDataTepm.sort();
        //---Change of label index for display purpose---
        var indexB = this.tradeDoughnutChartLabels.indexOf('B');
        if (indexB !== -1) {
            this.tradeDoughnutChartLabels[indexB] = 'BUY';
        }
        var indexS = this.tradeDoughnutChartLabels.indexOf('S');
        if (indexS !== -1) {
            this.tradeDoughnutChartLabels[indexS] = 'SELL';
        }
        //---Calculating the buy and sell qty --
        for ( var flag = 0; flag < this.tradeDataTepm.length; flag++ ) {
            if ( this.tradeDataTepm[flag] !== this.prevVal ) {
                this.a1.push(this.tradeDataTepm[flag]);
                this.b1.push(1);
            } else {
                this.b1[this.b1.length-1]++;
            }
            this.prevVal = this.tradeDataTepm[flag];
        }
        this.tradeDoughnutChartData=this.b1;
        var test1 = [];
        this.tradeDoughnutChartData.forEach((value, index) => {
          test1.push(this.tradeDoughnutChartLabels[index] + '(' + value + ')');
          this.lbl2.push(this.tradeDoughnutChartLabels[index])
          this.val2.push(value)
        });
        this.tradeDoughnutChartLabels = test1;
        // console.log("tradeDoughnutChartLabels",this.tradeDoughnutChartLabels)
        // console.log("tradeDoughnutChartData",this.tradeDoughnutChartData)
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }
  //---Default loaded scrip in dashboard --
  //---service to load the footer scrip ---
  getDefaultIndices(){
    this.tickerList = "NEPSE.SENSITIVE^NEPSE.NEPSE";
    var indexData;
    this.marketWatchManager.listTicker(this.tickerList).then((data)=>{
      this.ticker_result = data;
      //----Successfully loaded market watch list ---
      if(this.ticker_result.ErrorCode == '0'){
        this.footerTickerData = JSON.parse(this.ticker_result.data);
        indexData = JSON.parse(this.ticker_result.data);
        for (var temp = 0; temp < indexData.length; temp++) {
            if (indexData[temp].Close == 0 || indexData[temp].Close == '' || indexData[temp].LTP == '' || indexData[temp].LTP == 0) {
                indexData[temp].Change = 0;
            } else {
                indexData[temp].Change = indexData[temp].LTP - indexData[temp].Close;
                indexData[temp]['%change'] = (indexData[temp].LTP - indexData[temp].Close) / indexData[temp].Close;
            }
        }
        this.footerTickerData = indexData;
        this.userIndisesArray = this.footerTickerData;
        // this.storage.set("userIndicesMaster",this.userIndisesArray).then(()=>{
        //     // this.ev.publish('checkUserMasterData',this.user_login_result);
        //     // this.navCtrl.push('DashboardPage');
        // });
        //console.log("this.footerTickerData from dashboard",this.footerTickerData)
        /*on successful binding of data from response, create scriplist variable to subscribe to feed server*/

        // var ScripCode = "";
        var scripList = "";
        //var i = 0;
        var counter = 0;

        this.footerTickerData.forEach((marketWatchListItems_Obj, index) => {
            var ScripExchange = marketWatchListItems_Obj.exchange;
            var ticker = marketWatchListItems_Obj.ticker.toUpperCase();
            if (ScripExchange !== '') {
                scripList = scripList + this.GetExchangeCode(ScripExchange) + '.1!' + ticker.toUpperCase() + '^';
                counter = counter + 1;
            }
            //this.computeScripDetails(marketWatchListItems_Obj, index);
        });

        this.keylist = 'ADD^' + counter + '^' + scripList;
        //console.log("KeyList from footer-->", this.keylist);
        //---Service to connect with the websocket --
        this.socket.connect();
        this.socket.send(this.keylist.toUpperCase());
        this.websocketUtilityManager.getFeedAfterSubscribe(this.footerTickerData,'Dashboard').then((data)=>{
          //this.footer_webSocket_Data =data;
          //console.log("this.webSocket_Data--",this.footer_webSocket_Data.config)
        })
      }else{//----Market watch does not loaded--

      }
    }, err=> {
      // this.common.hideLoading();
    });

  }

  //---Net Position section --
  loadNetPosition(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getScripOrderReport("ALL","NetPosition",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.netPosition_result = data;
      if(this.netPosition_result.reportTable=="" || this.netPosition_result.reportTable==null){
        this.itemsNetPos = '';
        this.message=this.netPosition_result.Message
      }else{
        this.itemsNetPos = JSON.parse(this.netPosition_result.reportTable);
        // console.log("this.orderitems",this.itemsNetPos)
        //---call function to identify underlying,expiry,option and strike
        this.itemsNetPos.forEach((value, index) => {
          this.computeScripDetailsNet(value, index);
        });
        this.m2m=0
        this.bpl=0
        this.itemsNetPos.forEach((value, index) => {
          this.itemsNetPos[index]["exchange"]=this.itemsNetPos[index].Exchange;
          this.itemsNetPos[index]["ticker"]=this.itemsNetPos[index].underlying;
          this.globalVariableService.setData({ watchlistItems: this.itemsNetPos });

          //---Calculation of M2M and BPL--
          this.m2m += parseFloat(value.M2M);
          this.bpl += parseFloat(value.BPL);

        });
        this.getSpecifiedQuoteValue(this.itemsNetPos);
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }
  totalCounts(data) {
    let total = 0.00;
    data.forEach((d) => {
      total += parseFloat(d.M2M);
      //total += d.M2M;
      if(total<0){
        this.negativeVal=true
      }else{
        this.negativeVal=false;
      }
    });
    return total;
  }
  getSpecifiedQuoteValue(tickersItemsObj){
    var scripList = "";
    var counter = 0;
    tickersItemsObj.forEach((value, index) => {
      var ScripExchange = value.Exchange;
      var ticker = value.ContractName.toUpperCase();
      if (ScripExchange !== '') {
          scripList = scripList + this.GetExchangeCode(ScripExchange) + '.1!' + ticker + '^';
          counter = counter + 1;
      }
    });
    var keylist = "";
    keylist = 'ADD^' + counter + '^' + scripList;
    //---Service to connect with the websocket --
    this.socket.connect();
    this.socket.send(keylist);
    this.websocketUtilityManager.getFeedAfterSubscribe(this.itemsNetPos,'Dashboard').then((data)=>{
      //this.webSocket_Data =data;
      //console.log("this.webSocket_Data--",this.webSocket_Data.config)
    })

  }
  //--- Computer Scrip details ---
  computeScripDetails(value, index){
    var tickertype = 'EQT';
    var ScripExchange = value.Exchange;
    var ticker = value.Scrip;

    //---identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
    if (ticker.search("~") > 0) {
        tickertype = 'FUT';
        if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
            tickertype = 'OPT';
        }
        if (ticker.search("~S") > 0) {
            tickertype = 'SPD';
        }
    } else {
        tickertype = 'EQT';
    }

    this.ordersItems[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

    if (tickertype == 'EQT') {
        this.ordersItems[index].underlying = ticker.toUpperCase();
        this.ordersItems[index].optType = '';
        this.ordersItems[index].strikePrice = '';
    }
    if (tickertype == 'FUT') {
        this.ordersItems[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.ordersItems[index].optType = 'F';
        this.ordersItems[index].strikePrice = '';
        this.ordersItems[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'OPT') {
        this.ordersItems[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.ordersItems[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
        this.ordersItems[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
        this.ordersItems[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'SPD') {
        this.ordersItems[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
        this.ordersItems[index].optType = 'S';
        this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
        this.ordersItems[index].ExpiryDate = '';
        this.ordersItems[index].strikePrice = this.spreadType.split("~")[0];
    }
  }
  computeScripDetailsNet(value, index){
    var tickertype = 'EQT';
    var ScripExchange = value.Exchange;
    var ticker = value.Scrip;

    //---identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
    if (ticker.search("~") > 0) {
        tickertype = 'FUT';
        if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
            tickertype = 'OPT';
        }
        if (ticker.search("~S") > 0) {
            tickertype = 'SPD';
        }
    } else {
        tickertype = 'EQT';
    }

    this.itemsNetPos[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

    if (tickertype == 'EQT') {
        this.itemsNetPos[index].underlying = ticker.toUpperCase();
        this.itemsNetPos[index].optType = '';
        this.itemsNetPos[index].strikePrice = '';
    }
    if (tickertype == 'FUT') {
        this.itemsNetPos[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.itemsNetPos[index].optType = 'F';
        this.itemsNetPos[index].strikePrice = '';
        this.itemsNetPos[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'OPT') {
        this.itemsNetPos[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.itemsNetPos[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
        this.itemsNetPos[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
        this.itemsNetPos[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'SPD') {
        this.itemsNetPos[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
        this.itemsNetPos[index].optType = 'S';
        this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
        this.itemsNetPos[index].ExpiryDate = '';
        this.itemsNetPos[index].strikePrice = this.spreadType.split("~")[0];
    }
  }
  //--- Computer Scrip details ---
  computeScripDetailsTrade(value, index){
    var tickertype = 'EQT';
    var ScripExchange = value.Exchange;
    var ticker = value.Scrip;

    //---identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
    if (ticker.search("~") > 0) {
        tickertype = 'FUT';
        if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
            tickertype = 'OPT';
        }
        if (ticker.search("~S") > 0) {
            tickertype = 'SPD';
        }
    } else {
        tickertype = 'EQT';
    }

    this.tradeItems[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

    if (tickertype == 'EQT') {
        this.tradeItems[index].underlying = ticker.toUpperCase();
        this.tradeItems[index].optType = '';
        this.tradeItems[index].strikePrice = '';
    }
    if (tickertype == 'FUT') {
        this.tradeItems[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.tradeItems[index].optType = 'F';
        this.tradeItems[index].strikePrice = '';
        this.tradeItems[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'OPT') {
        this.tradeItems[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.tradeItems[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
        this.tradeItems[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
        this.tradeItems[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'SPD') {
        this.tradeItems[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
        this.tradeItems[index].optType = 'S';
        this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
        this.tradeItems[index].ExpiryDate = '';
        this.tradeItems[index].strikePrice = this.spreadType.split("~")[0];
    }
  }
  //--- Get exchange legend --
  GetExchangeLegend(Exchange){
    //console.log("Exchange",Exchange)
    var strCode = "";
    switch (Exchange) {
        case "NSE":
            strCode = "N";
            break;
        case "BSE":
            strCode = "B";
            break;
        case "FOBSE":
            strCode = "B";
            break;
        case "CDBSE":
            strCode = "B, CU";
            break;
        case "FONSE":
            strCode = "N";
            break;
        case "ACE":
            strCode = "A";
            break;
        case "CDNSE":
            strCode = "N, CU";
            break;
        case "MCX":
            strCode = "M";
            break;
        case "COMNSE":
            strCode = "COM";
            break;
        case "NCDEX":
            strCode = "X";
            break;
        case "MCXSX":
            strCode = "M, CU";
            break;
        case "NSEL":
            strCode = "NS";
            break;
        case "MCXSXEQ":
            strCode = "M, EQ";
            break;
        case "MCXSXFO":
            strCode = "M, FO";
            break;
            case "NEPSE":
              strCode = "NEP";
              break;
    }
    return (strCode);
  }

  /*set exchange code in order to build keylist to register for feed.*/
  GetExchangeCode(Exchange) {
      var strCode = "0";
      switch (Exchange) {
          case "NSE":
          case "FONSE":
              strCode = "4";
              break;
          case "BSE":
          case "FOBSE":
              strCode = "1";
              break;
          case "ACE":
              strCode = "10";
              break;
          case "CDNSE":
              strCode = "13";
              break;
          case "MCX":
              strCode = "7";
              break;
          case "COMNSE":
              strCode = "5";
              break;
          case "NCDEX":
              strCode = "8";
              break;
          case "MCXSX":
              strCode = "14";
              break;
          case "NSEL":
              strCode = "36";
              break;
          case "MCXSXEQ":
              strCode = "64";
              break;
          case "MCXSXFO":
              strCode = "65";
              break;
          case "CDBSE":
              strCode = "17";
              break;
              case "NEPSE":
                strCode = "25";
                break;
      }
      return (strCode);
  }

  //----Compute script detail---
  computeScripDetailsForIndices(value, index) {
      var tickertype = 'EQT';
      var ScripExchange = value.exchange;
      var ticker = value.ticker.toUpperCase();

      //identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
      if (ticker.search("~") > 0) {
          tickertype = 'FUT';
          if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
              tickertype = 'OPT';
          }

          if (ticker.search("~S") > 0) {
              tickertype = 'SPD';
          }
      } else {
          tickertype = 'EQT';
      }

      this.userIndisesArray[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

      if (tickertype == 'EQT') {
          this.userIndisesArray[index].underlying = ticker.toUpperCase();
          this.userIndisesArray[index].optType = '';
          this.userIndisesArray[index].strikePrice = '';
      }

      if (tickertype == 'FUT') {
          this.userIndisesArray[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
          this.userIndisesArray[index].optType = 'F';
          this.userIndisesArray[index].strikePrice = '';
      }
      if (tickertype == 'SPD') {
          this.userIndisesArray[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
          this.userIndisesArray[index].strikePrice = '';
          this.userIndisesArray[index].optType = 'S';
          this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
          this.userIndisesArray[index].strikePrice = this.spreadType.split("~")[0];

      }
      if (tickertype == 'OPT') {
          this.userIndisesArray[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
          this.userIndisesArray[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
          this.userIndisesArray[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);

      }
  }

  // events
  public chartClicked(e:any):void {
    //console.log(e);

  }

  public chartHovered(e:any):void {
    //console.log(e);
  }

  
  getLegendColor() {
    let colorCode = '#141415'
    if(this.ClientName == 'Jetrade' || this.ClientName == 'DionBlack' || this.ClientName == 'Bgse') {
      colorCode = '#ffffff'
    } else if (this.ClientName == 'Arch') {
      colorCode = '#141415'
    } else if (this.ClientName == 'Asnani') {
      colorCode = '#333'
    }
    return colorCode;
  }
  
  public MyCollateral(v){
    let val = 0.0
    val = parseFloat(v.GROSSAVAILABLEEXPOSURE) + parseFloat(v.GROSSUSEDEXPOSURE)
    return val;
  }

  public tradedShrs(v){
    let val = 0.0
    for(let q=0; q< v.length; q++){
       val = parseInt(v[q].Quantity) + val;
    }
    // val = parseFloat(v.GROSSAVAILABLEEXPOSURE) + parseFloat(v.GROSSUSEDEXPOSURE)
    return val;
  }



  chartss(GROSSAVAILABLE,GROSSUSED){

    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ['Task', 'Hours per Day'],
        ['Available',     parseFloat(GROSSAVAILABLE)],
        // ['Utilized',      233288483],
        ['GROSS USED EXPOSURE',      parseFloat(GROSSUSED)],
      ]);

      var options = {
        // title: 'My Collateral Summary',
        is3D: true,
        legend: 'none',
        slices: {
          0: {color:'#a51e1c' },
          1: {color:'#1e529f' },
          2: {color:'#74a10f'},
          3: {color:'#e38690'},
          4: {color:'#ead98b'}    
        },
          chartArea: {'backgroundColor':'red'}
      };

      var chart = new google.visualization.PieChart(document.getElementById('piechart'));

      chart.draw(data, options);
    }
  }

    // this.createChart2(["Pramoters",'Inst. Investor','Other Invester'],[17,24,50])

  createChart(c_labels, c_data) {
    // c_data = [12,32]
    var colors = [
      'rgb(220, 204, 108)',
      'rgb(13, 34, 65)',
      'rgb(247, 70, 74)',
      'rgb(148, 159, 177)',
      'rgb(51, 143, 82)',
      'rgb(77, 83, 96)',
      'rgb(180, 142, 173)',
      'rgb(150, 181, 180)',
      'rgb(235, 203, 138)',
      /*'rgb(94, 65, 149)',
      'rgb(171, 121, 103)',
      'rgb(134, 175, 18)'*/
    ];
    var labels = c_labels;
    var data = c_data;
    var bgColor = colors;
    var dataChart = {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: bgColor
      }]
    };
    var config = {
      type: 'doughnut',
      data: dataChart,
      options: {
        maintainAspectRatio: false,
        cutoutPercentage: 45,
        legend: {
          display: false
        },
        legendCallback: function (chart) {
          var text = [];
          text.push('<ul class="doughnut-legend">');
          if (chart.data.datasets.length) {
            // for (var i = 0; i < chart.data.datasets[0].data.length; ++i) {
            //   text.push('<li><span class="doughnut-legend-icon" style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '"></span>');
            //   if (chart.data.labels[i]) {
            //     text.push('<span class="doughnut-legend-text">' + chart.data.labels[i] + '</span>');
            //   }
            //   text.push('</li>');
            // }
          }
          text.push('</ul>');
          return text.join("");
        },
        tooltips: {
          yPadding: 10,
          callbacks: {
            label: function (tooltipItem, data) {
              var total = 0;
              data.datasets[tooltipItem.datasetIndex].data.forEach(function (element /*, index, array*/) {
                total += element;
              });
              var value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
              var percentTxt = Math.round(value / total * 100);
              return data.labels[tooltipItem.index] + ': ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index] + ' (' + percentTxt + '%)';
            }
          }
        }
      }
    };
    var ctx: any = document.getElementById("doughnutChart")
    let ct = ctx.getContext("2d");
    var doughnutChart = new Chart(ct, config);

    var legend = doughnutChart.generateLegend();
    var legendHolder = document.getElementById("legend");
    // this.createChartOrder('a',2)

    setTimeout(() => {
      this.createChartOrder(this.lbl,this.val)
    }, 2000);

    // legendHolder.innerHTML = legend + '<div style="font-size: smaller">Total : <strong>' + 1703 + '</strong></div>';

  }


  createChartOrder(c_labels, c_data) {
    // c_data = [12,32]
    // c_labels = ['Accpt','Rejct']
    var colors = [
      // 'rgb(0, 0, 230)',
      'rgb(51, 143, 82)',
      'rgb(255, 0, 102)',
      'rgb(13, 34, 65)',
      // 'rgb(214, 0, 0)',
      'rgb(148, 159, 177)',
      'rgb(77, 83, 96)',
      'rgb(180, 142, 173)',
      'rgb(150, 181, 180)',
      'rgb(235, 203, 138)',
      /*'rgb(94, 65, 149)',
      'rgb(171, 121, 103)',
      'rgb(134, 175, 18)'*/
    ];
    var labels = c_labels;
    var data = c_data;
    var bgColor = colors;
    var dataChart = {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: bgColor
      }]
    };
    var config = {
      type: 'doughnut',
      data: dataChart,
      options: {
        maintainAspectRatio: false,
        cutoutPercentage: 45,
        legend: {
          display: false
        },
        legendCallback: function (chart) {
          var text = [];
          text.push('<ul class="doughnut-legend">');
          if (chart.data.datasets.length) {
            // for (var i = 0; i < chart.data.datasets[0].data.length; ++i) {
            //   text.push('<li><span class="doughnut-legend-icon" style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '"></span>');
            //   if (chart.data.labels[i]) {
            //     text.push('<span class="doughnut-legend-text">' + chart.data.labels[i] + '</span>');
            //   }
            //   text.push('</li>');
            // }
          }
          text.push('</ul>');
          return text.join("");
        },
        tooltips: {
          yPadding: 10,
          callbacks: {
            label: function (tooltipItem, data) {
              var total = 0;
              data.datasets[tooltipItem.datasetIndex].data.forEach(function (element /*, index, array*/) {
                total += element;
              });
              var value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
              var percentTxt = Math.round(value / total * 100);
              return data.labels[tooltipItem.index] + ': ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index] + ' (' + percentTxt + '%)';
            }
          }
        }
      }
    };
    var ctx: any = document.getElementById("doughnutChart2")
    let ct = ctx.getContext("2d");
    var doughnutChart = new Chart(ct, config);

    var legend = doughnutChart.generateLegend();
    var legendHolder = document.getElementById("legend");
    // legendHolder.innerHTML = legend + '<div style="font-size: smaller">Total : <strong>' + 1703 + '</strong></div>';
    setTimeout(() => {
      this.createChartTrade(this.lbl2,this.val2)
    }, 2000);
  }

  createChartTrade(c_labels, c_data) {
    // c_data = [12,32]
    // c_labels = ['Accpt','Rejct']
    var colors = [
      'rgb(0, 0, 230)',
      // 'rgb(51, 143, 82)',
      // 'rgb(255, 0, 102)',
      // 'rgb(13, 34, 65)',
      'rgb(214, 0, 0)',
      'rgb(148, 159, 177)',
      'rgb(77, 83, 96)',
      'rgb(180, 142, 173)',
      'rgb(150, 181, 180)',
      'rgb(235, 203, 138)',
      /*'rgb(94, 65, 149)',
      'rgb(171, 121, 103)',
      'rgb(134, 175, 18)'*/
    ];
    var labels = c_labels;
    var data = c_data;
    var bgColor = colors;
    var dataChart = {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: bgColor
      }]
    };
    var config = {
      type: 'doughnut',
      data: dataChart,
      options: {
        maintainAspectRatio: false,
        cutoutPercentage: 45,
        legend: {
          display: false
        },
        legendCallback: function (chart) {
          var text = [];
          text.push('<ul class="doughnut-legend">');
          if (chart.data.datasets.length) {
            // for (var i = 0; i < chart.data.datasets[0].data.length; ++i) {
            //   text.push('<li><span class="doughnut-legend-icon" style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '"></span>');
            //   if (chart.data.labels[i]) {
            //     text.push('<span class="doughnut-legend-text">' + chart.data.labels[i] + '</span>');
            //   }
            //   text.push('</li>');
            // }
          }
          text.push('</ul>');
          return text.join("");
        },
        tooltips: {
          yPadding: 10,
          callbacks: {
            label: function (tooltipItem, data) {
              var total = 0;
              data.datasets[tooltipItem.datasetIndex].data.forEach(function (element /*, index, array*/) {
                total += element;
              });
              var value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
              var percentTxt = Math.round(value / total * 100);
              return data.labels[tooltipItem.index] + ': ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index] + ' (' + percentTxt + '%)';
            }
          }
        }
      }
    };
    var ctx: any = document.getElementById("doughnutChart3")
    let ct = ctx.getContext("2d");
    var doughnutChart = new Chart(ct, config);

    var legend = doughnutChart.generateLegend();
    var legendHolder = document.getElementById("legend");
    // legendHolder.innerHTML = legend + '<div style="font-size: smaller">Total : <strong>' + 1703 + '</strong></div>';

  }

   
}








