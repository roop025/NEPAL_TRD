import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DashboardPage } from './dashboard';
//import { GaugeModule } from 'angular-gauge';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
import { ChartsModule } from 'ng2-charts';
import {PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    DashboardPage,
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    ChartsModule,
    PipesModule,
    //GaugeModule.forRoot(),
    IonicPageModule.forChild(DashboardPage),
  ],
})
export class DashboardPageModule {}
