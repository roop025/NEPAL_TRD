import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PortfolioTrackerProvider } from '../../providers/portfolio-tracker/portfolio-tracker';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the EquityPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-equity',
  templateUrl: '../../pages/DionBlack/equity/equity.html',
})
export class EquityPage {
  userData:any;
  listOfPortfolio:any[]=[];
  constructor(public navCtrl: NavController,public storage:Storage, public navParams: NavParams,public pt_traker:PortfolioTrackerProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PortfolioSummaryPage');
    // let obj=
    // {
    //   "ServiceName":"EquityHoldingSummary",
    //   "ParameterList":"LoginID=128605$AccountID=0$Type=A"
    

    // }
    this.storage.get("userMaster").then((data)=>{
      if(data!=null && data!=''){
       console.log(data);
       this.userData=data;
       this.getEquityTransactions();
      //  this.getPortFolioNetworth();

      let obj=
    {
      "ServiceName":"AccountNamesForLoginId",
      "ParameterList":`LoginID=${this.userData.ClientCode}`
    

    }
    this.pt_traker.getPTServicesDownloadReport(obj).then(_ptdata=>{
     
      if(_ptdata.ErrorCode==0)
      {
        console.log("Suceess",_ptdata);
        this.listOfPortfolio=_ptdata.DataSet.Table;
      }
    }).catch(ee=>{
      console.log(ee);
      
    })
  }
});
  }

  getEquityTransactions()
  {

  }

  getPortFolioNetworth()
  {

  }
}
