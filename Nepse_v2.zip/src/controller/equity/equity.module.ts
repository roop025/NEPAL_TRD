import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EquityPage } from './equity';

@NgModule({
  declarations: [
    EquityPage,
  ],
  imports: [
    IonicPageModule.forChild(EquityPage),
  ],
})
export class EquityPageModule {}
