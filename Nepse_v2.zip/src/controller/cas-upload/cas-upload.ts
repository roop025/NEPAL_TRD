import { Component } from '@angular/core';
import {IonicPage, NavController, NavParams,MenuController, ActionSheetController} from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import { PortfolioManagerProvider } from '../../providers/portfolio-manager/portfolio-manager';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { Camera, CameraOptions } from '@ionic-native/camera';
// import { CameraPreview, CameraPreviewPictureOptions, CameraPreviewOptions, CameraPreviewDimensions } from '@ionic-native/camera-preview/ngx';
import { Observable, Observer } from 'rxjs';
import { _localeFactory } from '@angular/core/src/application_module';
import { Chooser } from '@ionic-native/chooser';
// import { ImagePicker } from '@ionic-native/image-picker';

// import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer/ngx';
// import { File } from '@ionic-native/file';


/**
 * Generated class for the UserProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 // private transfer: FileTransfer,
 //      private file: File


@IonicPage()
@Component({
  selector: 'page-cas-upload',
  templateUrl: '../../pages/DionBlack/cas-upload/cas-upload.html',

})
export class CasUploadPage {
  // file: File;
  userProfileData:any;
  sourcetype:any='CAMS';
  pdf_password:any;
  fileByteArray:any[]=[];
  pdf_file_name:any='';
  constructor(public navCtrl: NavController,
     public navParams: NavParams,
     private menu: MenuController,
     public globalVar    : GlobalVariableService,
     private common      : CommonProvider,
     private portfolioManager: PortfolioManagerProvider,
     private userManager: UserManagerProvider,
     private actionSheet: ActionSheetController,
     private camera: Camera,public chooser:Chooser

     ) {
      this.menu.enable(true);
      this.userProfileData = this.globalVar.userDetailFromGetInvestor[0];
      console.log("this.userProfileData"+ JSON.stringify(this.userProfileData));
  }



  ionViewDidLoad() {
    console.log('ionViewDidLoad Cash Upload page');

  }


   changeListener($event) : void {
    // this.file = $event.target.files[0];
    // console.log(this.file);
    // var reader = new FileReader();
     this.fileByteArray = [];
    // reader.readAsArrayBuffer(this.file);
    // reader.onloadend =  (evt:any)=> {
    //     if (evt.target.readyState) {
    //        var arrayBuffer = evt.target.result,
    //            array = new Uint8Array(arrayBuffer);
    //        for (var i = 0; i < array.length; i++) {
    //         this.fileByteArray.push(array[i]);
    //         }
    //         console.log("Byte arry",this.fileByteArray);
            
    //     }
    // }

    this.chooser.getFile('application/pdf').then((file:any) => {
      console.log(file);

                 var arrayBuffer =file.data,
               array = new Uint8Array(arrayBuffer);
           for (var i = 0; i < array.length; i++) {
            this.fileByteArray.push(array[i]);
            }
      // this.fileByteArray=file.data || '';
      this.pdf_file_name=file.name || '';

    })
    .catch((error: any) => console.error(error));


  }



  uploadPDf()
  {


    let upload_obj=
    {
    //  Source:this.sourcetype,
      Password:this.pdf_password,
      PANNo: this.userProfileData.vcClientPANNo,
      PdfContent:this.fileByteArray,
      CreatedBy:this.globalVar.clientId || ''
    }
    console.log("Object",upload_obj);
    this.common.showLoading()
this.common.saveCasPDF(upload_obj).then(uploaded=>{
  this.common.hideLoading();
  this.pdf_file_name='';
  this.pdf_password='';
  this.fileByteArray = [];
}).catch(err=>{
  this.common.hideLoading()
})

  }
}
