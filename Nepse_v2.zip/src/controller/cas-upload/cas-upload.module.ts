import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CasUploadPage } from './cas-upload';
import { Chooser } from '@ionic-native/chooser';

@NgModule({
  declarations: [
    CasUploadPage,
  ],
  imports: [
    IonicPageModule.forChild(CasUploadPage),
  ],
  providers:[Chooser]
})
export class CasUploadPageModule {}
