import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import { PortfolioManagerProvider } from '../../providers/portfolio-manager/portfolio-manager';

/**
 * Generated class for the FolioReportPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-folio-report',
  templateUrl: '../../pages/DionBlack/folio-report/folio-report.html',
})

export class FolioReportPage {
  public portfolio_summary_Result: any;
  public portfolio_History: any;
  public portfolio_summary_show: any;
  public pagelist: any;
  public popovershow: boolean = false;
  public selectedFolioObject: any;
  public folioSummaryForSelectedFolio: any;
  public portFolioListMaster: any;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public globalVar    : GlobalVariableService,
              private common      : CommonProvider,
              private portfolioManager: PortfolioManagerProvider,
              public menu         : MenuController) {

                this.portfolio_summary_Result = this.navParams.get('folioReportData');
                this.portfolio_History = this.navParams.get('folioHistory');
                this.selectedFolioObject = this.navParams.get('selectedFolioObject');
                this.portFolioListMaster = this.portfolio_summary_Result.ReportTable5;
                this.folioSummaryForSelectedFolio = [];

                for(var i = 0; i < this.portFolioListMaster.length;i++){
                  if(this.portFolioListMaster[i].schcode == this.selectedFolioObject.schcode && this.portFolioListMaster[i].FolioNo == this.selectedFolioObject.FolioNo){
                    this.folioSummaryForSelectedFolio.push(this.portFolioListMaster[i]);
                  }
                }

                this.pagelist = [{ text: "Redeem", value: "R" }, { text: "Purchase", value: "AP" }, { text: "ISIP", value: "ISIP" }, { text: "XSIP", value: "XSIP" }, { text: "SIP", value: "SIP" }];
                if(this.portfolio_History == undefined){
                    this.portfolio_History = [];
                }

                if(this.portfolio_summary_Result != undefined){
                  this.portfolio_summary_show = this.portfolio_summary_Result.ReportTable4
                }
                else{
                  this.portfolio_summary_show = [];
                }

                console.log("this.portfolioSummary_Result"+ JSON.stringify(this.portfolio_summary_Result));
                console.log("this.portfolio_History"+ JSON.stringify(this.portfolio_History));
  }

  show() {
      this.popovershow = !this.popovershow;
  }


  gotoformpage(obj, selectedScheme) {

    this.globalVar.setOrderType("FolioOrder");
    this.navCtrl.push('FolioOrderPage', { inputSchemeObj: selectedScheme, PlaceOrderObj: selectedScheme, tag: obj });
  }

  // gotoformpage(obj, selectedScheme) {
  //
  //
  //   console.log("obj" + JSON.stringify(obj));
  //   console.log("selectedScheme" + JSON.stringify(selectedScheme));
  //   this.globalVar.isOrderEdit = false;
  //   this.globalVar.isOrderFromHolding = true;
  //   if(obj.value == 'R'){
  //     this.globalVar.isOrderRedeem = true;
  //   } else this.globalVar.isOrderRedeem = false;
  //     // this.navCtrl.push('AdditionalPurchasePage');
  //   this.globalVar.setOrderType("HoldingOrder");
  //   this.navCtrl.push('FpOrderFormPage', { inputSchemeObj: selectedScheme, PlaceOrderObj: selectedScheme, tag: obj });
  // }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FolioReportPage');
  }

}
