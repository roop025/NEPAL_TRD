import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FolioReportPage } from './folio-report';

@NgModule({
  declarations: [
    FolioReportPage,
  ],
  imports: [
    IonicPageModule.forChild(FolioReportPage),
  ],
})
export class FolioReportPageModule {}
