import { Component } from '@angular/core';
import { NavController , IonicPage,NavParams} from 'ionic-angular';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';

import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';

@IonicPage()
@Component({
  selector: 'page-dp-hold-report',
  templateUrl: '../../pages/DionWhite/dp-hold-report/dp-hold-report.html'
})

export class DpHoldReportPage {

  public progressBarColor : any;
  public userData : any;
  public marginReport_result : any;
  public items : any;
  public message : any;
  public defaultSegmentAccount : any;
  public shownGroup : any;
  public groups : any;
  public ClientName : any;
  private logoutFrmData : any;
  private   user_logout_result: any = '';

  public holdData : any;
  public holdObj : {
      isin:'',
      dpid:'',
      segment:'',
      exhange:'NSE',
      qunty:''
  };

  public dpid_list:any;
  public segmet_list:any;
  public exchange_list:any;
  public report_result:any;



  constructor(public navCtrl: NavController,
    public ngProgress: NgProgress,
    private globalVariableService : GlobalVariableService,
    public getReportManager : ReportProvider,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private storage:Storage,
    public navParams:NavParams
  ) {
    this.defaultSegmentAccount = {
      SelectedSegment: ''
    }
    this.groups = [];
    this.ClientName = globalVariableService.clientName;
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"MarginPage"});

    this.holdData = this.navParams.get('holdObj');
    // console.log("this.holdData ---->>");
   // console.log(this.holdData['ISIN No']);
    this.holdObj ={isin:this.holdData['ISIN No'],dpid:'',segment:'',exhange:'NSE',qunty:''};

  }

  ionViewDidLoad(){
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //---Load margin report --
       this.getDPID();
    });

  }
  //---Cnahge Segment type --
  changeSegmentType(proObj){
    this.items.forEach((value, index) => {
      if(value.SEGMENTACCOUNT==proObj.SelectedSegment){
        this.defaultSegmentAccount = {SelectedSegment:value.SEGMENTACCOUNT,ItemsVal:value}
        //this.bindDataAccordion();
      }
    });
  }



  getDPID(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getDPID_OR_SegmentReport(this.userData.ClientCode,"GetDPId").then((data)=>{
      this.ngProgress.done();
      this.marginReport_result = data;
      if(this.marginReport_result.reportTable=="" || this.marginReport_result.reportTable==null){
        this.dpid_list = '';
        this.message=this.marginReport_result.Message
      }else{
        this.dpid_list = JSON.parse(this.marginReport_result.reportTable);
        this.holdObj.dpid = this.dpid_list[0]['DPID'];

        //console.log(this.dpid_list)
       
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }

// Get Sigment here

  getSegment(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getDPID_OR_SegmentReport(this.userData.ClientCode,"GetSegmentAccount").then((data)=>{
      this.ngProgress.done();
      this.marginReport_result = data;
      if(this.marginReport_result.reportTable=="" || this.marginReport_result.reportTable==null){
        this.segmet_list = '';
        this.message=this.marginReport_result.Message
      }else{
        this.segmet_list = JSON.parse(this.marginReport_result.reportTable);
        this.holdObj.segment = this.segmet_list[0]['segmentaccount'];

        //console.log(this.segmet_list);
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }
 


  // Get Exchage Data  here

  submitHold_Data(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    // console.log("this.holdObj dat --------->");
    //console.log(this.holdObj);
    this.getReportManager.submitHoldData(this.userData.ClientCode,this.holdObj).then((data)=>{
      this.ngProgress.done();
       this.report_result = data;
      if(this.report_result.ErrorCode == 0 && this.report_result.ServiceResponse !=null){
        this.holdData = '';
        this.message=this.report_result.DatabaseResponse;
        var msg =this.report_result.Message;
        this.storage.set("dpHoldRecord",this.holdObj).then(()=>{
            console.log("this.holdObj set storage")
            console.log(this.holdObj)
        });
        swal({
            title: msg,
            text: this.message,
            timer: 3000,
            type: "success"
        });
        this.navCtrl.push('DpAllocationPage');
      }else{
        
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }
 

  showDpHoldSuccessReport(){

  }







  //---Toggling of scrip section--
    toggleGroup (group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
        } else {
            //this.getScripRate(group);
            this.shownGroup = group;
        }
    }
    isGroupShown(group) {
        return this.shownGroup === group;
    }
  //---//--pull down to refresh --
  doRefresh(refresher) {
    // this.loadMarginReport()
    setTimeout(() => {
      refresher.complete();
    }, 1000);
  }
}
