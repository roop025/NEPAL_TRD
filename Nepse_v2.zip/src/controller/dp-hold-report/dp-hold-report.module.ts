import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DpHoldReportPage } from './dp-hold-report';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    DpHoldReportPage,
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(DpHoldReportPage),
  ],
})
export class DpHoldReportPageModule {}
