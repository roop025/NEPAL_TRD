import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ViewController } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-filters',
  templateUrl: '../../pages/DionWhite/filters/filters.html',
})
export class FiltersPage {
  poupData:any;
  adults=1;
  children=0;
  infants=0;
  personDetail
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public viewCtrl: ViewController,
    ) {
      this.personDetail = {  adults: 1,  children: 0,  infants: 0 };
      this.poupData =navParams.get('data')

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PopupPage');
  }

  closeModal(d){
    //let data = { 'foo': 'bar' };
    console.log(d)
    this.viewCtrl.dismiss(d);
  }

  getFilter(val){
    if(val == 'reset'){
      this.viewCtrl.dismiss({filterAt:"reset"})
    } else if(val == 'value'){
      this.viewCtrl.dismiss({filterAt:"value"})
    }  else if(val == 'TQty'){
      this.viewCtrl.dismiss({filterAt:"TQty"})
    }
    else if(val == 'RQty'){
      this.viewCtrl.dismiss({filterAt:"RQty"})
    }
    else if(val == 'qty'){
      this.viewCtrl.dismiss({filterAt:"qty"})
    }
    else if(val == 'atoz'){
      this.viewCtrl.dismiss({filterAt:"atoz"})
    } else {
      this.viewCtrl.dismiss({filterAt:"price"})
    }
    // this.viewCtrl.dismiss({adults:this.adults,children:this.children,infants:this.infants})
  }

}
