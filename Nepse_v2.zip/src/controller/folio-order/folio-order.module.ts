import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FolioOrderPage } from './folio-order';
import { IonicSelectableModule } from 'ionic-selectable';


@NgModule({
  declarations: [
    FolioOrderPage,
  ],
  imports: [
    IonicPageModule.forChild(FolioOrderPage),
    IonicSelectableModule
  ],
})
export class FolioOrderPageModule {}
