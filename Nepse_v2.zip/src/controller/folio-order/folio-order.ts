import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,AlertController } from 'ionic-angular';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { CommonProvider } from '../../providers/common/common';
import swal from 'sweetalert2';
import { PlaceorderManagerProvider } from '../../providers/placeorder-manager/placeorder-manager';
import { Http } from '@angular/http';
import { IonicSelectableComponent } from 'ionic-selectable';
import { InAppBrowser } from '@ionic-native/in-app-browser';

/**
 * Generated class for the FolioOrderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-folio-order',
  templateUrl: '../../pages/DionBlack/folio-order/folio-order.html',
})
export class FolioOrderPage {

  public show: boolean = false;
  public IsSIP: boolean = false;
  public isSwitchType: boolean = false;
  public isAddToCart: boolean = false;
  public isSwitchScheme: boolean = false;
  public disableSwitch: boolean;

  public buttonName: any = 'Show Details';
  public ShowHideClass: any = 'add-circle';
  private getSchemeDetailByISIN_result: any;
  private getBankDetails_result: any;
  private placeOrder_result: any;
  private getFrequency_result: any;
  private getSIPDates_result: any;
  private getMadateID_result: any;
  private Frequency: any;
  private SIPDates: any;
  private Tenure: any;
  private BankDetail: any;
  private SchemeDetail: any;
  private SchemeObj: any;
  private inputSchemeObj: any;
  private MandateDetail: any;
  public minAmount: any = " ";
  private productPermissionDetail: any;
  private GetInvestorProductPermission_result: any;
  private showSublineToAmount: boolean;
  private getSchemeDetailByToken: any;
  public EditAmount: any;
  private modifyOrder_result: any;

  public selectedBank: any;
  public isTermsAndConditionChecked: any;

  private SIPXSIPISIPConfigDetail: any;
  public disableModify : boolean
  public SchemeCodeFromISINDetail: any;
  public tag: any;

  // tag = "";
  Amount: any;
  folioNumber: any;
  // this.ddlorderType = [{ value: "MFD", text: "MFD" }]
  TransactionMode: any;
  Bank: any;
  option: any = "";
  selectedFrequency: any;
  GFOT: any;
  selectedSIPDate: any;
  selectedTenure: any;
  selectedMadnateID: any;

  showOrderType: boolean;
  showTransactionMode: boolean;

  ddlTransactionMode: any;
  ddlorderType: any;
  orderType: any;
  alertMFIMFD: any;
  nameOrderType: any;
  schemeDetailFromApi: any;
  public switchTypeddl: any;
  public switchTypeVal: any;

  public fpOpenedFrom : any;
  private schemeListForSwitch_result: any
  public schemeListForSwitchList: any;
  public selectedNewScheme: any;
  public productPermissionModify: any;
  // added for redemption addon
  public requestedRedeemUnit:any;
  public redemptionTypeddl: any;
  public redemptionTypeVal: any;
  public availableUnit: any;
  public redAmountMax: any;
  public redAmountMin: any;
  public redAmountMul: any;
  public redMinQty: any;
  public redMulQty: any;
  public isAllUnitFlag: boolean = false;
  public availableAmount: any;
  public disableisAllUnitFlag: boolean = false;

  public clientFolio_result: any;
  public clientFolioData: any;
  public isInitialAmountZero: boolean = true;
  public isOrderTypeNormal: boolean = false;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public globalVar: GlobalVariableService,
    private common: CommonProvider,
    private placeorderManager: PlaceorderManagerProvider,
    public alertCtrl: AlertController,
    private iab: InAppBrowser,
    public http: Http) {

    this.orderType ={ value: "MFD", text: "MFD" };
    this.isTermsAndConditionChecked = {checkedData :false};
    this.inputSchemeObj =this.navParams.get("inputSchemeObj");
    this.folioNumber = this.inputSchemeObj.FolioNo;
console.log("InputsObj",this.inputSchemeObj);

    // this.tag = this.navParams.get("tag");
    this.tag =this.navParams.get("tag").value;
    console.log("Tagg>>>",this.tag);
    
    this.isOrderTypeNormal = (this.tag == 'FP') || (this.tag == 'SIP') || (this.tag == 'XSIP') || (this.tag == 'ISIP') || (this.tag == 'SWP');
    console.log("isOrderTypeNormal" +this.isOrderTypeNormal);
    this.BankDetail = [];
    var clientCode = this.globalVar.clientId;

      this.TransactionMode = this.common.allowedTransactionModeList[0];
      if(this.TransactionMode.value == "Demat"){
        this.redemptionTypeddl =  [{ text: "Unit", value: "unit" }]
      } else {
        this.redemptionTypeddl =  [{ text: "Amount", value: "amount" },{ text: "Unit", value: "unit" }]
      }
      this.redemptionTypeVal = this.redemptionTypeddl[0];

      // this.option = this.inputSchemeObj.TrxnType;

      this.getSchemeDetailByISIN();


      // this.getSchemeDetailByToken()

      if (this.tag == "SIP") {
        this.IsSIP= true;
        this.getFrequency();
      }
      else if (this.tag == "XSIP") {
        this.IsSIP= true;
        this.getFrequency();
        this.getMandateIDs();

      }
      else if (this.tag == "ISIP") {
        this.IsSIP= true;
        this.getFrequency();
        this.getMandateIDs();
      }
       else if(this.tag == "SWITCH"){
         this.isSwitchType = true;
         this.IsSIP = false;
       }

      // this.getClientFolio();

  if(this.globalVar.isOrderRedeem ||(this.inputSchemeObj.ShortTxnType == 'R' && this.globalVar.isOrderEdit)){
    this.availableUnit = parseFloat(this.inputSchemeObj.AvailableUnits);
    this.redMinQty = this.inputSchemeObj.minRedQty
    this.redAmountMin = this.inputSchemeObj.RedemptionAmountMinimum;
    this.redAmountMax = this.inputSchemeObj.RedemptionAmountMaximum;
    this.redAmountMul = this.inputSchemeObj.RedemptionAmountMultiple;
    this.redMulQty = this.inputSchemeObj.RedQtyMul;
    this.availableAmount = this.inputSchemeObj.NAVValue * this.availableUnit
    if(this.inputSchemeObj.Mode == 'DEMAT' ||  this.inputSchemeObj.Mode == 'demat'){
      this.disableisAllUnitFlag = true
    }
  }

  // this.setOption();
  this.getBankDetails();



    this.minAmount =  this.inputSchemeObj.MinPurAmt;
    // this.tag = this.navParams.get("tag");
    // this.tag = this.navParams.get("tag");
    this.clientFolioData = [];
  }


  setOption(){

    switch (this.SchemeDetail.DivReFlag.toUpperCase().trim()) {
      case "N":
      this.option = "Div. PayOut";
      break;

      case "Y":
      this.option = "Div. Reinvest";
      break;

      case "Z":
      this.option = "Growth";
      break;

      default:
      this.option = "NA";
    }
  }

  getBankDetails() {
    let inputBankObj = {
      ReportName: "GetBanks",
      UserId: this.globalVar.getUserId(),
      ResponseType: 2
    };
    this.common.showLoading();
    this.placeorderManager.getBankDetails(inputBankObj).then((data) => {
      this.getBankDetails_result = data;
      this.common.hideLoading();
      if (this.getBankDetails_result.ErrorCode == '0') {
        let Data = this.getBankDetails_result.ReportTable;
        if (Data.length > 0) {
          for (var i = 0; i < Data.length; i++) {
            Data[i].DisplayText = Data[i].BankName + " : " + Data[i].vcAccountNo;
            Data[i].FieldText = "|||NETBANKING|" + Data[i].vcAccountNo + "|" + Data[i].vcIFSC + "|" + Data[i].vcDefinedCode + "|" + Data[i].BankMode;
          }
          var bankDetailData = Data;
           var uniqueBankAcc = [];
          for(let x = 0; x< bankDetailData.length; x++) {
            if(uniqueBankAcc.indexOf(bankDetailData[x].vcAccountNo) === -1){
              uniqueBankAcc.push(bankDetailData[x].vcAccountNo);
              this.BankDetail.push(bankDetailData[x]);
            }

            if(this.BankDetail[x].bolisDefault){
                this.Bank = this.BankDetail[x]
            }

          }
        }
      }
      else {
        swal({
          title: "OOPS!",
          text: this.getBankDetails_result.Message,
          type: "error"
        });
      }
    }, err => {
      console.log("err" + err)
      swal({
        title: 'OOPS!',
        text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
        type: "error"
      });
      this.common.hideLoading();
    });

  }

  getClientFolio(){
  let reportDetail = {
    ClientCode: this.globalVar.clientId,
    SchemeCode: this.inputSchemeObj.schcode,
    ISIN: this.inputSchemeObj.ISIN,
    ReportName: "ClientFolio",
    ResponseType: "2",
  }
  // this.SchemeDetail.SchemeCode
  this.placeorderManager.getBSEStarMFServicesDownloadReport(reportDetail).then((data) => {
    this.clientFolio_result = data;
    if(this.clientFolio_result.ErrorCode == 0){
      this.clientFolioData = this.clientFolio_result.ReportTable[0]
      console.log("this.clientFolio_result" + JSON.stringify(this.clientFolio_result));
    }
  })
}

onAmountChange(){
  // this.SchemeObj.Amount = this.inputSchemeObj.Amount;
  if(this.Amount != 0){
    this.isInitialAmountZero = false;
    this.getSchemeDetailByISIN();
  }
}

getSchemeDetailByISIN(){

  this.SchemeObj = {
    ReportName: "SchemeFromISIN",
    ISIN: this.inputSchemeObj.ISIN,
    Amount: this.Amount,
    SchemePlan: "Normal",
    RequestedBy: this.globalVar.getClientId(),
    TxnType: this.tag, // "FP" changed on 3 jan
    ResponseType: "2",
    Mode: this.TransactionMode.value,
    FolioNo: ''
  }

  if(this.tag == 'AP'){
    this.SchemeObj.Amount = this.inputSchemeObj.Amount;
    this.Amount = this.inputSchemeObj.Amount;
  } else{
      if(this.isInitialAmountZero){
        this.SchemeObj.Amount = "0";
      } else{
          this.SchemeObj.Amount = this.Amount;
      }
  }

  this.placeorderManager.getSchemeDetailByISIN(this.SchemeObj).then((data) => {
    this.getSchemeDetailByISIN_result = data;
    console.log("DataApi>>>>>",data)
    if(!this.globalVar.isOrderEdit){
      this.common.hideLoading();
    }
    if (this.getSchemeDetailByISIN_result.ErrorCode == '0') {
      if(this.getSchemeDetailByISIN_result.ReportTable[0] != [] && this.getSchemeDetailByISIN_result.ReportTable[0].length != 0){
        let Data = JSON.parse(JSON.stringify(this.getSchemeDetailByISIN_result.ReportTable[0]));
        this.SchemeDetail = Data;
        this.setOption();
        this.SchemeCodeFromISINDetail = this.SchemeDetail.SchemeCode;
        this.minAmount =  this.SchemeDetail.MinPurAmt;
        console.log("SchemeDetail", this.SchemeDetail);
        // if(!this.isSwitchType){
        //   this.toggle();
        // }
      }
    }
    else {
      if(!this.globalVar.isOrderEdit){
        this.common.showAlert(this.getSchemeDetailByISIN_result.Message);
        // this.navCtrl.pop()
      }
    }
  }, err => {
    // console.log("err" + err)
    swal({
      title: 'OOPS!',
      text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
      type: "error"
    });
    this.common.hideLoading();
  });

}




toggle() {

  if (this.SchemeDetail == undefined) {
    this.common.showAlert('Please enter Amount first !');
    return false;
  }
  this.show = !this.show;

  // CHANGE THE NAME OF THE BUTTON.

  if (this.show) {
    this.buttonName = "Hide Detail";
    this.ShowHideClass = "remove-circle";
  }
  else {
    this.buttonName = "Show Detail";
    this.ShowHideClass = "add-circle";
  }
}


redeemOrder(){
  if(this.isTermsAndConditionChecked.checkedData){
    this.isAddToCart = false;
    this.isSwitchScheme = false;
    if(this.common.allowedOrderType != 3){
      this.orderType = this.common.allowedOrderTypeList[0].value;
    }
    this.placeFreshOrder();
  }
  else{
    swal(
      "Notice",
      "Please accept the terms and conditions",
      'error'
    );
  }
}

addToCart(){
if(this.isTermsAndConditionChecked.checkedData){
  this.isAddToCart = true;
  this.isSwitchScheme = false;
  this.placeFreshOrder();
}
else{
  swal(
    "Notice",
    "Please accept the terms and conditions",
    'error'
  );
}
}

placeOrder(){
  console.log("placeOrder is checked" + this.isTermsAndConditionChecked.checkedData);
  if(this.isTermsAndConditionChecked.checkedData){
  this.isAddToCart = false;
  this.isSwitchScheme = false;
  this.placeFreshOrder();
}
  else{
    swal(
      "Notice",
      "Please accept the terms and conditions",
      'error'
    );
  }
}

placeFreshOrder(){
  var objOrder: any;

  objOrder = {
    Amount: this.Amount,
    BrokerRefNo: '',
    Brokerage: 0,
    CheckHoldings: 'Y',
    ClientCode: this.globalVar.getClientId(),
    CloseAccountFlag: 'N',
    DPC: (this.TransactionMode.value.toUpperCase() == "DEMAT") ? "Y" : "N",
    EUINFlag: 'N',
    EUINNumber: '',
    EndDate: '',
    ExchangeReferneceNo: '',
    FolioNo: this.folioNumber,
    GenrateToday: '',
    ISININo: this.inputSchemeObj.ISIN,
    IsSpread: 'N',
    KYCFlag: 1,
    LimitValidation: 'Y',
    MFIMFD: this.orderType.value,
    MandateID: '',
    MinRedeemFlag: '',
    Mode: '',
    ModelPortFolioName: this.inputSchemeObj.MFBSEModelPortfolioName,
    OrderSource: 'Mobile',
    OrderType: '',
    PhysicalFlag: (this.TransactionMode.value.toUpperCase() == "DEMAT") ? "D" :  (this.TransactionMode.value.toUpperCase() == "PHYSICAL") ? "P" : '',
    RedeemAmount: 0,
    RedeemDate: '',
    ReinvestmentFlag: 'Z',
    RequestedBy: this.globalVar.getClientId(),
    SIPFrequency: '',
    SchemeCode:'',
    SessionID: this.globalVar.getSessionNo(),
    StartDate: '',
    StartDay: 0,
    SwitchSchemeISIN: '',
    SwitchSchemeSchemeCode: '',
    TXNID: '0',
    Tenure: '',
    Token: this.SchemeDetail.Token,
    TxnType: '',
    Units: '0',
    ValidateMargin: 'N',
    inBatchID: 0,
    inSubBatchID: 0,
    vcRemarks: '',
    // Status : '-1'
  };


  if(this.common.allowedOrderType != 3 &&  this.common.allowedOrderType != 0){
    objOrder.MFIMFD = this.common.allowedOrderTypeList[0].value
  } else if(this.common.allowedOrderType == 3){
    objOrder.MFIMFD = this.orderType.value;
  }

  if(this.globalVar.isOrderFromHolding){
      objOrder.FolioNo =  this.inputSchemeObj.FolioNo
      this.folioNumber =  this.inputSchemeObj.FolioNo
      objOrder.Mode = this.inputSchemeObj.Mode;
      if(this.inputSchemeObj.Mode == 'DEMAT'){
        objOrder.DPC = 'Y',
        objOrder.PhysicalFlag = 'D'
      }else{
        objOrder.DPC = 'N',
        objOrder.PhysicalFlag = 'P'
      }

      if(this.isAllUnitFlag){
        objOrder.CloseAccountFlag = 'Y'
        objOrder.Amount = 0;
        objOrder.Units = 0;

      }

      if(this.globalVar.isOrderRedeem && this.common.allowedOrderType !=3){
        this.orderType = this.common.allowedOrderTypeList[0];
      }
  }

  var gFOT = "N";;

if (this.GFOT === true) {
    gFOT = "Y";

  } else if (this.GFOT === false) {
    gFOT = "N";
  }


  if (this.validateOrder() == true) {

    if (this.tag.toUpperCase().trim() == "R") {
      if(!this.isAllUnitFlag){
      if(this.redemptionTypeVal.value == "amount"){
          objOrder.Amount = this.Amount;
          objOrder.Units = '0';

      } else if(this.redemptionTypeVal.value == "unit"){
           objOrder.Amount = 0;
           objOrder.Units = this.requestedRedeemUnit;
      }
    } else if(this.isAllUnitFlag && this.inputSchemeObj.Mode == 'PHYICAL'){
      // redMinQty is min availble unit

      if(this.requestedRedeemUnit < parseFloat(this.redMinQty)){
        objOrder.MinRedeemFlag = "Y"
      }
      else{
          objOrder.MinRedeemFlag = "N"
      }
      objOrder.CloseAccountFlag = "Y"
      objOrder.Amount = 0;
      objOrder.Units = 0;
    }

      objOrder.TxnType = this.tag.toUpperCase().trim()
      objOrder.MandateID = ''
      objOrder.StartDate = ''
      objOrder.StartDay = 0
      objOrder.EndDate = ''
      objOrder.SIPFrequency = ''
      objOrder.GenrateToday = ''
      objOrder.SwitchSchemeISIN =''
      objOrder.SwitchSchemeSchemeCode = ''
      objOrder.SchemeCode = this.SchemeCodeFromISINDetail
      objOrder.BrokerRefNo = ''
    }

    if (this.tag.toUpperCase().trim() == "FP" || this.tag.toUpperCase().trim() == "AP" ) {
      objOrder.Amount = this.Amount
      objOrder.TxnType = this.tag.toUpperCase().trim()
      objOrder.MandateID = ''
      objOrder.StartDate = ''
      objOrder.StartDay = 0
      objOrder.EndDate = ''
      objOrder.SIPFrequency = ''
      objOrder.GenrateToday = ''
      objOrder.SwitchSchemeISIN =''
      objOrder.SwitchSchemeSchemeCode = ''
      objOrder.SchemeCode = this.SchemeCodeFromISINDetail
      objOrder.BrokerRefNo = "|||NETBANKING|" + this.Bank.vcAccountNo + "|" + this.Bank.vcIFSC + "|" + this.Bank.vcDefinedCode + "|" + this.Bank.BankMode
    }

    else if (this.tag.toUpperCase().trim() == "SIP") {
      objOrder.Amount = this.Amount
      objOrder.TxnType = this.tag.toUpperCase().trim()
      objOrder.MandateID = ''
      objOrder.StartDate = this.getStartDate(this.selectedSIPDate.Vailddates)
      objOrder.StartDay =  this.getStartDay(this.selectedSIPDate.Vailddates)
      objOrder.EndDate =  this.getEndDate(this.selectedSIPDate.Vailddates, this.selectedTenure.value)
      objOrder.SIPFrequency = this.selectedFrequency.SIPFrequency,
      objOrder.GenrateToday =gFOT,
      objOrder.Tenure = this.selectedTenure.value,
      // objOrder.GenrateToday = this.GFOT == undefined ? "N" : this.GFOT,
      objOrder.SwitchSchemeISIN =''
      objOrder.SwitchSchemeSchemeCode = ''
      objOrder.SchemeCode =  this.inputSchemeObj.SchemeCode
      objOrder.BrokerRefNo = "|||NETBANKING|" + this.Bank.vcAccountNo + "|" + this.Bank.vcIFSC + "|" + this.Bank.vcDefinedCode + "|" + this.Bank.BankMode

    }
     else if (this.tag.toUpperCase().trim() == "XSIP") {
      objOrder.Amount = this.Amount
      objOrder.TxnType = this.tag.toUpperCase().trim()
      objOrder.MandateID = this.selectedMadnateID.MandateId
      objOrder.StartDate = this.getStartDate(this.selectedSIPDate.Vailddates)
      objOrder.StartDay = this.getStartDay(this.selectedSIPDate.Vailddates)
      objOrder.EndDate =  this.getEndDate(this.selectedSIPDate.Vailddates, this.selectedTenure.value)
      objOrder.SIPFrequency = this.selectedFrequency.SIPFrequency,
      objOrder.GenrateToday =gFOT,
      objOrder.Tenure = this.selectedTenure.value,
      objOrder.BrokerRefNo = this.Bank.FieldText,
      objOrder.SwitchSchemeISIN ='',
      objOrder.SwitchSchemeSchemeCode = ''
      objOrder.SchemeCode =  this.inputSchemeObj.SchemeCode

    } else if (this.tag.toUpperCase().trim() == "ISIP") {
      objOrder.Amount = this.Amount
      objOrder.TxnType = this.tag.toUpperCase().trim()
      objOrder.MandateID = this.selectedMadnateID.MandateId
      objOrder.StartDate = this.getStartDate(this.selectedSIPDate.Vailddates)
      objOrder.StartDay =  this.getStartDay(this.selectedSIPDate.Vailddates)
      objOrder.EndDate =  this.getEndDate(this.selectedSIPDate.Vailddates, this.selectedTenure.value),
      objOrder.SIPFrequency = this.selectedFrequency.SIPFrequency,
      objOrder.GenrateToday =gFOT,
      objOrder.Tenure = this.selectedTenure.value,
      objOrder.BrokerRefNo = this.Bank.FieldText
      objOrder.SwitchSchemeISIN =''
      objOrder.SwitchSchemeSchemeCode = ''
      objOrder.SchemeCode =  this.inputSchemeObj.SchemeCode


    } else if (this.tag.toUpperCase().trim() == "SWITCH") {

      if(this.switchTypeVal.value == "amount"){
          objOrder.Amount = this.Amount;
          objOrder.Units = '0';

      } else if(this.switchTypeVal.value == "unit"){
           objOrder.Amount = 0;
           objOrder.Units = this.Amount;
      }

      objOrder.TxnType = this.tag.toUpperCase().trim()
      objOrder.MandateID = ''
      objOrder.StartDate = ''
      objOrder.StartDay =  ''
      objOrder.EndDate =  ''
      objOrder.SIPFrequency = ''
      objOrder.GenrateToday ='',
      objOrder.BrokerRefNo = ''
      objOrder.BrokerRefNo = ''
      objOrder.SwitchSchemeISIN = this.selectedNewScheme.ISIN,
      objOrder.SwitchSchemeSchemeCode = this.selectedNewScheme.SchemeCode
    }



  if(this.isAddToCart){
    objOrder.OrderType = 'CART'
  } else {
    objOrder.OrderType = 'Fresh'
  }

  // this.isAddToCart = false;
  this.common.showLoading();

  this.placeorderManager.PlaceOrder(objOrder).then((data) => {
    this.placeOrder_result = data;
    this.common.hideLoading();
    if (this.placeOrder_result.ErrorCode == '0' || this.placeOrder_result.ErrorCode == '100') {
      swal(
        "Order No : " + this.placeOrder_result.OrderNumber,
        this.placeOrder_result.ErrorMessage,
        'success'
      );

      if(this.tag.toUpperCase().trim() == 'AP' || this.tag.toUpperCase().trim() == 'FP' || this.tag.toUpperCase().trim() == 'R'){
        this.navCtrl.push('OrderBookPage').then(() => {
              let index = 1;
              this.navCtrl.remove(index);
            });
      } else{
        this.navCtrl.push('SipOrderbookPage').then(() => {
              let index = 1;
              this.navCtrl.remove(index);
            });
      }

    }

    else if (this.placeOrder_result.ErrorCode == '200') {
      swal(
        "Order No : " + this.placeOrder_result.OrderNumber,
        this.placeOrder_result.ErrorMessage,
        'success'
      );
      this.common.getCartCount();
      this.navCtrl.push('PlaceorderSuggestionPage').then(() => {
            let index = 1;
            this.navCtrl.remove(index);
          });
    }

    else if (this.placeOrder_result.ErrorCode == '-1000167') {
      this.common.logOutFromSessionOut();
    }
    else {
      swal({
        title: "OOPS!",
        text: this.placeOrder_result.ErrorMessage,
        type: "error"
      });
    }
  }, err => {
    console.log("err" + err)
    swal({
      title: 'OOPS!',
      text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
      type: "error"
    });
    this.common.hideLoading();
  });
}
}


validateOrder() {


  if(this.globalVar.isOrderEdit && this.inputSchemeObj.ShortTxnType != 'R'){
    if(this.EditAmount < this.minAmount){
      this.common.showAlert('Amount must be above '+ this.minAmount);
      return;
    }

  }


  if(this.common.allowedOrderType == 0){
    this.common.showAlert('Client does not have any permission to place MFI/MFD order.');
    return false;
  } else if(this.common.allowedOrderType == 3 && this.orderType.value == '' ){
    this.common.showAlert('Please selected order type');
    return false;
  }

  if(this.common.allowedTransactionMode == 0){
    this.common.showAlert('Client does not have any permission to place Physical/Demat order.');
    return false;
  } else if(this.common.allowedTransactionMode == 3 && this.TransactionMode.value == '' ){
    this.common.showAlert('Please select transaction mode');
    return false;
  }

  switch (this.tag.toUpperCase().trim()) {
    case 'R':
    if(this.globalVar.isOrderEdit){
      this.isAllUnitFlag = false;
      if(parseFloat(this.inputSchemeObj.Amount).toFixed(2) == "0.00"){
        this.requestedRedeemUnit = this.EditAmount;
        this.redemptionTypeVal.value = 'unit';
      } else if(parseFloat(this.inputSchemeObj.Units).toFixed(2)== "0.00"){
          this.Amount = this.EditAmount;
          this.redemptionTypeVal.value = 'amount';

      }

      this.availableUnit = parseFloat(this.clientFolioData.ALLOTEDUNIT) + parseFloat(this.requestedRedeemUnit);

      this.redMinQty = this.schemeDetailFromApi.MinRedQty
      this.redAmountMin = this.schemeDetailFromApi.RedemptionAmountMinimum;
      this.redAmountMax = this.schemeDetailFromApi.RedemptionAmountMaximum;
      this.redAmountMul = this.schemeDetailFromApi.RedemptionAmountMultiple;
      this.redMulQty = this.schemeDetailFromApi.RedQtyMul;
      this.availableAmount = this.schemeDetailFromApi.NAVValue * this.availableUnit
    }

    if(this.availableUnit > 0){
      this.availableAmount = this.inputSchemeObj.NAVValue * this.availableUnit

      if(this.Amount != '' && this.redemptionTypeVal.value == 'amount'){
          if (parseFloat(this.Amount) > 0) {
            if (parseFloat(this.Amount) < parseFloat(this.redAmountMin)) {
                this.common.showAlert('Amount should be greater than or equal to minimum amount.');
                return false;
            }
            else if (this.Amount > this.availableAmount) {
              this.common.showAlert('Transaction Amount can not be greater than available amount');
              return false;
            }
            else if ((parseFloat(this.Amount) % parseFloat(this.redAmountMul)).toFixed(2) != "0.00") {

                this.common.showAlert('Amount should be in multiple of ' + this.redAmountMul);
                return false;
            }
          }

      }



      if(this.requestedRedeemUnit != '' && this.redemptionTypeVal.value == 'unit'){

        if (parseFloat(this.requestedRedeemUnit) > parseFloat(this.availableUnit)) {
          this.common.showAlert('Units should be less than or equal to available Units.');
          return false;
        }

        else if (parseFloat(this.requestedRedeemUnit) < parseFloat(this.redMinQty)) {
          this.common.showAlert('Units should be greater or equal to minimum Units.');
          return false;
        }
        if (parseFloat(this.redMulQty).toFixed(2) != "0.00") {
            if ((parseFloat(this.requestedRedeemUnit) % parseFloat(this.redMulQty)).toFixed(2) != "0.00") {
                this.common.showAlert('Units should be in multiple of ' + this.redMulQty);
                return false;
            }
        }


      }

      else if(this.Amount == '' && this.redemptionTypeVal.value == 'amount' && !this.isAllUnitFlag){
        this.common.showAlert('Please enter amount.');
        return false;
      }

      else if(this.requestedRedeemUnit == '' && this.redemptionTypeVal.value == 'unit' && ! this.isAllUnitFlag){
        this.common.showAlert('Please enter units.');
        return false;
      }

    }
    else{
      this.common.showAlert('Available Units is Zero');
      return false;
    }

    break;
    //START FROM HERE
    case 'SWITCH':
    var AvailAmnt = 1000;

    var boolAllUnits = false;
     if (!boolAllUnits) {
         if (this.switchTypeVal.value == "amount") {
             if (this.Amount != "") {
                 if (parseFloat(this.Amount) <  parseFloat(this.schemeDetailFromApi.MinPurAmt)) {
                     this.common.showAlert('Amount should be greater than or equal to minimum amount.');
                       return false;
                 }
                 else if (parseFloat(this.Amount) > AvailAmnt) {
                     this.common.showAlert('Transaction Amount can not be greater than available amount');
                      return false;
                 }
             }
             else {
                 this.common.showAlert('Please enter amount.');
                   return false;
             }
         }
         else if (this.switchTypeVal.value == "unit") {
             if (this.Amount != "") {
                 var _calAmount = parseFloat(this.Amount) * parseFloat(this.schemeDetailFromApi.NAVValue);
                 if (_calAmount < parseFloat(this.schemeDetailFromApi.MinPurAmt)) {
                    this.common.showAlert('Amount should be greater than or equal to minimum amount.');
                      return false;
                 }
                 else if (this.Amount > this.schemeDetailFromApi.AllotedUnit) {
                     this.common.showAlert('Transaction unit can not be greater than available units');
                      return false;
                 }
             }
             else {
                 this.common.showAlert('Please enter units.');
                 return false;
             }
         }
     } else  return false;

    break;


    case "FP":

    if (this.option == "" || this.option == "NA" || this.option == undefined) {
      this.common.showAlert('Option can not be blank !');
      return false;
    }

    if (this.Amount == "" || this.Amount == undefined) {
      this.common.showAlert('Amount can not be blank !');
      return false;
    }

    if (parseInt(this.Amount) == 0) {
      this.common.showAlert('Amount can not be zero !');
      return false;
    }

    if (this.Bank == null || this.Bank == undefined) {
      this.common.showAlert('Please select bank !');
      return false;
    }

    break;

    case "AP":

    if (this.folioNumber == "" || this.folioNumber == undefined) {
      this.common.showAlert('Please enter folio number !');
      return false;
    }

    if (this.Bank == null || this.Bank == undefined) {
      this.common.showAlert('Please select bank !');
      return false;
    }
    break;


    case "SIP":

    if (this.option == "" || this.option == "NA" || this.option == undefined) {
      this.common.showAlert('Option can not be blank !');
      return false;
    }

    if (this.selectedFrequency == null || this.selectedFrequency == undefined) {
      this.common.showAlert('Please select frequency !');
      return false;
    }

    if (this.selectedSIPDate == null || this.selectedSIPDate == undefined) {
      this.common.showAlert('Please select start date !');
      return false;
    }

    if (this.selectedTenure == null || this.selectedTenure == undefined) {
      this.common.showAlert('Please select tenure !');
      return false;
    }

    if (this.Amount == "" || this.Amount == undefined) {
      this.common.showAlert('Amount can not be blank !');
      return false;
    }

    if (parseInt(this.Amount) == 0) {
      this.common.showAlert('Amount can not be zero !');
      return false;
    }

    // if(this.orderType.value == null || this.orderType.value == '' || this.orderType.value == undefined){
    //   this.common.showAlert('Client does not have any permission to place MFI/MFD order.');
    //   return false;
    // }

    let minimumSIPAmount = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMinimumInstallmentAmount);
    let maximumSIPAmount = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMaximumInstallmentAmount);
    let SIPMultiplier = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMultiplierAmount);

    if (parseFloat(this.Amount) < minimumSIPAmount) {
      this.common.showAlert('Amount can not be less than minimum SIP Amount Rs :' + minimumSIPAmount);
      return false;
    }

    if (parseFloat(this.Amount) > maximumSIPAmount) {
      this.common.showAlert('Amount can not be greater than minimum SIP Amount Rs :' + maximumSIPAmount);
      return false;
    }

    if (SIPMultiplier != 0) {
      if (parseFloat(this.Amount) % SIPMultiplier != 0) {
        this.common.showAlert('Amount should be multiple of Rs :' + SIPMultiplier);
        return false;
      }
    }

    if (this.Bank == null || this.Bank == undefined) {
      this.common.showAlert('Please select bank !');
      return false;
    }
    break;

    case "XSIP":

    // if (this.TransactionMode.value == "" || this.TransactionMode.value == undefined) {
    //   this.common.showAlert('Please select transaction mode !');
    //   return false;
    // }

    if (this.option == "" || this.option == "NA" || this.option == undefined) {
      this.common.showAlert('Option can not be blank !');
      return false;
    }

    if (this.selectedFrequency == null || this.selectedFrequency == undefined) {
      this.common.showAlert('Please select frequency !');
      return false;
    }

    if (this.selectedSIPDate == null || this.selectedSIPDate == undefined) {
      this.common.showAlert('Please select start date !');
      return false;
    }

    if (this.selectedTenure == null || this.selectedTenure == undefined) {
      this.common.showAlert('Please select tenure !');
      return false;
    }

    if (this.Bank == null || this.Bank == undefined) {
      this.common.showAlert('Please select bank !');
      return false;
    }

    if (this.selectedMadnateID == undefined || this.selectedMadnateID == null){
      this.common.showAlert('Please select mandate id !');
      return false;
    }
    else{
      if(this.selectedMadnateID.MandateId == null || this.selectedMadnateID.MandateId == undefined) {
        this.common.showAlert('Please select mandate id !');
        return false;
    }
  }



    if (this.Amount == "" || this.Amount == undefined) {
      this.common.showAlert('Amount can not be blank !');
      return false;
    }

    if (parseInt(this.Amount) == 0) {
      this.common.showAlert('Amount can not be zero !');
      return false;
    }

    // if(this.orderType.value == null || this.orderType.value == '' || this.orderType.value == undefined){
    //   this.common.showAlert('Client does not have any permission to place MFI/MFD order.');
    //   return false;
    // }

    let minimumXSIPAmount = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMinimumInstallmentAmount);
    let maximumXSIPAmount = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMaximumInstallmentAmount);
    let XSIPMultiplier = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMultiplierAmount);

    if (parseFloat(this.Amount) < minimumXSIPAmount) {
      this.common.showAlert('Amount can not be less than minimum XSIP Amount Rs :' + minimumXSIPAmount);
      return false;
    }

    if (parseFloat(this.Amount) > maximumXSIPAmount) {
      this.common.showAlert('Amount can not be greater than minimum XSIP Amount Rs :' + maximumXSIPAmount);
      return false;
    }

    if (XSIPMultiplier != 0) {
      if (parseFloat(this.Amount) % XSIPMultiplier != 0) {
        this.common.showAlert('Amount should be multiple of  Rs :' + XSIPMultiplier);
        return false;
      }
    }
    break;

    case "ISIP":
    // if (this.TransactionMode.value == "" || this.TransactionMode.value == undefined) {
    //   this.common.showAlert('Please select transaction mode !');
    //   return false;
    // }

    if (this.option == "" || this.option == "NA" || this.option == undefined) {
      this.common.showAlert('Option can not be blank !');
      return false;
    }

    if (this.selectedFrequency == null || this.selectedFrequency == undefined) {
      this.common.showAlert('Please select frequency !');
      return false;
    }

    if (this.selectedSIPDate == null || this.selectedSIPDate == undefined) {
      this.common.showAlert('Please select start date !');
      return false;
    }

    if (this.selectedTenure == null || this.selectedTenure == undefined) {
      this.common.showAlert('Please select tenure !');
      return false;
    }

    if (this.Bank == null || this.Bank == undefined) {
      this.common.showAlert('Please select bank !');
      return false;
    }

    if (this.selectedMadnateID == undefined || this.selectedMadnateID == null){
      this.common.showAlert('Please select mandate id !');
      return false;
    }
    else{
      if(this.selectedMadnateID.MandateId == null || this.selectedMadnateID.MandateId == undefined) {
        this.common.showAlert('Please select mandate id !');
        return false;
    }
  }


    // if (this.selectedMadnateID.MandateId == null || this.selectedMadnateID.MandateId == undefined || this.selectedMadnateID == undefined) {
    //   this.common.showAlert('Please select mandate id !');
    //   return false;
    //
    // }

    if (this.Amount == "" || this.Amount == undefined) {
      this.common.showAlert('Amount can not be blank !');
      return false;
    }

    if (parseInt(this.Amount) == 0) {
      this.common.showAlert('Amount can not be zero !');
      return false;
    }

    let minimumISIPAmount = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMinimumInstallmentAmount);
    let maximumISIPAmount = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMaximumInstallmentAmount);
    let ISIPMultiplier = parseFloat(this.SIPXSIPISIPConfigDetail.SIPMultiplierAmount);
    if (parseFloat(this.Amount) < minimumISIPAmount) {
      this.common.showAlert('Amount can not be less than minimum ISIP Amount Rs :' + minimumISIPAmount);
      return false;
    }

    if (parseFloat(this.Amount) > maximumISIPAmount) {
      this.common.showAlert('Amount can not be greater than minimum ISIP Amount Rs :' + maximumISIPAmount);
      return false;
    }

    if (parseFloat(this.Amount) > maximumISIPAmount) {
      this.common.showAlert('Amount can not be greater than minimum ISIP Amount Rs :' + maximumISIPAmount);
      return false;
    }
    if (ISIPMultiplier != 0) {
      if (parseFloat(this.Amount) % ISIPMultiplier != 0) {
        this.common.showAlert('Amount should be multiple of  Rs :' + ISIPMultiplier);
        return false;
      }
    }

    break;
  }
  return true;
}


getFrequency() {
  let inputFrequencyObj = {
    ReportName: "SIPFrequency",
    AmcCode: this.inputSchemeObj.AMCCode,
    SchemeCode: this.inputSchemeObj.SchemeCode,
    ISIN: this.inputSchemeObj.ISIN,
    ResponseType: 2,
    TxnType: this.tag
  };
  this.common.showLoading();
  this.placeorderManager.getBSEStarMFServicesDownloadReport(inputFrequencyObj).then((data) => {
    this.getFrequency_result = data;
    this.common.hideLoading();
    if (this.getFrequency_result.ErrorCode == '0') {
      let Data = this.getFrequency_result.ReportTable;
      this.Frequency = Data;
      console.log("Frequency", this.Frequency);
    }
    else if(this.getFrequency_result.ErrorCode == '-1000020'){
      swal({
        title: "OOPS!",
        text: this.getFrequency_result.Message,
        type: "error"
      });
      // this.globalVar.setPreviousPage({ PreviousPage: 'FPOrderForm'});
      // this.globalVar.isLastPagePlaceOrder = false;
      this.globalVar.isLastPageFPOrderForm = true;
      // this.navCtrl.push('InvestmentSuggestionDetailsPage');
    }
    else {
      swal({
        title: "OOPS!",
        text: this.getFrequency_result.Message,
        type: "error"
      });
    }
  }, err => {
    console.log("err" + err)
    swal({
      title: 'OOPS!',
      text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
      type: "error"
    });
    this.common.hideLoading();
  });

}


getSIPDates() {
  let gFOT;
  console.log("GFOT", this.GFOT)
  if (this.GFOT === undefined) {
    gFOT = "N";

  } else if (this.GFOT === true) {
    gFOT = "Y";

  } else if (this.GFOT === false) {
    gFOT = "N";
  }


  let inputFrequencyObj = {
    ReportName: "SIPDates",
    AmcCode: this.SchemeDetail.AMCCode,
    SchemeCode: this.SchemeDetail.SchemeCode,
    ISIN: this.inputSchemeObj.ISIN,
    TxnType: this.tag,
    GFOT: gFOT,
    Frequency: this.selectedFrequency.SIPFrequency,
    ResponseType: 2
  };
  this.common.showLoading();
  this.placeorderManager.getBSEStarMFServicesDownloadReport(inputFrequencyObj).then((data) => {
    this.getSIPDates_result = data;
    this.common.hideLoading();

    if (this.getSIPDates_result.ErrorCode == '0') {
      let Data = this.getSIPDates_result.ReportTable;
      this.SIPDates = Data;
      console.log("SIPDates", this.SIPDates);

    }
    else {
      swal({
        title: "OOPS!",
        text: this.getSIPDates_result.Message,
        type: "error"
      });
    }
  }, err => {
    console.log("err" + err)
    swal({
      title: 'OOPS!',
      text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
      type: "error"
    });
    this.common.hideLoading();
  });
  this.getSchemeDetailForSIP();
}

getTenure() {
  let start: number = parseInt(this.SIPXSIPISIPConfigDetail.SIPMinimumInstallmentNumbers);
  let end: number = parseInt(this.SIPXSIPISIPConfigDetail.SIPMaximumInstallmentNumbers);
  this.Tenure = [];
  for (var i = start; i < end + 1; i++) {
    this.Tenure.push({ value: i });
  }

}

getNewSchemeDetail(){

}


getSchemeDetailForSIP(){
  this.SchemeObj = {
    ReportName: "SIPFrequencyDates",
    AmcCode: this.inputSchemeObj.AMCCode,
    SchemeCode: this.inputSchemeObj.SchemeCode,
    ISIN: this.inputSchemeObj.ISIN,
    Frequency: this.selectedFrequency.SIPFrequency,
    ResponseType: 2,
  }

  this.common.showLoading();
  this.placeorderManager.getSchemeDetailByISIN((this.SchemeObj)).then((data) => {
    this.getSchemeDetailByISIN_result = data;

    this.common.hideLoading();
    if (this.getSchemeDetailByISIN_result.ErrorCode == '0') {
      let Data = JSON.parse(JSON.stringify(this.getSchemeDetailByISIN_result.ReportTable[0]));
      this.SIPXSIPISIPConfigDetail = Data;
      this.minAmount = this.SIPXSIPISIPConfigDetail.SIPMinimumInstallmentAmount;
      console.log("SIPXSIPISIPConfigDetail", this.SIPXSIPISIPConfigDetail);

      // this.SchemeDetail = Data;
      // this.minAmount = "( Min. Rs" + this.SchemeDetail.SIPMinimumInstallmentAmount + " )";
      // console.log("SchemeDetail", this.SchemeDetail);
      this.getTenure();
    }
    else {
      this.common.showAlert(this.getSchemeDetailByISIN_result.Message);
    }
  }, err => {
    console.log("err" + err)
    swal({
      title: 'OOPS!',
      text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
      type: "error"
    });
    this.common.hideLoading();
  });
}

freqencyChange(event: {
  component: IonicSelectableComponent,
  value: any
}) {
  this.getSIPDates();
}

getMandateIDs() {
  this.SchemeObj = {
    ReportName: "MandateId",
    ClientCode: this.globalVar.getClientId(),
    TxnType: this.tag,
    MandateMode: this.orderType.value,
    ResponseType: 2
  }

  this.common.showLoading();
  this.placeorderManager.getSchemeDetailByISIN((this.SchemeObj)).then((data) => {
    this.getMadateID_result = data;
    this.common.hideLoading();

    if (this.getMadateID_result.ErrorCode == '0') {
      let Data = this.getMadateID_result.ReportTable;

      if (Data.length > 0) {
        for (var i = 0; i < Data.length; i++) {
          Data[i].DisplayText = Data[i].MandateId;
          // Data[i].DisplayText = Data[i].MandateId + " - " + Data[i].MandateType;
        }
        this.MandateDetail = Data;
        console.log("MandateDetail", this.MandateDetail);
      }

    }
    else {
      this.common.showAlert(this.getMadateID_result.Message);
    }
  }, err => {
    console.log("err" + err)
    swal({
      title: 'OOPS!',
      text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
      type: "error"
    });
    this.common.hideLoading();
  });
}

getStartDay(strDate: string) {
  if (strDate != "") {
    let arr = strDate.split("/");
    return arr[0];
  }
  return "0";
}

getStartDate(strDate: string) {
  if (strDate != "") {
    let arr = strDate.split("/");
    return arr[2] + "-" + arr[1] + "-" + arr[0];
  }
  return "0";
}

getEndDate(strDate: string, tenure) {
  if (strDate != "") {
    let arr = strDate.split("/");
    let d = parseInt(arr[0]);
    let m = parseInt(arr[1]) - 1;
    let y = parseInt(arr[2]);
    let endDate = new Date(y, m, d);
    tenure = parseInt(tenure) + 1;
    endDate.setMonth(endDate.getMonth() + tenure);
    console.log("endDate", endDate);
    console.log("return endate", endDate.getDay() + "/" + endDate.getMonth() + "/" + endDate.getFullYear());
    return endDate.getFullYear() + "-" + endDate.getMonth() + "-" + endDate.getDate();

  }
  return "";
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad FolioOrderPage');
  }

}
