import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DpreleasereportPage } from './dpreleasereport';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [
    DpreleasereportPage,
  ],
  imports: [
    NgProgressModule,
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(DpreleasereportPage),
  ],
})
export class DpreleasereportPageModule {}
