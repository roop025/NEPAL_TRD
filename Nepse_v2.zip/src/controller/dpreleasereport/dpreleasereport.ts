import { Component } from '@angular/core';
import { NavController , IonicPage,NavParams} from 'ionic-angular';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';

import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';

@IonicPage()
@Component({
  selector: 'page-dpreleasereport',
  templateUrl: '../../pages/DionBlack/dpreleasereport/dpreleasereport.html'
})

export class DpreleasereportPage {

  public progressBarColor : any;
  public userData : any;
  public marginReport_result : any;
  public items : any;
  public message : any;
  public defaultSegmentAccount : any;
  public shownGroup : any;
  public groups : any;
  public ClientName : any;
  private logoutFrmData : any;
  private   user_logout_result: any = '';

  public holdData : any;
  public holdObj : {
      isin:'',
      dpid:'',
      segment:'',
      exhange:'',
      qunty:''
  };

  public dpid_list:any;
  public segmet_list:any;
  public exchange_list:any;
  public report_result:any;



  constructor(public navCtrl: NavController,
    public ngProgress: NgProgress,
    private globalVariableService : GlobalVariableService,
    public getReportManager : ReportProvider,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private storage:Storage,
    public navParams:NavParams
  ) {
    this.defaultSegmentAccount = {
      SelectedSegment: ''
    }
    this.groups = [];
    this.ClientName = globalVariableService.clientName;
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"MarginPage"});

    this.holdData = this.navParams.get('holdObj');
   // console.log(this.holdData['ISIN No']);
    this.holdObj ={isin:this.holdData['ISINCode'],dpid:this.holdData['DPID'],segment:this.holdData['SegmentAccount'],exhange:'',qunty:this.holdData['AvailableQty']};

  }

  ionViewDidLoad(){
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //this.getDPID();
    });
 
  }

  // Get Exchage Data  here

  submitRelease_Data(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    // console.log("this.holdObj dat --------->");
    //console.log(this.holdObj);
    this.getReportManager.dpRelease(this.userData.ClientCode,this.holdObj).then((data)=>{
      this.ngProgress.done();
       this.report_result = data;
      if(this.report_result.ErrorCode == 0 && this.report_result.ServiceResponse !=null){
        this.holdData = '';
        this.message=this.report_result.DatabaseResponse;
        var msg =this.report_result.Message;
        swal({
            title: msg,
            text: this.message,
            timer: 3000,
            type: "success"
        });
        // this.navCtrl.push('DpAllocationPage');
      }else{
        var msg =this.report_result.Message;
        swal({
          title: "Error!",
          text: msg,
          timer: 3000,
          showConfirmButton: false
      });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });
  }
 








  //---Toggling of scrip section--
    toggleGroup (group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
        } else {
            //this.getScripRate(group);
            this.shownGroup = group;
        }
    }
    isGroupShown(group) {
        return this.shownGroup === group;
    }
 
}
