import { Component,ViewChild } from '@angular/core';
import { NavController , IonicPage,NavParams ,ModalController,Navbar} from 'ionic-angular';
import { AddScripProvider } from '../../providers/add-scrip/add-scrip';
import swal from 'sweetalert2';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { Storage } from '@ionic/storage';
// import { OrderbyPipe } from '../../pipes/orderBy/orderBy';
import { NgProgress } from 'ngx-progressbar';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import { ReportProvider } from '../../providers/report/report';
@IonicPage()
@Component({
  selector: 'page-addScrip',
  templateUrl: '../../pages/DionWhite/add-scrip/add-scrip.html'
})

export class AddScripPage {
  @ViewChild(Navbar) navBar: Navbar;

  //public setName : any;
  public searchStr : any;
  public classE : any;
  public classCu : any;
  public classC : any;
  public Equity : any;
  public Commodity : any;
  public Currency : any;
  public CClick : any;
  public EClick : any;
  public CuClick : any;
  public scripList : any;
  public tmpscripList : any;
  public MonthOne : any;
  public MonthTwo : any;
  public MonthThree : any;
  public showFutureData : any;
  public showOptionData : any;
  public showSpreadData : any;
  public showSpotData : any;
  public isFandO : any;
  public user_search_result : any;
  public exchangeList : any;
  //public tempSearch : any;
  public showScripList : any;
  public shownGroup : any;
  public selectedScrip : any;
  public optionButton : any;
  public selectedOptionType : any;
  public selected : any;
  public shownExpiry : any;
  public selectedExpiry : any;
  public rangeData : any;
  public InstrumentType : any;
  public user_expiryDate_result : any;
  public scripSetExpiry : any;
  public selectedExpiryVal : any;
  public selectedDate : any;
  public user_expiryDate_result_option : any;
  public strikePriceList_result : any;
  public strikePriceList : any;
  public getSelectedSrip_result : any;
  public singleScrip : any;
  public watchListAddItem : any;
  public userData : any;
  public getSpecified_quote_result : any;
  public singleScrip_quote : any;
  public spreadType : any;
  public scripExistsinWL : any;
  public progressBarColor : any;
  public ClientName : any;
  public WatchlistName : any;
  public user_marketSave_result : any;
  //public order : any = 'ID';
  //public ascending : any = true;
  public scriptTickers : any;
    public disbled_add:boolean;
    public allowed_script:any;
    futureOptionFlag : any;
    public selectedExpObj:any;
    public currentComp:any = ''


  constructor(public navCtrl: NavController,
    private addScripManager:AddScripProvider,
    private clientMarketWatchList : GlobalVariableService,
    private storage:Storage,
    public navParams: NavParams,
    private marketWatchManager:MarketWatchProvider,
    public modalCtrl: ModalController,
    public ngProgress: NgProgress,
    public socket: WebsocketProvider,public get_report:ReportProvider
    // public navBar:Navbar
    ) {
    this.progressBarColor = 'white'
    this.searchStr ='';
    this.classE = "dark";
    this.classCu = "";
    this.classC = "";
    this.Equity = false;
    this.Commodity = true;
    this.Currency = true;
    this.EClick = '1'
    this.CuClick = '1'
    this.CClick = '1'
    this.showScripList = false
    //---CAlling of option button --
    this.optionButton = [{
            'Id': 1,
            'type': 'CE',
            'buttonName': 'CALL',
        },
        {
            'Id': 2,
            'type': 'PE',
            'buttonName': 'PUT',
        }
    ];
    
    //console.log("this.WatchlistName",this.WatchlistName)
    this.ClientName = clientMarketWatchList.clientName;
    let view = this.navCtrl.getActive();
    this.currentComp = view.component.name
    if(this.currentComp == 'BuyPage'){
        this.disbled_add = true
    }
console.log("view---------------------------->",view)
  }


 
  ionViewDidLoad(){
    this.rangeData = {min: 0,max: 0,value: 0,step: 0,selectedStrikePrice:''};




    
    this.selectedOptionType = this.optionButton[0].type;
    this.selected = 0;
    this.selectedDate = 0;
    this.singleScrip = {};
    //--range and expiry section default value --
    this.selectedExpiry = "1-MON";
    // this.rangeData = {min: 0,max: 0,value: 0,step: 0,selectedStrikePrice:''};
    this.watchListAddItem = this.clientMarketWatchList.getData();
    //---get the user login data --
    this.storage.get("userMaster").then((data)=>{
         this.userData = data;
        this.getUserServiceProperties(this.userData.ClientCode);
    });
    this.WatchlistName=this.navParams.get('currentMarketWatch');
this.disbled_add=this.navParams.get('disbled_add');

}

//   ionViewDidLoad(){
    ionViewDidEnter(){
    //console.log("test from login")
    //console.log("In add scrip page -->",this.clientMarketWatchList.getData())
    this.navBar.backButtonClick = (e:UIEvent)=>{
        // this.socket.send('DELETE^*')
        // this.navCtrl.push('MarketWatchPage');
        try {
            let page = this.navCtrl.getViews()
            if (page.length > 1){
            this.navCtrl.pop();
            }
          } catch(e){}
       }
       //--------------------------
//     this.selectedOptionType = this.optionButton[0].type;
//     this.selected = 0;
//     this.selectedDate = 0;
//     this.singleScrip = {};
//     //--range and expiry section default value --
//     this.selectedExpiry = "1-MON";
//     // this.rangeData = {min: 0,max: 0,value: 0,step: 0,selectedStrikePrice:''};
//     this.watchListAddItem = this.clientMarketWatchList.getData();
//     // console.log("In add scrip page -->",this.watchListAddItem.watchlistItems)
//     //---get the user login data --
//     this.storage.get("userMaster").then((data)=>{
//          this.userData = data;
//         // console.log("this.userData",this.userData)
//         this.getUserServiceProperties(this.userData.ClientCode);
//     });
//     this.WatchlistName=this.navParams.get('currentMarketWatch');
// this.disbled_add=this.navParams.get('disbled_add');
console.log(">>>>>>>>>>>>>>>>>>..",this.disbled_add);

  }






  
  //---Search input field function fired --
  onInput(event){
      if(event){
        this.selectedDate = 0;
        this.getSearchResults();
      }
  }
  //--more option button click --
  select(index) {
      this.selected = index;
      //console.log("this.selected",this.selected)
  }
  //---Go to market Depth --
  public goToMarketDepth(mrketDepthObj){
    mrketDepthObj = {
        "exchange":mrketDepthObj.Exchange,"ticker":this.getTicker(mrketDepthObj)
      }
        //---check if user is allowed exchange. if not, then give message and prevent Add to MW
    var ProductType =this.userData.ExchangeMarketSegmentList.split('^');
    var ExchangePermit = 0;
    //console.log("productType"+ JSON.stringify(ProductType));
    for (var i = 0; i < ProductType.length; i++) {
        if (ProductType[i].split('$')[0] == mrketDepthObj.exchange) {
            ExchangePermit = 1;
            break;
        }
    }
    //---If user is not allowed to add the scrip in the market watch since it is not mapped to the trading account list.
    if(ExchangePermit === 0) {
        swal({title: "Not Allowed",text: "Cannot open to Market Depth, Exchange " + mrketDepthObj.exchange + " is not mapped to the user.",allowOutsideClick: true,showConfirmButton: false,showCancelButton: true,cancelButtonText: "Close"});
        return false;
    }
  
    //---Set data here the corresponding value so that it can be get in the quoteHeader page--
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: mrketDepthObj });
    this.navCtrl.push('MarketDepthPage',{userMWDepthData:mrketDepthObj,clientUserData:this.userData,prev_page:'add_scrip'});



  }
  public buyItem(mrketDepthObj){
    mrketDepthObj = {
      "exchange":mrketDepthObj.Exchange,"ticker":this.getTicker(mrketDepthObj)
    }
    
        //---check if user is allowed exchange. if not, then give message and prevent Add to MW
        var ProductType =this.userData.ExchangeMarketSegmentList.split('^');
        var ExchangePermit = 0;
        //console.log("productType"+ JSON.stringify(ProductType));
        for (var i = 0; i < ProductType.length; i++) {
            if (ProductType[i].split('$')[0] == mrketDepthObj.exchange) {
                ExchangePermit = 1;
                break;
            }
        }
        //---If user is not allowed to add the scrip in the market watch since it is not mapped to the trading account list.
        if(ExchangePermit === 0) {
            swal({title: "Not Allowed",text: "Buy not allowed, Exchange " + mrketDepthObj.exchange + " is not mapped to the user.",allowOutsideClick: true,showConfirmButton: false,showCancelButton: true,cancelButtonText: "Close"});
            return false;
        }
    //---Set data here the corresponding value so that it can be get in the quoteHeader page--
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: mrketDepthObj });
    this.navCtrl.push('BuyPage',{userbuyData:mrketDepthObj,clientUserData:this.userData,selectedBTN:"B" });
  }
  public sellItem(mrketDepthObj){
    mrketDepthObj = {
      "exchange":mrketDepthObj.Exchange,"ticker":this.getTicker(mrketDepthObj)
    }
    
        //---check if user is allowed exchange. if not, then give message and prevent Add to MW
        var ProductType =this.userData.ExchangeMarketSegmentList.split('^');
        var ExchangePermit = 0;
        //console.log("productType"+ JSON.stringify(ProductType));
        for (var i = 0; i < ProductType.length; i++) {
            if (ProductType[i].split('$')[0] == mrketDepthObj.exchange) {
                ExchangePermit = 1;
                break;
            }
        }
        //---If user is not allowed to add the scrip in the market watch since it is not mapped to the trading account list.
        if(ExchangePermit === 0) {
            swal({title: "Not Allowed",text: "Sell not allowed, Exchange " + mrketDepthObj.exchange + " is not mapped to the user.",allowOutsideClick: true,showConfirmButton: false,showCancelButton: true,cancelButtonText: "Close"});
            return false;
        }
    //---Set data here the corresponding value so that it can be get in the quoteHeader page--
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: mrketDepthObj });
    // this.navCtrl.push('SellPage',{usersellData:mrketDepthObj,clientUserData:this.userData,selectedBTN:"S" });
    this.navCtrl.push('BuyPage',{usersellData:mrketDepthObj,clientUserData:this.userData,selectedBTN:"S" });
  }


  //     create ticker
  public getTicker(group){
    // var specifiedQuoteString;
    var ticker = '';
    if (this.showOptionData === true) {
        //To get LTP for option indices
        if (group.Indices == 0) {

            ticker = group.ID + '~O:' + this.selectedExpiry + ':' + this.selectedOptionType + ':' + this.rangeData.selectedStrikePrice;
        } else {
            ticker = group.Name + '~O:' + this.selectedExpiry + ':' + this.selectedOptionType + ':' + this.rangeData.selectedStrikePrice;
        }
    }else if(this.showFutureData === true){
      if (group.Indices == 0) {
        ticker = group.ID + '~F:' + this.selectedExpiry;

      } else {
        ticker = group.Name+ '~F:' + this.selectedExpiry;

      }
    }else {
        if (group.Indices == 0) {
            ticker = group.ID;
        } else {
            ticker = group.Name;
        }
    }
    return ticker;
  }

  //------------------------
  HideTabsE(){
        this.Equity = false;
        this.Commodity = true;
        this.Currency = true;
        this.classE = "dark";
        this.classCu = "";
        this.classC = "";
        this.getSearchResults();
    }
  HideTabsCu(){
      this.Equity = true;
      this.Commodity = true;
      this.Currency = false;
      this.classE = "";
      this.classCu = "dark";
      this.classC = "";
      this.getSearchResults();
  }
  HideTabsC(){
      this.Equity = true;
      this.Commodity = false;
      this.Currency = true;
      this.classE = "";
      this.classCu = "";
      this.classC = "dark";
      this.CClick = 1;
      this.getSearchResults();
  }

  clickedE(num){
    this.EClick=num;
    this.getSearchResults();
  }
  clickedCu(num){
    this.CuClick=num;
    this.getSearchResults();
  }
  clickedC(num){
    this.CClick=num;
    this.getSearchResults();
  }
  toggleExpiry(index) {
      // this.shownExpiry = expiry;
      this.selectedDate = index;
  }
  isExpiryShown(expiry) {
      return this.shownExpiry === expiry;
  }
  //----search crip function ---
  getSearchResults() {
      this.scripList = [];
      //this.scripList.deleteContents();
      this.tmpscripList = {};
      this.futureOptionFlag = 0;

      var exchangeCount = 0;
      this.exchangeList = [];

      this.MonthOne = "ExpiryButtonActive";
      this.MonthTwo = "ExpiryButton";
      this.MonthThree = "ExpiryButton";

      if(this.searchStr == undefined || this.searchStr.length < 2){
          return;
      }

      //set parameters, count of queries and exchange set
      if (this.Equity == false) {
          if (this.EClick == 1) {
              //Equity Cash
              exchangeCount = 3
              this.exchangeList = ['NEPSE','Sensitive'];
              this.isFandO = false;
              this.showFutureData = false;
              this.showOptionData = false;
              
          } else if (this.EClick == 2) {
              // Equity Future
              exchangeCount = 2
              this.exchangeList = ['FONSE', 'FOBSE'];
              this.isFandO = true;
              this.showFutureData = true;
              this.showOptionData = false;
              this.futureOptionFlag = 1;
          } else if (this.EClick == 3) {
              //Equity Options
              exchangeCount = 2
              this.exchangeList = ['FONSE', 'FOBSE'];
              this.isFandO = true;
              this.showFutureData = true;
              this.showOptionData = true;
              this.futureOptionFlag = 2;
          } else if (this.EClick == 4) {
              //Equity Options
              exchangeCount = 2
              this.exchangeList = ['FONSE', 'FOBSE'];
              this.isFandO = "spread";
              this.showFutureData = false;
              this.showSpreadData = true;
              this.showOptionData = false;
          }

      } else if (this.Commodity == false) {
          if (this.CClick == 1) {
              //Commodity Future
              exchangeCount = 3;
              this.exchangeList = ['MCX', 'NCDEX','COMNSE'];
              this.isFandO = true;
              this.showFutureData = true;
              //this.showOptionData = true;
              this.futureOptionFlag = 1;
              this.showOptionData = false;
          }

          if (this.CClick == 2) {
              //Commodity Option
              exchangeCount = 3;
              this.exchangeList = ['MCX','NCDEX','COMNSE'];
              this.isFandO = true;
              this.showFutureData = true;
              this.showSpreadData === false;
              this.futureOptionFlag = 2;
              this.showOptionData = true;
              //this.showOptionData = false;
          }
      } else if (this.Currency == false) {
          if (this.CuClick == 1) {
              //Currency Futures
              exchangeCount = 3;
              this.exchangeList = ['CDNSE', 'CDBSE', 'MCXSX'];
              this.isFandO = true;
              this.showFutureData = true;
              this.showSpreadData = false;
              this.showOptionData = false;
              this.futureOptionFlag = 1;
              this.showSpotData = false;
          }

          if (this.CuClick == 2) {
              //Currency Futures
              exchangeCount = 3
              this.exchangeList = ['CDNSE', 'CDBSE', 'MCXSX'];
              this.isFandO = true;
              this.showFutureData = true;
              this.showSpreadData = false;
              this.showOptionData = true;
              this.futureOptionFlag = 2;
              this.showSpotData = false;
          }

          if (this.CuClick == 3) {
              //Currency Futures
              exchangeCount = 3
              this.exchangeList = ['CDNSE', 'CDBSE', 'MCXSX'];
              this.isFandO = "spread";
              this.showFutureData = false;
              this.showSpreadData = true;
              this.showOptionData = false;
              this.showSpotData = false;
          }

          if (this.CuClick == 4) {
              //Currency Futures
              exchangeCount = 3
              this.exchangeList = ['CDNSE', 'CDBSE', 'MCXSX'];
              this.isFandO = true;
              this.showFutureData = false;
              this.showSpreadData = false;
              this.showOptionData = false;
              this.showSpotData = true;
          }
      }

      for (var i = 0; i < exchangeCount; i++) {
          this.progressBarColor = 'white'
          this.ngProgress.start();
          this.addScripManager.searchScrip(this.exchangeList[i],this.searchStr,this.isFandO).then((data)=>{
            this.ngProgress.done();
            this.user_search_result = data;
            //console.log("this.user_search_result",this.user_search_result)
            //this.tempSearch = JSON.parse(this.user_search_result.data.data).length;
            //----Successfully loaded search result list ---
            if(this.user_search_result.data.data == "" || this.user_search_result.data.data == null){
              //---do nothing
                this.showScripList = false;

          }else{
            this.showScripList = true;
            this.tmpscripList = JSON.parse(this.user_search_result.data.data);
            this.tmpscripList.forEach((search_tempObj, index) => {

                if( this.futureOptionFlag === 2 && search_tempObj.Indices != '1' && (search_tempObj.OI == '' || search_tempObj.OI == undefined)){

                }else {
              this.scripList.push({
                  ID: search_tempObj.ID,
                  Name: search_tempObj.Name,
                  Token: search_tempObj.Token,
                  Indices: search_tempObj.Indices,
                  Exchange: this.user_search_result.config,
                  FI: search_tempObj.FI,
                  OI: search_tempObj.OI
              });
            }
            });
          }
          }, err=> {
            // this.common.hideLoading();
            swal({
                    // title: "Error!",
                    text: "Something went wrong.",
                    timer: 2000,
                    showConfirmButton: false,
                    allowOutsideClick: true
                });
          });
          // console.log("this.exchangeList[i]",this.exchangeList[i])
      }
  }
  //---Toggling of scrip section--
    toggleGroup (group) {
            this.selectedDate = 0;
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
            this.selectedDate = 0;
            
        } else {
            this.getScripRate(group);
            this.shownGroup = group;
        }
    }
    isGroupShown(group) {
        return this.shownGroup === group;
    }

    getScripRate(group){
      //--when a scrip is expanded,
      //--get specified quote and display the data
      this.selectedScrip = {};
      //--if Scrip search selection is future, get Expiry data as well and show
      if (this.futureOptionFlag === 1) {
          //To get Expiry for Future indices
          if (group.Indices === "1") {
            this.InstrumentType = "FUTIDX"
        } else {
            this.InstrumentType = group.FI
        }

          //--service to call expiry date --
          this.addScripManager.getExpiryDate(group.Exchange,this.InstrumentType,group.ID).then((data)=>{
            this.user_expiryDate_result = data;
            if(this.user_expiryDate_result.ErrorCode==0){
              this.scripSetExpiry = JSON.parse(this.user_expiryDate_result.data);
              if(this.scripSetExpiry!=null){
                this.selectedExpiry = this.scripSetExpiry[0].ExpKey;
                this.selectedExpiryVal = this.scripSetExpiry[0].ExpVal.split("=")[1];
                this.shownExpiry = this.scripSetExpiry[0];
              }else{
                this.selectedExpiry = ''
              }
              this.getSelectedScripQuote(group);
            }
          }, err=> {});
      }
      if (this.futureOptionFlag === 2) {
          //To get Expiry for Future indices
          if (group.Indices === "1") {
            this.InstrumentType = "OPTIDX"
        } else {
          this.InstrumentType = group.OI
      }

        //   if (group.Exchange === 'FONSE' || group.Exchange === 'FOBSE') {
             
        //   }


        //   if (group.Exchange == 'CDNSE' || group.Exchange == 'CDBSE' || group.Exchange == 'MCXSX') {
        //       this.InstrumentType = "OPTCUR"
        //   }
        //   if (group.Exchange == 'MCX' || group.Exchange == 'NCDEX') {
        //       this.InstrumentType = "OPTFUT"
        //   }
        //   if ( group.Exchange == 'COMNSE') {
        //       this.InstrumentType = "OPTION"
        //   }

          //--service to call expiry date --
          this.addScripManager.getExpiryDate(group.Exchange,this.InstrumentType,group.ID).then((data)=>{
            this.user_expiryDate_result_option = data;
            if(this.user_expiryDate_result_option.data!=null){
              this.scripSetExpiry = JSON.parse(this.user_expiryDate_result_option.data);
              if(this.scripSetExpiry!=null){
                this.selectedExpiry = this.scripSetExpiry[0].ExpKey;
                this.selectedExpiryVal = this.scripSetExpiry[0].ExpVal.split("=")[1];
                this.shownExpiry = this.scripSetExpiry[0];
              }
              this.getSelectedScripQuote(group);
              //--if Scrip search selection is options, get strike price as well and show
                  if (this.showOptionData === true) {
                      //console.log("this.scripSetExpiry",this.scripSetExpiry)
                      if(this.scripSetExpiry!=null){
                        this.addScripManager.getStrikePrices(group.Exchange,this.scripSetExpiry[0].ExpKey,group.ID,this.selectedOptionType).then((data)=>{
                          this.strikePriceList_result=data;
                          if(this.strikePriceList_result.ErrorCode==0){
                            this.strikePriceList_result.data=this.strikePriceList_result.data.replace('[','')
                            this.strikePriceList_result.data=this.strikePriceList_result.data.replace(']','')
                            this.strikePriceList = (this.strikePriceList_result.data).split(',');
                            //console.log("this.strikePriceList ",this.strikePriceList )
                            //console.log("this.strikePriceList",this.strikePriceList.length)
                            var listlength = this.strikePriceList.length - 1;

                            this.rangeData = {
                                min: 0,
                                max: 0,
                                value: 0,
                                step: 0
                            };
                            // var selectedStrikePrice = "";
                            var CurrentStrikePriceIndex = (listlength / 2);
                            if(CurrentStrikePriceIndex % 1 !== 0){
                              CurrentStrikePriceIndex = CurrentStrikePriceIndex + (CurrentStrikePriceIndex % 1);
                            }
                            //console.log("CurrentStrikePriceIndex",CurrentStrikePriceIndex)
                            this.rangeData = {
                                min: this.strikePriceList[0],
                                max: this.strikePriceList[listlength],
                                value: this.strikePriceList[(listlength / 2)],
                                step: (this.strikePriceList[1] - this.strikePriceList[0]),
                                selectedStrikePrice: this.strikePriceList[CurrentStrikePriceIndex]
                            };
                            //console.log("this.rangeData",this.rangeData)
                            /* this.rangeData.selectedStrikePrice = Number(this.rangeData.selectedStrikePrice) + Number(this.rangeData.step) - +Number(this.rangeData.step);*/
                            this.rangeData.selectedStrikePrice = this.strikePriceList[CurrentStrikePriceIndex];

                            this.getSelectedScripQuote(group);
                          }
                        }, err=> {});
                      }
                  }
            }else{
              this.shownGroup = null;
               swal({
                     title: "Error!",
                     text: "No Data Available.",
                     timer: 2000,
                     showConfirmButton: false,
                     allowOutsideClick: true
                 });
              return;
            }
          }, err=> {});
      }
      this.getSelectedScripQuote(group);
    }

    //---get selected scrip quote --
    getSelectedScripQuote(group){
      //--- for future and options, send only underlying as querystring....
      //if User is looking for a Future Scrip then modify the Ticker to search for selected expiry e.g. NSE.ACC~F:1-MON
      var specifiedQuoteString;
      if (this.showOptionData === true) {
          //To get LTP for option indices
          if (group.Indices == 0) {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID) + '~O:' + this.selectedExpiry + ':' + this.selectedOptionType + ':' + this.rangeData.selectedStrikePrice;
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name) + '~O:' + this.selectedExpiry + ':' + this.selectedOptionType + ':' + this.rangeData.selectedStrikePrice;
          }
      }else if(this.showFutureData === true){
        if (group.Indices == 0) {
            specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID) + '~F:' + this.selectedExpiry;

        } else {
            specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name)+ '~F:' + this.selectedExpiry;

        }
      }else {
          if (group.Indices == 0) {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID);
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name);
          }
      }

      //---service to call the selected scrip only--
        this.addScripManager.getSelectedScrip(specifiedQuoteString).then((data)=>{
          this.getSelectedSrip_result=data;
          if(this.getSelectedSrip_result.ErrorCode==0){
              var scripSet = JSON.parse(this.getSelectedSrip_result.data);
              this.singleScrip = scripSet[0];
              this.selectedScrip = this.singleScrip;

              if (this.selectedScrip.LTP == '') {
                  this.selectedScrip.LTP = 0;
              }
              if (this.selectedScrip.Close == '') {
                  this.selectedScrip.Close = 0;
              }
              if (this.selectedScrip.BidQty == '') {
                  this.selectedScrip.BidQty = 0;
              }
              if (this.selectedScrip.BidPrice == '') {
                  this.selectedScrip.BidPrice = 0;
              }
              if (this.selectedScrip.LastTradeTime == '') {
                  this.selectedScrip.LastTradeTime = 0;
              }
              if (this.selectedScrip.OfferQty == '') {
                  this.selectedScrip.OfferQty = 0;
              }
              if (this.selectedScrip.OfferPrice == '') {
                  this.selectedScrip.OfferPrice = 0;
              }
              if (this.selectedScrip.Volume == '') {
                  this.selectedScrip.Volume = 0;
              }
              this.selectedScrip['%Change'] = (((this.selectedScrip.LTP - this.selectedScrip.Close) / this.selectedScrip.Close) * 100).toFixed(2);
              if (this.selectedScrip['%Change'] == '-100' || this.selectedScrip['%Change'] == '-100.00' || this.selectedScrip['%Change'] == 'NaN' || this.selectedScrip['%Change'] == 'Infinity') { this.selectedScrip['%Change'] = 0 }

              //this.selectedScrip.LTP = singleScrip.LTP;
          }
      },err=>{
        //---error happend in fetching
      })
    }
    //---set expiry of the future data--
    setExpiryKey(Expiry, group) {
        this.selectedExpObj = Expiry;
        this.selectedExpiry = Expiry.ExpKey;
        this.selectedExpiryVal = Expiry.ExpVal.split("=")[1];
        this.getSelectedScripQuote(group);
        //getScripRate(group);
        // console.log("Expiry",Expiry)
        // console.log("group",group)
        this.addScripManager.getStrikePrices(group.Exchange,Expiry.ExpKey,group.ID,this.selectedOptionType).then((data)=>{
          this.strikePriceList_result=data;
          if(this.strikePriceList_result.ErrorCode==0){
            this.strikePriceList_result.data=this.strikePriceList_result.data.replace('[','')
            this.strikePriceList_result.data=this.strikePriceList_result.data.replace(']','')
            this.strikePriceList = (this.strikePriceList_result.data).split(',');
            //this.strikePriceList = JSON.parse(this.strikePriceList_result.data);
            var listlength = this.strikePriceList.length - 1;

            this.rangeData = {
                min: 0,
                max: 0,
                value: 0,
                step: 0
            };
            // var selectedStrikePrice = "";

            var CurrentStrikePriceIndex = Math.round(listlength / 2);
            if(CurrentStrikePriceIndex % 1 !== 0){
              CurrentStrikePriceIndex = CurrentStrikePriceIndex + (CurrentStrikePriceIndex % 1);
            }
            this.rangeData = {
                min: this.strikePriceList[0],
                max: this.strikePriceList[listlength],
                value: this.strikePriceList[(listlength / 2)],
                step: (this.strikePriceList[1] - this.strikePriceList[0]),
                selectedStrikePrice: this.strikePriceList[CurrentStrikePriceIndex]
            };

            /* this.rangeData.selectedStrikePrice = Number(this.rangeData.selectedStrikePrice) + Number(this.rangeData.step) - +Number(this.rangeData.step);*/
            this.rangeData.selectedStrikePrice = this.strikePriceList[CurrentStrikePriceIndex];

            this.getSelectedScripQuote(group);
          }
        }, err=> {});
    }
    //--select option type --
    setOptionType(OptionType, group) {
        this.selectedOptionType = OptionType;
        //getScripRate(group);
        this.getSelectedScripQuote(group);
        if (this.selectedExpObj) {
            this.setExpiryKey(this.selectedExpObj, group);
        }
    }
    //--set price based on range --
    setStrikePrice(group) {
      //console.log("this.rangeData",group)
        this.getSelectedScripQuote(group);
    }

    //---Add to market watch----
    addToMW(group){
      //console.log("group----->", group)
    //   this.allowed_script = 12;
      //---check if user is allowed exchange. if not, then give message and prevent Add to MW
      if(this.watchListAddItem.watchlistItems != undefined && (this.watchListAddItem.watchlistItems.length<this.allowed_script)){  
      var ProductType =this.userData.ExchangeMarketSegmentList.split('^');
      var ExchangePermit = 0;
      //console.log("productType"+ JSON.stringify(ProductType));
      for (var i = 0; i < ProductType.length; i++) {
          if (ProductType[i].split('$')[0] == group.Exchange) {
              ExchangePermit = 1;
              break;
          }
      }
      //---If user is not allowed to add the scrip in the market watch since it is not mapped to the trading account list.
      if(ExchangePermit === 0) {
          swal({title: "Cannot Add",text: "Cannot add to Marketwatch, Exchange " + group.Exchange + " is not mapped to the user.",allowOutsideClick: true,showConfirmButton: false,showCancelButton: true,cancelButtonText: "Close"});
          return false;
      }
      //---validating strike price if undefine then not adding in market watch
      if (this.showOptionData == true) {
          if (this.rangeData.selectedStrikePrice == undefined || this.rangeData.selectedStrikePrice == null) {
              swal({
                  title: "Cannot Add",
                  // type: "error",
                  text: "Please select strike price.",
                  allowOutsideClick: true,
                  showConfirmButton: false,
                  showCancelButton: true,
                  cancelButtonText: "Close"

              });
              return false;
          }
      }
      //--- for future and options, send only underlying as querystring....
      //---if User is looking for a Future Scrip then modify the Ticker to search for selected expiry e.g. NSE.ACC~F:1-MON
      var specifiedQuoteString;
      if (this.showOptionData === true) {
          if (group.Indices === "1") {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name) + '~O:' + this.selectedExpiry + ':' + this.selectedOptionType + ':' + this.rangeData.selectedStrikePrice;
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID) + '~O:' + this.selectedExpiry + ':' + this.selectedOptionType + ':' + this.rangeData.selectedStrikePrice;
          }


      } else if (this.showSpreadData === true) {
          if (group.Indices === "1") {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name);
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID);
          }
      } else if (this.showSpotData === true) {
          if (group.Indices === "1") {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name);
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID);
          }
      } else if (this.showFutureData === true) {
          if (group.Indices === "1") {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name)
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID)
          }
          if(this.selectedExpiry !=''){
            specifiedQuoteString += '~F:' + this.selectedExpiry;
          }

      } else {
          if (group.Indices == 0) {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.ID);
          } else {
              specifiedQuoteString = '?Tickers=' + encodeURIComponent(group.Exchange) + '.' + encodeURIComponent(group.Name);
          }
      }

      //---service to call get specified quote
        this.addScripManager.getSpecifiedQuote(specifiedQuoteString).then((data)=>{
          this.getSpecified_quote_result=data;
          if(this.getSpecified_quote_result.ErrorCode==0){
            var scripSet = JSON.parse(this.getSpecified_quote_result.data);
            this.singleScrip_quote = scripSet[0];

            //add to current watchlist $rootScope.watchlistItems. add to top of watchlist
            this.singleScrip_quote = this.computeScripDetails(this.singleScrip_quote );
            //---check if scrip already in watchlist. if not, then add else alert
            this.scripExistsinWL = false;
            //---loop over the market watch item which is been called from the service---
            this.watchListAddItem.watchlistItems.forEach((marketWatchListItems_Obj, index) => {
              //console.log("this.watchListAddItem.watchlistItems[index].ticker",this.watchListAddItem.watchlistItems[index].ticker.toUpperCase())
              //console.log("this.singleScrip_quote.ticker.toUpperCase()",this.singleScrip_quote.ticker.toUpperCase())
              if (this.watchListAddItem.watchlistItems[index].exchangeLegend === this.singleScrip_quote.exchangeLegend && this.watchListAddItem.watchlistItems[index].ticker.toUpperCase() === this.singleScrip_quote.ticker.toUpperCase()) {
                  this.scripExistsinWL = true;
              }
            });
            if (this.scripExistsinWL === true) {
                swal({
                    title: "Duplicate",
                    text: "Scrip Already exists in current Marketwatch",
                    // type: "error",
                    timer: 1250,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                try {
                    let page = this.navCtrl.getViews()
                    if (page.length > 1){
                    this.navCtrl.pop();
                    }
                  } catch(e){}

            } else {
                //var addkey = 'ADD^1^' + this.GetExchangeCode(this.singleScrip_quote.exchange) + '.1!' + this.singleScrip_quote.ticker;
                //this.socket.send(addkey.toUpperCase());

                this.singleScrip_quote.HoldingValue = 0;
                this.watchListAddItem.watchlistItems.splice(0, 0, this.singleScrip_quote);
            
                //---Call the save marketwatch watch after adding the scrip --
                this.saveMarketWatchFirst()
            }
            //console.log("this.watchListAddItem.watchlistItems",this.watchListAddItem.watchlistItems)
          }
      },err=>{
        //---error happend in fetching
      })
      }
else{
    
    swal({
        title: "Error!",
        text: "Not able to save Market Watch, No. of Scrip limitation "+this.allowed_script,
        type:"info",
        timer: 3000,
        showConfirmButton: false
    }).then(_=>{
        
        try {
            let page = this.navCtrl.getViews()
            if (page.length > 1){
            this.navCtrl.pop();
            }
          } catch(e){}
    })
}
}
    
    saveMarketWatchFirst(){
       
 
      //console.log("this.WatchlistName in save",this.WatchlistName)
      var scripList = '';
      if(this.watchListAddItem.watchlistItems != undefined){
        this.watchListAddItem.watchlistItems.forEach((marketWatchListItems_tempObj, index) => {
          if (marketWatchListItems_tempObj.exchange != '') {
              scripList = scripList + encodeURIComponent(marketWatchListItems_tempObj.exchange) + '.' + encodeURIComponent(marketWatchListItems_tempObj.ticker) + '^';
          }
        });
      }

      //save Marketwatch only if SystemTag==0, else for everything else, do not send save command as server will not save changes to watchlist with systemTag=1 in any case.

      if (scripList === '') { //this.CurrentMWsystemTag !== '0' ||
          return false;
      }

      let Source = 5
      var qStringforSave = '{';
      qStringforSave += '"UserId":"' + this.userData.ClientCode + '",';
      qStringforSave += '"SessionNo":"' + this.userData.SessionNo + '",';
      qStringforSave += '"Source":"' + Source + '",';
      qStringforSave += '"TemplateName":"' + this.WatchlistName + '",';
      qStringforSave += '"Exchange":"NSE",';
      qStringforSave += '"TickersList":"' + scripList + '",';
      //qStringforSave += '"ColumnsList":" ",';
      qStringforSave += '"ColumnsList":"Ind^LTP^BidQty^BidPrice^OfferPrice^OfferQty^LTQ",';
      qStringforSave += '"TriggersList":"BidPrice",';
      qStringforSave += '"AlertsFiltersList":"BidPrice",';
      qStringforSave += '"Font":"",';
      qStringforSave += '"DefaultMarketwatch":"1",';
      qStringforSave += '"DefaultGrid":"0"}';
      //console.log("qStringforSave-->", qStringforSave);
      this.marketWatchManager.saveListMWatch(qStringforSave).then((data:any)=>{
        this.user_marketSave_result = data;
        if(this.user_marketSave_result.ErrorCode == '0'){
        console.log("Market watch saved successfully",data);
          // this.loadMarketWatch(this.CurrentMWObject, this.CurrentMWsystemTag, this.CurrentMWtype,'')
          // refresher.complete();
          swal({
            title: "Added",
            text: "Added to current Marketwatch",
            timer: 1250,
            allowOutsideClick: true,
            showConfirmButton: true
        });
        }else{
          console.log("Market watch error while saving",data);
          swal({
            title: "Error!",
            text: data.Message,
            timer: 3000,
            allowOutsideClick: true,
            showConfirmButton: true
        });
        
        try {
            let page = this.navCtrl.getViews()
            if (page.length > 1){
            this.navCtrl.pop();
            }
          } catch(e){}
        }
      }, err=> {
        // this.common.hideLoading();
          swal({
              title: "Error!",
              text: "Network Issue...",
              timer: 3000,
              showConfirmButton: false
          });
      });

    }
    //---------
    computeScripDetails(singleScrip) {
        var tickertype = 'EQT';
        var ScripExchange = singleScrip.exchange;
        var ticker = singleScrip.ticker;

        //identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
        if (ticker.search("~") > 0) {
            tickertype = 'FUT';
            if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
                tickertype = 'OPT';
            }
            if (ticker.search("~S") > 0) {
                tickertype = 'SPD';
            }
        } else {
            tickertype = 'EQT';
        }

        singleScrip.exchangeLegend = this.GetExchangeLegend(ScripExchange);

        if (tickertype == 'EQT') {
            singleScrip.underlying = ticker.toUpperCase();
            singleScrip.optType = '';
            singleScrip.strikePrice = '';
        }
        if (tickertype == 'SPD') {
            singleScrip.underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
            singleScrip.optType = 'S';
            //singleScrip.strikePrice = '';

            this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
            //$rootScope.watchlistItems[index].strikePrice = '';
            singleScrip.strikePrice = this.spreadType.split("~")[0];
        }

        if (tickertype == 'FUT') {
            singleScrip.underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
            singleScrip.optType = 'F';
            singleScrip.strikePrice = '';
            //this.sep1='|';
            //this.sep2='';
        }

        if (tickertype == 'OPT') {
            singleScrip.underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
            singleScrip.optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
            singleScrip.strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
            //this.sep1='|';
            //this.sep2='|';
        }
        singleScrip['%Change'] = (((singleScrip.LTP - singleScrip.Close) / singleScrip.Close) * 100).toFixed(2);

        if (singleScrip['%Change'] == '-100.00' || singleScrip['%Change'] == "NaN" || singleScrip['%Change'] == "Infinity") { singleScrip['%Change'] = 0 }

        return singleScrip;
    }

    //------------
    GetExchangeLegend(Exchange){
      var strCode = "";
      switch (Exchange) {
          case "NSE":
              strCode = "N";
              break;
          case "BSE":
              strCode = "B";
              break;
          case "FOBSE":
              strCode = "B";
              break;
          case "CDBSE":
              strCode = "B, CU";
              break;
          case "FONSE":
              strCode = "N";
              break;
          case "ACE":
              strCode = "A";
              break;
          case "CDNSE":
              strCode = "N, CU";
              break;
          case "MCX":
              strCode = "M";
              break;
          case "COMNSE":
              strCode = "COM";
              break;
          case "NCDEX":
              strCode = "X";
              break;
          case "MCXSX":
              strCode = "M, CU";
              break;
          case "NSEL":
              strCode = "NS";
              break;
          case "MCXSXEQ":
              strCode = "M, EQ";
              break;
          case "MCXSXFO":
              strCode = "M, FO";
              break;
        case "NEPSE":
              strCode = "NEP";
        break;
      }
      return (strCode);
    }

    GetExchangeCode(Exchange) {
        var strCode = "0";
        switch (Exchange) {
            case "NSE":
            case "FONSE":
                strCode = "4";
                break;
            case "BSE":
            case "FOBSE":
                strCode = "1";
                break;
            case "ACE":
                strCode = "10";
                break;
            case "CDNSE":
                strCode = "13";
                break;
            case "MCX":
                strCode = "7";
                break;
            case "COMNSE":
                strCode = "5";
                break;
            case "NCDEX":
                strCode = "8";
                break;
            case "MCXSX":
                strCode = "14";
                break;
            case "NSEL":
                strCode = "36";
                break;
            case "MCXSXEQ":
                strCode = "64";
                break;
            case "MCXSXFO":
                strCode = "65";
                break;
            case "CDBSE":
                strCode = "17";
                break;
            case "NEPSE":
                strCode = "25";
                break;
        }
        return (strCode);
    }


        public addValue(group){
            // console.log(' + Fist Check ----->'+this.rangeData.selectedStrikePrice);
            // if(parseFloat(this.rangeData.selectedStrikePrice)<parseFloat(this.rangeData.max)){
            //   this.rangeData.selectedStrikePrice = parseFloat(this.rangeData.selectedStrikePrice) + parseFloat(this.rangeData.step);
            // }
            // //console.log(this.rangeData.selectedStrikePrice);
            var allData = [];
            allData = this.strikePriceList;
            var len = allData.length;
            var stkPriz =this.rangeData.selectedStrikePrice;
            if(stkPriz){
                for(var k=0;k<len;k++){
                    if(allData[k] == stkPriz){
                        if(k == len-1){this.rangeData.selectedStrikePrice = allData[k]}else{
                        var setValue = allData[k+1];
                        this.rangeData.selectedStrikePrice = setValue;
                        //console.log(setValue);
                        }

                    }
                }
            }else{this.rangeData.selectedStrikePrice = allData[len]}
            this.getSelectedScripQuote(group);
        }

        public subtractaValue(group){
            // console.log(' - Fist Check ----->',this.rangeData.selectedStrikePrice);
            // console.log(' - this.rangeData.min ----->',this.rangeData.min);
            // if(parseFloat(this.rangeData.selectedStrikePrice)>parseFloat(this.rangeData.min)){
            //   this.rangeData.selectedStrikePrice = parseFloat(this.rangeData.selectedStrikePrice) - parseFloat(this.rangeData.step);
            // }

            var allData = [];
            allData = this.strikePriceList;
            var len = allData.length;
            var stkPriz =this.rangeData.selectedStrikePrice;
            if(stkPriz){
                for(var k=0;k<len;k++){
                    if(allData[k] == stkPriz){
                        //var index = allData.indexOf(stkPriz);
                        if(k == 0){this.rangeData.selectedStrikePrice = allData[0]}else{
                        var setValue = allData[k-1];
                        this.rangeData.selectedStrikePrice = setValue;
                        }
                        // console.log(setValue); 
                    }
                }
            }else{this.rangeData.selectedStrikePrice = allData[0]}
           
            this.getSelectedScripQuote(group); 
            //console.log(this.rangeData.selectedStrikePrice);
        }

    presentStrikePriceModal(group) {
     let profileModal = this.modalCtrl.create("StrikePriceModal", { strikePriceValue:this.strikePriceList});
     profileModal.onDidDismiss(data => {
       //console.log(data);
       if(typeof(data) != "undefined"){
         this.rangeData.selectedStrikePrice=data
         this.getSelectedScripQuote(group); 

       }else{
         //alert("test")
       }

     });
     profileModal.present();
   }

getUserServiceProperties(userId)
{
    
this.get_report.GetUserPropertyDeatailsStatus(userId,this.userData.SessionNo).then((data:any)=>{

    // if(data.ErrorCode != 0){
    //     this.allowed_script = 25
    // }
        let userData= (data.data);
        if(userData) {
            this.allowed_script= (userData && userData[3][0])?userData[3][0].NoOfScrip:25;
            if(this.allowed_script === undefined){
                this.allowed_script = 25
            }
        } else {
            this.allowed_script = 25
        }

})
}




}
