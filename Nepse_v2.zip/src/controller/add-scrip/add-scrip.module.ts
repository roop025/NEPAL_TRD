import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddScripPage } from './add-scrip';
import {PipesModule} from '../../pipes/pipes.module';
import { NgProgressModule } from 'ngx-progressbar';

@NgModule({
  declarations: [
    AddScripPage,
  ],
  imports: [
    PipesModule,
    NgProgressModule,
    IonicPageModule.forChild(AddScripPage),
  ],
})
export class AddScripPageModule {}
