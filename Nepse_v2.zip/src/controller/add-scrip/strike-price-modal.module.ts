import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StrikePriceModal } from './strike-price-modal';
import {PipesModule} from '../../pipes/pipes.module';
import { NgProgressModule } from 'ngx-progressbar';

@NgModule({
  declarations: [
    StrikePriceModal,
  ],
  imports: [
    PipesModule,
    NgProgressModule,
    IonicPageModule.forChild(StrikePriceModal),
  ],
})
export class StrikePriceModalModule {}
