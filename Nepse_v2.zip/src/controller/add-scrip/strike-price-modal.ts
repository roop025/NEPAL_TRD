import { Component } from '@angular/core';
import { NavController , IonicPage,NavParams,ViewController } from 'ionic-angular';
import { AddScripProvider } from '../../providers/add-scrip/add-scrip';
import swal from 'sweetalert2';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { Storage } from '@ionic/storage';
// import { OrderbyPipe } from '../../pipes/orderBy/orderBy';
import { NgProgress } from 'ngx-progressbar';


@IonicPage()
@Component({
  selector: 'page-addScrip',
  templateUrl: '../../pages/DionWhite/add-scrip/strike-price-modal.html'
})

export class StrikePriceModal {
  public strikepriceData : any;

  constructor(public navCtrl: NavController,
    private addScripManager:AddScripProvider,
    private clientMarketWatchList : GlobalVariableService,
    private storage:Storage,
    public navParams: NavParams,
    public viewCtrl: ViewController,
    ) {
      this.strikepriceData=navParams.get('strikePriceValue')
      //console.log("this.strikepriceData",this.strikepriceData)
  }

  ionViewDidLoad(){
    //console.log("test from login")
    //console.log("In add scrip page -->",this.clientMarketWatchList.getData())

  }

  closeModal(){
    //let data = { 'foo': 'bar' };
    this.viewCtrl.dismiss();
  }

  strikePriceSelectedValue(data){
    this.viewCtrl.dismiss(data);
  }
}
