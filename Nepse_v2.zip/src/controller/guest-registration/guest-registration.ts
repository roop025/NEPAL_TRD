import { Component,ViewChild,ElementRef } from '@angular/core';
import { NavController , IonicPage ,NavParams } from 'ionic-angular';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { NgForm } from '@angular/forms';
// import  data  from  '../../assets/DionBlack/contactInfo.json';
declare var require:any

@IonicPage()
@Component({
  selector: 'page-changePassword',
  templateUrl: '../../pages/DionWhite/guest-registration/guest-registration.html'
})

export class GuestRegistrationPage {
  @ViewChild("guestMobile") public guestMobile: ElementRef;
  @ViewChild("guestEmail") public guestEmail: ElementRef;
  @ViewChild("password") public password: ElementRef;
  @ViewChild("confirmNewPassword") public confirmNewPassword: ElementRef;
  @ViewChild("guestPAN") public guestPAN: ElementRef;
  @ViewChild("guestName") public guestName: ElementRef;

  @ViewChild('registerDetailsForm') registerDetailsForm;

  public guestRegistrData : any;
  public guest_user_generate_otp_result : any;
  private user_change_password_result : any;
  public ForgotPasswordOptions : any;
  public ClientName : any;
  public showPassword : any;
  public showTradePassword : any;
  public showConfirmPassword : any;
  public guest_user_validate_otp_result : any;
  public guest_user_register_result : any;

  public showRegisterForm:any = true;
  public showOtpForm:any = false;
  public otp:any = '';
  public activeClientData:any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private userManager:UserManagerProvider,
    public globalVar:GlobalVariableService,
    private common:CommonProvider,
    ){
      //this.guestRegtrFrmData.password = '123';
      this.guestRegistrData = {
            guestMobile:'',
            guestEmail:'',
            password: '',
            confrPassword: '',
            guestPAN: '',
            guestOTP:'',
            guestName:''
        }

    // this.showRegisterForm = true;
    this.showRegisterForm = true;
    this.showOtpForm = false;
    this.ClientName = globalVar.clientName;
    // this.activeClientData = globalVar.getActiveClientData(globalVar.activeClient);
    }

    
  ngOnInit(){
    this.activeClientData = require("../../assets/DionBlack/contactInfo.json");
    // this.activeClientData = data
  }

  ionViewDidLoad(){
    //console.log("test from login")
  }

  guestRegistrSubmit(form: NgForm){
    var guestDetail = form.value;
    //console.log(guestDetail);

     if(this.guestRegistrData.guestMobile=='' || this.guestRegistrData.guestMobile==undefined){
      swal({
          text: "Please Enter Mobile Number",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.guestMobile;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.guestMobile;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.guestRegistrData.guestEmail=='' || this.guestRegistrData.guestEmail==undefined){
      swal({
        text: "Please Enter Email Id",
    }).then((result) => {
        if (result.value) {
          setTimeout(() => {
            var elem:any = this.guestEmail;
            elem._native.nativeElement.focus();
          }, 100);
        }else{
          setTimeout(() => {
            var elem:any = this.guestEmail;
            elem._native.nativeElement.focus();
          }, 100);
        }
    })
    }else if(this.guestRegistrData.guestName=='' || this.guestRegistrData.guestName==undefined){
      swal({
        text: "Please Enter Name",
    }).then((result) => {
        if (result.value) {
          setTimeout(() => {
            var elem:any = this.guestName;
            elem._native.nativeElement.focus();
          }, 100);
        }else{
          setTimeout(() => {
            var elem:any = this.guestName;
            elem._native.nativeElement.focus();
          }, 100);
        }
    })
    }
    else if(this.guestRegistrData.password=='' || this.guestRegistrData.password==undefined){
      swal({
          text: "Please Enter Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.password;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.password;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }else if(this.guestRegistrData.confrPassword == '' || this.guestRegistrData.confrPassword==undefined){
      swal({
          text: "Please Enter Confirm Password",
      }).then((result) => {
          if (result.value) {
            setTimeout(() => {
              var elem:any = this.confirmNewPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }else{
            setTimeout(() => {
              var elem:any = this.confirmNewPassword;
              elem._native.nativeElement.focus();
            }, 100);
          }
      })
    }
    else if(this.guestRegistrData.password!=this.guestRegistrData.confrPassword){
      swal({
          text: "Password and Confirm Password mismatch !",
      });
    }else if(this.guestRegistrData.guestPAN == '' || this.guestRegistrData.guestPAN==undefined){
    swal({
        text: "Please Enter PAN Number",
    }).then((result) => {
        if (result.value) {
          setTimeout(() => {
            var elem:any = this.guestPAN;
            elem._native.nativeElement.focus();
          }, 100);
        }else{
          setTimeout(() => {
            var elem:any = this.guestPAN;
            elem._native.nativeElement.focus();
          }, 100);
        }
    })
  }else{
      //console.log("this.guestRegistrData",this.guestRegistrData);
      this.common.showLoading();
      //---Generate guest user otp--
      this.userManager.GuestUserGenerateOTP(this.guestRegistrData).then((data)=>{
        this.guest_user_generate_otp_result = data;
        this.common.hideLoading();
        if(this.guest_user_generate_otp_result.ErrorCode == '0'){
          this.showRegisterForm = false;
          this.showOtpForm = true;
          // swal({
          //     title: "OTP sent Successful",
          //     text: this.guest_user_generate_otp_result.Message,
          //     type: "success"
          // });
        }else{
          swal({
              title: 'Wrong Number',
              text: this.guest_user_generate_otp_result.Message,
              type: "warning"
          });
        }
      }, err=> {
        this.common.hideLoading();
      });
    }
  }

  //----Hide show password function --\
  hideShowPassword(){
    this.showPassword = !this.showPassword;
  }

  hideShowConfirmPassword(){
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  submitOtp(){
    if(this.guestRegistrData.guestOTP == '' || this.guestRegistrData.guestOTP == undefined){
      swal({
        text: "Enter OTP",
        });
        return false;
    }else{
      //---Generate guest user otp--
      this.common.showLoading();
      this.userManager.GuestUserValidateOTP(this.guestRegistrData).then((data)=>{
        this.guest_user_validate_otp_result = data;
        this.common.hideLoading();
        if(this.guest_user_validate_otp_result.ErrorCode == '0'){
          //---Now after success go for register of guest user--
          this.common.showLoading();
          //---Generate guest user otp--
          this.userManager.GuestUserRegister(this.guestRegistrData).then((data)=>{
            this.guest_user_register_result = data;
            this.common.hideLoading();
            if(this.guest_user_register_result.ErrorCode == '0'){
                this.navCtrl.push('GuestLogin');
                swal({
                  title: "Successful",
                  text: 'Guest User registration successful',
                  type: "success",
                  timer:3000
              });
            }else if(this.guest_user_register_result.ErrorCode == '-20020002'){
              swal({
                title: "Registration Fails",
                text: this.guest_user_register_result.Message,
                type: "warning"
            });
            //this.showRegisterForm = true;
            this.showOtpForm = false;
            this.navCtrl.push('GuestLogin');
            }else{
              swal({
                  title: 'Registration Fails',
                  text: this.guest_user_register_result.Message,
                  type: "warning"
              });
            }
          }, err=> {
            this.common.hideLoading();
          });

        }else{
          swal({
              title: 'Wrong OTP',
              text: this.guest_user_validate_otp_result.Message,
              type: "warning"
          });
        }
      }, err=> {
        this.common.hideLoading();
      });
    }
  }

  goBack(){
    this.showRegisterForm = true;
    this.showOtpForm = false;
  }
}
