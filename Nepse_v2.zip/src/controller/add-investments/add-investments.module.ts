import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddInvestmentsPage } from './add-investments';

@NgModule({
  declarations: [
    AddInvestmentsPage,
  ],
  imports: [
    IonicPageModule.forChild(AddInvestmentsPage),
  ],
})
export class AddInvestmentsPageModule {}
