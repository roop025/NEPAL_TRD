import { Component,NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PortfolioTrackerProvider } from '../../providers/portfolio-tracker/portfolio-tracker';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
/**
 * Generated class for the PortfolioSummaryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-investments',
  templateUrl: '../../pages/Bgse/add-investments/add-investments.html',
})
export class AddInvestmentsPage {
  // portfolio_list:any="Select";
  userData:any;
  listOfPortfolio:any[]=[];
  search_Cmpny:any;
  companyLists:any[]=[];
  company_details:any;
  portfolio_form:any={};
  InstrumentLists:any[]=[];
  ExpiryDateList:any[]=[];
  SymbolList:any[]=[];
  OptionList:any[]=[];
  strikePriceList:any[]=[];
  tran_type:any='equity';
  constructor(public navCtrl: NavController,public lc:NgZone,
    public storage:Storage, public navParams: NavParams,public pt_traker:PortfolioTrackerProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PortfolioSummaryPage');
    this.portfolio_form.exchange_name="BSE";
    this.portfolio_form.transaction_type=0;
    // let obj=
    // {
    //   "ServiceName":"EquityHoldingSummary",
    //   "ParameterList":"LoginID=128605$AccountID=0$Type=A"
    

    // }
    this.storage.get("userMaster").then((data)=>{
      if(data!=null && data!=''){
       console.log(data);
       this.userData=data;
       this.getDerivativeInstrumentList()

      let obj=
    {
      "ServiceName":"AccountNamesForLoginId",
      "ParameterList":`LoginID=${this.userData.ClientCode}`
    

    }
    this.pt_traker.getPTServicesDownloadReport(obj).then(_ptdata=>{
      console.log("Suceess",_ptdata);
      
      if(_ptdata.ErrorCode==0)
      {
        console.log("Suceess",_ptdata);
        this.listOfPortfolio=_ptdata.DataSet.Table;
        this.portfolio_form.portfolio_list=this.listOfPortfolio[0].accountid;
      }
    }).catch(ee=>{
      console.log(ee);
      
    })
  }
})
  }

   addPortfolio(){
    //use swal to ask for new wlname, then create a new marketwatch with NIFTY/Sensex
    //close page and then load new watchlist after creation.
            // this.optionFlag = false;
    swal({
      title: 'Add Portfolio',
      text: "Please enter Portfolio Name",
      input: 'text',
      inputPlaceholder: "Portfolio Name",
      showCancelButton: true,
      confirmButtonText: 'Create',
      showLoaderOnConfirm: true,
      inputValidator: (inputValue) => {
        if(!inputValue){
            //---input field is blank ---
          return !inputValue && 'Please enter portfolio name!'
        }else{
          console.log("Input value",inputValue);

          let obj=
          {
            "ServiceName":"AddNewPortfolio",
            "ParameterList":`UserID=${this.userData.ClientCode}$UserName=${inputValue}$PortfolioName=${inputValue}
            $DeleteFlag=0$AccountAccessType=F$Type=I$PortfolioID=0$RelationShip=null`
          
      
          }
          this.pt_traker.executeActionPTService(obj).then(_ptdata=>{
            console.log("Suceess",_ptdata);
            
          }).catch(ee=>{
            console.log(ee);
            
          })
          
          // for (var i = 0; i < this.user_marketWatchData.length; i++) {
          //     if (this.user_marketWatchData[i].Template_Name.toUpperCase() == inputValue.toUpperCase()) {this.SetcreateMarketWatch = false;  break;}
          //     else {this.SetcreateMarketWatch = true; }
             
          // };

          // if (this.SetcreateMarketWatch === true) {
          //   if (this.ClientName === 'Canara') {
          //    this.marketWtName = inputValue;
          //    localStorage.setItem("mWatchName",this.marketWtName);
          //   }
          //     this.common.showLoading();
          //     //call saveMWatch service
          //     var qStringforSave = '{';
          //     qStringforSave += '"UserId":"' + this.userData.ClientCode + '",';
          //     qStringforSave += '"TemplateName":"' + inputValue + '",';
          //     qStringforSave += '"Exchange":"NSE",';
          //     //qStringforSave += '"TickersList":"' + "NSE.NIFTY 50^BSE.SENSEX" + '",';
          //     qStringforSave += '"TickersList":"' + "BSE.SENSEX" + '",';
          //     qStringforSave += '"ColumnsList":"Ind^LTP^BidQty^BidPrice^OfferPrice^OfferQty^LTQ",';
          //     qStringforSave += '"TriggersList":"BidPrice",';
          //     qStringforSave += '"AlertsFiltersList":"BidPrice",';
          //     qStringforSave += '"Font":"",';
          //     qStringforSave += '"DefaultMarketwatch":"1",';
          //     qStringforSave += '"DefaultGrid":"0"}';

          //     this.marketWatchManager.createMWatch(qStringforSave).then((data)=>{
          //       this.common.hideLoading();
          //       this.newMarketWatchCreatedData = data;
          //       if(this.newMarketWatchCreatedData.ErrorCode==0){
          //         swal({
          //           title: 'Saved',
          //           text: 'New Market Watch created.',
          //           type:'success',
          //           timer: 3000
          //         })
          //         this.navCtrl.push('MarketWatchPage',{useLogindata:this.userData});
          //       }else{
          //         swal({
          //           title: 'Error',
          //           text: 'Error in creating New Market Watch.',
          //           type:'error',
          //           timer: 3000
          //         })
          //       }
          //     },err=> {
          //       this.common.hideLoading();
          //       swal({
          //         title: 'Error',
          //         text: 'Error in creating New Market Watch.',
          //         type:'error',
          //         timer: 3000
          //       })
          //     });
          // } else {
          //     return 'Marketwatch Name already Exist!'
          // }
        }
      }
    })


//End of fun
 }
 name: string = '';
 name1: string = '';
 _timeout: any = null;

 serarchMe(){
 if(this._timeout){ //if there is already a timeout in process cancel it
  window.clearTimeout(this._timeout);
}
this._timeout = window.setTimeout(() => {
   this._timeout = null;
   this.lc.run(() =>{

   this.name1 = this.search_Cmpny
  console.log("Cmpany Name ",this.name1);
  // this.getSchemeDetailByISIN()
  let obj=
  {
    "ServiceName":"CompleteCompanySearch",
    "ParameterList":`SearchString=${this.name1}`
  

  }
  this.pt_traker.getPTServicesDownloadReport(obj).then(_ptdata=>{
    console.log("Suceess",_ptdata);
    if(_ptdata.ErrorCode==0)
    {
      console.log("Suceess",_ptdata);
      this.companyLists=_ptdata.DataSet.Table;
    }
  }).catch(ee=>{
    console.log(ee);
    
  })
  });
},1000);
 }

 selectCmpny(item)
 {
   console.log(item);
   
this.company_details=item;
this.companyLists=[];
this.portfolio_form.script_name=item.ShortCompanyName;


 }

 getEquityPrice()
 {
   console.log("Equity Price",this.portfolio_form)
   console.log("company details",this.company_details);
  let obj= {
    "ServiceName":"GetEquityPrice",
   "ParameterList":`SecurityType=Stock$Exchange=${this.portfolio_form.transaction_type}$SecurityCode=${this.company_details.SecurityCode}
   $PriceDate=${this.portfolio_form.transaction_date}`
   }
   console.log(obj);
   this.pt_traker.getPTServicesDownloadReport(obj).then(_ptdata=>{
    // console.log("Suceess",_ptdata);
    if(_ptdata.ErrorCode==0)
    {
      console.log("Suceess",_ptdata);
      if(this.portfolio_form.exchange_name=='BSE')
      this.portfolio_form.price=_ptdata.DataSet.Table[0].SensexPrice;
      else
      this.portfolio_form.price=_ptdata.DataSet.Table[0].NiftyPrice; 
      // this.companyLists=_ptdata.DataSet.Table;
    }
  }).catch(ee=>{
    console.log(ee);
    
  })
 }

 addInvestment()
 {
 let obj= {"ServiceName":"AddEquityTransaction",
  "ParameterList":`LoginID=${this.userData.ClientCode}$AccountID=${this.portfolio_form.portfolio_list}$SecurityType=EQ$SecurityCode=${this.company_details.SecurityCode}$DateOfTransaction=${this.portfolio_form.transaction_date}$TypeOfTransaction=${this.portfolio_form.transaction_type}$Exchange=${this.portfolio_form.exchange_name}$Quantity=${this.portfolio_form.units}$Price=${this.portfolio_form.price}$BrokerCommission=0$AverageBuyPrice=0$BrokerName=$Remarks=`
  // 
  // LoginID=${this.userData.ClientCode}
  // $AccountID=${this.portfolio_form.portfolio_list}
  // $SecurityType=EQ
  // $SecurityCode=${parseFloat(this.company_details.SecurityCode)}
  // $DateOfTransaction=${this.portfolio_form.transaction_date}
  // $TypeOfTransaction=${parseInt(this.portfolio_form.transaction_type)}
  // $Exchange=${this.portfolio_form.exchange_name}
  // $Quantity=${parseInt(this.portfolio_form.units)}
  // $Price=${parseFloat(this.portfolio_form.price)}
  // $BrokerCommission=${0}
  // $AverageBuyPrice=${0}
  // $BrokerName=
  // $Remarks=`
  
  }
  
  console.log("Investment obj",obj);
  
  
  this.pt_traker.executeActionPTService(obj).then((_ptdata:any)=>{
    console.log("Suceess>>>>>>>>>>>>",_ptdata);
    if(_ptdata.ErrorCode==0)
    {
              swal({
                    title: 'Saved',
                    text: 'Successfully created.',
                    type:'success',
                    timer: 3000
                  })
                  this.navCtrl.pop().catch(err=>{
                    console.log(err);
                    
                  })
    }else{
      swal({
        title: 'Error',
        text: 'Please try again.',
        type:'error',
        timer: 3000
      })
    }
  }).catch(ee=>{
    console.log(ee);
    swal({
      title: 'Error',
      text: 'Please try again.',
      type:'error',
      timer: 3000
    })
  })


 }

 getEquityTransactions()
 {
  //  let obj={
  //    "ServiceName":"GetEquityTransactions",
  //    "ParameterList":`LoginID=${this.userData.ClientCode}$AccountID=${this.portfolio_form.portfolio_list}$StartDate=${}$EndDate=${}$SecurityCode=${}`

  //  }
 }

 addDerivatives()
 {

 }


 getDerivativeInstrumentList()
 {
  let obj={
       "ServiceName":"GetDerivativesInstrumentList",
      //  "ParameterList":`LoginID=${this.userData.ClientCode}$AccountID=${this.portfolio_form.portfolio_list}$StartDate=${}$EndDate=${}$SecurityCode=${}`
  
     }
     this.pt_traker.getPTServicesDownloadReport(obj).then(list_data=>{
       if(list_data.ErrorCode==0)
       {
this.InstrumentLists=list_data.DataSet.Table;
       }
     })
 }

 getSelectedInstrument(event)
 {
console.log("Event",event)
let obj={
  "ServiceName":"DerivativesGetSymbol",
  "ParameterList":`Instrumentname=${event}`

}
this.pt_traker.getPTServicesDownloadReport(obj).then(list_data=>{
  // if(list_data.ErrorCode==0)
  // {
this.SymbolList=list_data.DataSet.Table;
  // }
})
 }

 getSelectedSymbol(event)
 {
console.log("Event",event)
this.selectCmpny(event)
let obj={
  "ServiceName":"DerivativesGetExpiryDate",
  "ParameterList":`Instrumentname=${this.portfolio_form.instrument}$Symbol=${event.symbol}`

}
console.log();

this.pt_traker.getPTServicesDownloadReport(obj).then(list_data=>{
  // if(list_data.ErrorCode==0)
  // {
this.ExpiryDateList=list_data.DataSet.Table;
console.log("Expirydatae lsit",this.ExpiryDateList);

  // }
})
 }

 getSelectedExpiryDate(event)
 {
  let obj={
    "ServiceName":"GetCurrencyInstrumentDetails",
    "ParameterList":`Type=OT$InstrumentType=${this.portfolio_form.instrument}$ScriptCode=EURINR$ExpiryDate=${event}`
  
  }
  console.log(obj);
  
  this.pt_traker.getPTServicesDownloadReport(obj).then(list_data=>{
    // if(list_data.ErrorCode==0)
    // {
  this.OptionList=list_data.DataSet.Table;
  console.log("Option lsit",this.OptionList);
  
    // }
  })
 }

 getSelectedOption(event)
 {
  let obj={
    "ServiceName":"GetCurrencyInstrumentDetails",
    "ParameterList":`Type=P$InstrumentType=${this.portfolio_form.instrument}$ScriptCode=EURINR$ExpiryDate=${this.portfolio_form.expiry_date}$OptionType=${event}`
  
  }
  console.log(obj);
  
  this.pt_traker.getPTServicesDownloadReport(obj).then(list_data=>{
    // if(list_data.ErrorCode==0)
    // {
  this.strikePriceList=list_data.DataSet.Table;
  console.log("Option lsit",this.strikePriceList);
  
    // }
  })
 }

 addDerivative()
 {
 let obj= {"ServiceName":"AddDrivativesFuturesTransaction",
  "ParameterList":`LoginID=${this.userData.ClientCode}$AccountID=${this.portfolio_form.portfolio_list}$SecurityCode=${this.portfolio_form.symbol.SecurityCode}$ExpiryDate=${this.portfolio_form.expiry_date}$TypeOfTransaction=${this.portfolio_form.transaction_type}$Exchange=${this.portfolio_form.exchange_name}$Quantity=${this.portfolio_form.units}$Price=${this.portfolio_form.price}$BrokerCommission=0$AverageBuyPrice=0$BrokerName=$Remarks=`
 }
}
    }