import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { PlaceorderManagerProvider } from '../../providers/placeorder-manager/placeorder-manager';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
// import { IonicSelectableComponent } from 'ionic-selectable'/;



@IonicPage()
@Component({
  selector: 'page-add-mandate',
  templateUrl: '../../pages/Bgse/add-mandate/add-mandate.html',
})
export class AddMandatePage {
  public ClientParam: any;
  public bankdetail_result: any;
  public bankdetail: any;
  public errmsg: any;
  public AccountNo: any;
  public Branch: any;
  public IFSC: any;
  public Bank_name: any;
  public Amount: any;
  public Mandatetype: any;
  public MandateMode: any;
  public bankId: any;
  private todo: FormGroup;

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddMandatePage');

  }

  constructor(
    public navCtrl: NavController,
    public globalVar: GlobalVariableService,
    private common: CommonProvider,
    private placeorderManager: PlaceorderManagerProvider,
   private formBuilder: FormBuilder,
  ) {
    this.bankdetail = [];
    this.getbankdata();
    this.todo = this.formBuilder.group({
      bankname: ['', Validators.required],
      mandatetype: ['', Validators.required],
      mandatemode: ['', Validators.required],
      amount: [null, Validators.required],
    });
  }

  logForm() {
    console.log(this.todo.value)
  }

  setBackButtonAction(){
        // this.navCtrl.push('MandateRegisterationPage');
        this.navCtrl.pop();
  }

  getbankdata() {
    let userId = this.globalVar.userId.toString();

    this.ClientParam = {
      UserId: userId,
      ReportName: "GetBanks",
    };
    this.common.showLoading();
    this.placeorderManager.getBankDetails(this.ClientParam).then((data) => {
      this.bankdetail_result = data;
      this.common.hideLoading();
      if (this.bankdetail_result.ErrorCode == '0') {
        let Data = this.bankdetail_result.ReportTable;
        this.bankdetail = JSON.parse(Data);
        console.log("bank", this.bankdetail);
      }
      else {
        this.errmsg = this.bankdetail_result.Message;

      }
    }, err => {
      this.errmsg = 'Connection Error. Check Your Internet Connection / Contact Administrator.';
      console.log("err" + err)
      this.common.hideLoading();
    });
  }


  getbankdataOld() {
    let userId = this.globalVar.userId.toString();

    this.ClientParam = {
      UserId: userId,
      ReportName: "GetBanks",
    };
    this.common.showLoading();
    this.placeorderManager.getBankDetails(this.ClientParam).then((data) => {
      this.bankdetail_result = data;
      this.common.hideLoading();
      if (this.bankdetail_result.ErrorCode == '0') {
        let Data = this.bankdetail_result.ReportTable;
        var bankDetailData = JSON.parse(Data);
        if (bankDetailData.length > 0) {
        // this.bankdetail = JSON.parse(Data);
        // console.log("bank", this.bankdetail);
        var uniqueBankAcc = [];
       // this.BankDetail = bankDetailData.filter((x, i, a) => x && a.indexOf(x) === i);
       for(let x = 0; x < bankDetailData.length ; x++) {
         if(uniqueBankAcc.indexOf(bankDetailData[x].vcAccountNo) === -1){
           uniqueBankAcc.push(bankDetailData[x].vcAccountNo);
           this.bankdetail.push(bankDetailData[x]);
         }
       }
     }

       // for(let x = 0; x< bankDetailData.length; x++) {
       //   if(uniqueBankAcc.indexOf(bankDetailData[x].vcAccountNo) === -1){
       //     uniqueBankAcc.push(bankDetailData[x].vcAccountNo);
       //     this.BankDetail.push(bankDetailData[x]);
       //   }
       // }
      }
      else {
        this.errmsg = this.bankdetail_result.Message;
        swal({
          title: 'OOPS!',
          text: this.errmsg,
          type: "error"
        });

      }
    }, err => {
      this.errmsg = 'Connection Error. Check Your Internet Connection / Contact Administrator.';

      swal({
        title: 'OOPS!',
        text: this.errmsg,
        type: "error"
      });

      console.log("err" + err)
      this.common.hideLoading();
    });
  }

  getbankdetails(bankid) {
    this.Bank_name = this.bankdetail.find(x => x.inUserBankId == bankid).BankName;
    this.AccountNo = this.bankdetail.find(x => x.inUserBankId == bankid).vcAccountNo;
    this.Branch = this.bankdetail.find(x => x.inUserBankId == bankid).vcBankBranch;
    this.IFSC = this.bankdetail.find(x => x.inUserBankId == bankid).vcIFSC;
  }

  updatemandateform() {
    let clientName = this.globalVar.clientId;
    this.ClientParam = {
      ClientCode: clientName,
      ClientName: '',
      Amount: this.Amount,
      Status: "235",
      Remarks: "",
      MandateType: this.Mandatetype,
      MandateMode: this.MandateMode,
      Branch: this.Branch,
      AccountNumber: this.AccountNo,
      IFSCCode: this.IFSC,
      RequestedBy: clientName,
      BankName: this.Bank_name,
    };
    if (this.Amount.toString().length > 10) {
      this.common.showAlert("Please enter maximum 10 digit in amount !");
      return false;
    }
    this.common.showLoading();
    this.placeorderManager.updatemandate(this.ClientParam).then((data) => {
      this.bankdetail_result = data;
      this.common.hideLoading();
      if (this.bankdetail_result.ErrorCode == '0') {
        this.errmsg = this.bankdetail_result.Message;
        if(this.bankdetail_result.StatusCode==100)
        {
        swal({
          title: "Success!",
          text: 'Mandate added successfully',
          type: 'success'
        });
      }
      else{
        swal({
          title: "OOPS!",
          text: this.errmsg,
          type: "error"
        });

      }

        // this.bankId = "";
        // this.Mandatetype = [];
        // this.MandateMode = [];
        // this.Amount = "";
        // this.bankdetail = [];

        // this.navCtrl.push("MandateRegisterationPage");
        this.setBackButtonAction()
      }
      else {
        this.errmsg = this.bankdetail_result.Message;
        swal({
          title: "OOPS!",
          text: this.errmsg,
          type: "error"
        });
        // this.navCtrl.push("MandateRegisterationPage");
        this.setBackButtonAction()
      }
    }, err => {
      this.common.hideLoading();
      this.errmsg = 'Connection Error. Check Your Internet Connection / Contact Administrator.';
      swal({
        title: "OOPS!",
        text: this.errmsg,
        type: "error"
      });
      console.log("err" + err)
    });
  }

}
