import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddMandatePage } from './add-mandate';
import { IonicSelectableModule } from 'ionic-selectable';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    AddMandatePage,
  ],
  imports: [
    IonicPageModule.forChild(AddMandatePage),
    IonicSelectableModule,SharedModule
  ],
})
export class AddMandatePageModule {


}
