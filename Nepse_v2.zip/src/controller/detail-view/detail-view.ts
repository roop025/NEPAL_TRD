import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import swal from 'sweetalert2';
import { PlaceorderManagerProvider } from '../../providers/placeorder-manager/placeorder-manager';


@IonicPage()
@Component({
  selector: 'page-detail-view',
  templateUrl: '../../pages/DionBlack/detail-view/detail-view.html',
})
export class DetailViewPage {
  public DetailParam: any;
  public DetailData: any;
  public report1: any;
  public assestallocation: any;
  public performanceArr: any;
  public detaildata_result: any;
  public topsector: any;
  public topholding:any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public globalVar: GlobalVariableService,
    private common: CommonProvider,
    private placeorderManager: PlaceorderManagerProvider
  ) {
    this.report1 = [];
    this.performanceArr = [];
    this.assestallocation = [];
    this.topsector = [];
    this.topholding=[];
    this.DetailParam = this.navParams.get('Investpostdata');
    let clientName = this.globalVar.clientId;
    this.DetailData = {
      RequestedBy: clientName,
      ReportName: "SchemeSearch",
      ResponseType: "2",
      Filter1: "SingleContent",
      SchemeType: this.DetailParam.SchemeType1,
      ContentCode: this.DetailParam.ContentCode,
      AmcCode: "-1"

    };

    this.loaddetailsview();

  }

  ionViewDidLoad() {

  }

  loaddetailsview() {
    this.common.showLoading();
    this.placeorderManager.getInvestmentSuggestion((this.DetailData)).then((data) => {
      this.detaildata_result = data;
      this.common.hideLoading();
      if (this.detaildata_result.ErrorCode == '0') {
        this.performanceArr = this.detaildata_result.ReportTable4;
        this.assestallocation = this.detaildata_result.ReportTable3;
        this.topsector = this.detaildata_result.ReportTable2;
        this.topholding = this.detaildata_result.ReportTable1;
        this.report1 = JSON.parse(JSON.stringify(this.detaildata_result.ReportTable))[0];
        // console.log("mydata", this.topholding);
      }
      else {

        swal({
          title: "OOPS!",
          text: this.detaildata_result.Message,
          type: "error"
        });
      }
    }, err => {
      this.common.hideLoading();
      swal({
        title: 'OOPS!',
        text: 'Connection Error. Check Your Internet Connection / Contact Administrator.',
        type: "error"
      });
      // this.common.hideLoading();
    });
  }
}
