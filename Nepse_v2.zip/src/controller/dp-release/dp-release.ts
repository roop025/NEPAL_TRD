import { Component } from '@angular/core';
import { NavController , IonicPage,Events } from 'ionic-angular';
import { NgProgress } from 'ngx-progressbar';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { MarketWatchProvider } from '../../providers/market-watch/market-watch';
import swal from 'sweetalert2';
import { Storage } from '@ionic/storage';
import { ReportProvider } from '../../providers/report/report';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { WebsocketUtilityService } from '../../util/webSocketUtility';

import { CommonProvider } from '../../providers/common/common';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';

@IonicPage()
@Component({
  selector: 'page-dp-release',
  templateUrl: '../../pages/DionBlack/dp-release/dp-release.html'
})

export class DpReleasePage {

  public progressBarColor : any;
  public userData : any;
  public netPosition_result : any;
  public items : any;
  public message : any;
  public spreadType : any;
  public m2m : any;
  public bpl : any;
  public filterargs : any;
  public ClientName : any;
  public negativeVal : any;
  public ticker_result : any;
  public footerTickerData : any;
  private logoutFrmData : any;
  private   user_logout_result: any = '';
  shownGroup = null;

  constructor(public navCtrl: NavController,
    public ngProgress: NgProgress,
    private globalVariableService : GlobalVariableService,
    public getReportManager : ReportProvider,
    public websocketUtilityManager: WebsocketUtilityService,
    public socket: WebsocketProvider,
    private marketWatchManager:MarketWatchProvider,
    private storage:Storage,
    private common:CommonProvider,
    private userManager:UserManagerProvider,
    private ev:Events
  ) {
    this.m2m=0.00;
    this.bpl=0.00;

    this.ev.subscribe('checkFilterArgument',data=>{
      //alert(data.indexSel)
      if(data.indexSel == "Exchange"){
        this.filterargs = {exchange: data.valueSel};
      }else if(data.indexSel == "Scrip"){
        this.filterargs = {underlying: data.valueSel};
      }else if(data.indexSel == "TradingAccount"){
        this.filterargs = {TradingAccount: data.valueSel};
      }else if(data.indexSel == "Status"){
        this.filterargs = {OrderStatus: data.valueSel};
      }else if(data.indexSel == "BuySellType"){
        this.filterargs = {BuySellType: data.valueSel};
      }
      else{
        this.filterargs = {all: data.valueSel};
      }
    });
    //---Set page name as orderbook--
    this.globalVariableService.setPageName({currentPageName:"NetPositionPage"});
    this.ClientName = globalVariableService.clientName;
  }

  ionViewDidLoad(){
    //this.negativeVal=false;
    //console.log("test from login")
    this.storage.get("userMaster").then((data)=>{
       if(data!=null && data!=''){
         this.userData = data;
       }
       //---Load net position --
       this.loadNetPosition();
    });

  }

  loadNetPosition(){
    this.progressBarColor = 'white'
    this.ngProgress.start();
    this.getReportManager.getScripOrderReport("ALL","NetPosition",this.userData,"").then((data)=>{
      this.ngProgress.done();
      this.netPosition_result = data;
      if(this.netPosition_result.reportTable=="" || this.netPosition_result.reportTable==null){
        this.items = '';
        this.message=this.netPosition_result.Message
      }else{
        this.items = JSON.parse(this.netPosition_result.reportTable);
        // console.log("this.orderitems",this.items)
        //---call function to identify underlying,expiry,option and strike
        this.items.forEach((value, index) => {
          this.computeScripDetails(value, index);
          //console.log("value",value)
          if(value.OpenPosition=='B'){
            this.items[index].M2M=(value.LTP-value.OpenPrice)*value.OpenQuantity*value.ContractSize
          }else{
            this.items[index].M2M=(value.OpenPrice-value.LTP)*value.OpenQuantity*value.ContractSize
          }
        });
        this.m2m=0
        this.bpl=0
        this.items.forEach((value, index) => {
          this.items[index]["exchange"]=this.items[index].Exchange;
          this.items[index]["ticker"]=this.items[index].underlying;
          this.globalVariableService.setData({ watchlistItems: this.items });

          //---Calculation of M2M and BPL--
          this.m2m += parseFloat(value.M2M);
          this.bpl += parseFloat(value.BPL);

        });
        this.getSpecifiedQuoteValue(this.items);
        //----With ltp calculation from getSpecified Quote ---
        var ScripCode = "";
        var scripList = "";
        var i = 0;
        var counter = 0;
        this.items.forEach((value, index) => {
          var ScripExchange = value.Exchange;
          var data = '';
          if (ScripExchange !== '') {
              scripList = scripList + ScripExchange + '.' + value.ContractName + '^';
              counter = counter + 1;
          }

        });
        //console.log("scriplist from net position-->", scripList);
        var indexData;
        this.marketWatchManager.listTicker(scripList).then((data)=>{
          this.ticker_result = data;
          //----Successfully loaded market watch list ---
          if(this.ticker_result.ErrorCode == '0'){
            this.footerTickerData = JSON.parse(this.ticker_result.data);
            indexData = JSON.parse(this.ticker_result.data);
            //console.log("this.footerTickerData",this.footerTickerData)

            this.items.forEach((value, index) => {
              this.footerTickerData.forEach((value1, index1) => {
                if(value.ContractName==value1.ticker){
                  //console.log("value1",value1);
                  //console.log("value",value);
                  this.items[index].LTP=value1.LTP;
                  if(value.OpenPosition=='B'){
                    this.items[index].M2M=(value.LTP-value.OpenPrice)*value.OpenQuantity*value.ContractSize
                  }else{
                    this.items[index].M2M=(value.OpenPrice-value.LTP)*value.OpenQuantity*value.ContractSize
                  }
                }
              });
            });
          }else{//----Market watch does not loaded--

          }
        }, err=> {
          // this.common.hideLoading();
        });
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      this.progressBarColor = 'Red'
      this.ngProgress.done();
    });

  }
  totalCounts(data) {
    let total = 0.00;
    data.forEach((d) => {
      total += parseFloat(d.M2M);
      //total += d.M2M;
      if(total<0){
        this.negativeVal=true
      }else{
        this.negativeVal=false;
      }
    });
    return total;
  }
  //---Calculate LTP and subscribe to feed ---
  getSpecifiedQuoteValue(tickersItemsObj){
    var scripList = "";
    var counter = 0;
    tickersItemsObj.forEach((value, index) => {
      var ScripExchange = value.Exchange;
      var ticker = value.ContractName.toUpperCase();
      if (ScripExchange !== '') {
          scripList = scripList + this.GetExchangeCode(ScripExchange) + '.1!' + ticker + '^';
          counter = counter + 1;
      }
    });
    var keylist = "";
    keylist = 'ADD^' + counter + '^' + scripList;
    //---Service to connect with the websocket --
    this.socket.connect();
    this.socket.send(keylist.toUpperCase());
    this.websocketUtilityManager.getFeedAfterSubscribe(this.items,'DPRelease').then((data)=>{
      //this.webSocket_Data =data;
      //console.log("this.webSocket_Data--",this.webSocket_Data.config)
    })

  }
  //--Square Of Order --
  squareOfOrder(item){
    //console.log("item->",item)
    item.ticker=item.Scrip;
    item.exchange=item.Exchange;
    if (item.OpenPosition == "B") {
      this.globalVariableService.setQuoteHeaderData({ quoteItem: item });
      this.navCtrl.push('SellPage',{usersellData:item,clientUserData:this.userData,isSquareOfOrder:true});
    } else {
      this.globalVariableService.setQuoteHeaderData({ quoteItem: item });
      this.navCtrl.push('BuyPage',{userbuyData:item,clientUserData:this.userData,isSquareOfOrder:true});
    }
  }
  //--Convert Order --
  convertOrder(item){
    var ProductType = this.userData.TradingAccountExchangeList.split('^');
    var ProductTypeList = '';
    for (var i = 0; i < ProductType.length; i++) {
        if (ProductType[i].split('$')[0] == item.exchange) {
            ProductTypeList = ProductType[i].split('$')[1];
            //ExchangePermit = 1;
            break;
        }
    }
    var ProductTerms = ProductTypeList.split('|')[1].split('~');
    if(ProductTerms.length == 1){
      //---No product conversion allowed since no other trading account allocated.
      swal({
          text: "Product conversion not allowed.No other trading account available for product conversion.",
          showConfirmButton: true
      });
    }else{
      this.globalVariableService.setQuoteHeaderData({ quoteItem: item });
      // this.ev.publish('fromOrderTradeBook',{formatValue:true});
      //console.log("userConvertData",item)
      this.navCtrl.push('ConvertPage',{userConvertData:item,clientUserData:this.userData});
    }

  }
  //--- Computer Scrip details ---
  computeScripDetails(value, index){
    var tickertype = 'EQT';
    var ScripExchange = value.Exchange;
    var ticker = value.Scrip;

    //---identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
    if (ticker.search("~") > 0) {
        tickertype = 'FUT';
        if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
            tickertype = 'OPT';
        }
        if (ticker.search("~S") > 0) {
            tickertype = 'SPD';
        }
    } else {
        tickertype = 'EQT';
    }

    this.items[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

    if (tickertype == 'EQT') {
        this.items[index].underlying = ticker.toUpperCase();
        this.items[index].optType = '';
        this.items[index].strikePrice = '';
    }
    if (tickertype == 'FUT') {
        this.items[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.items[index].optType = 'F';
        this.items[index].strikePrice = '';
        this.items[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'OPT') {
        this.items[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.items[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
        this.items[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
        this.items[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'SPD') {
        this.items[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
        this.items[index].optType = 'S';
        this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
        this.items[index].ExpiryDate = '';
        this.items[index].strikePrice = this.spreadType.split("~")[0];
    }
  }
  //--- Get exchange legend --
  GetExchangeLegend(Exchange){
    var strCode = "";
    switch (Exchange) {
        case "NSE":
            strCode = "N";
            break;
        case "BSE":
            strCode = "B";
            break;
        case "FOBSE":
            strCode = "B";
            break;
        case "CDBSE":
            strCode = "B, CU";
            break;
        case "FONSE":
            strCode = "N";
            break;
        case "ACE":
            strCode = "A";
            break;
        case "CDNSE":
            strCode = "N, CU";
            break;
        case "MCX":
            strCode = "M";
            break;
        case "COMNSE":
            strCode = "COM";
            break;
        case "NCDEX":
            strCode = "X";
            break;
        case "MCXSX":
            strCode = "M, CU";
            break;
        case "NSEL":
            strCode = "NS";
            break;
        case "MCXSXEQ":
            strCode = "M, EQ";
            break;
        case "MCXSXFO":
            strCode = "M, FO";
            break;
    }
    return (strCode);
  }

  //---//--pull down to refresh --
  doRefresh(refresher) {
    this.loadNetPosition()
    setTimeout(() => {
      refresher.complete();
    }, 1000);
  }


    /*set exchange code in order to build keylist to register for feed.*/
    GetExchangeCode(Exchange) {
        var strCode = "0";
        switch (Exchange) {
            case "NSE":
            case "FONSE":
                strCode = "4";
                break;
            case "BSE":
            case "FOBSE":
                strCode = "1";
                break;
            case "ACE":
                strCode = "10";
                break;
            case "CDNSE":
                strCode = "13";
                break;
            case "MCX":
                strCode = "7";
                break;
            case "COMNSE":
                strCode = "5";
                break;
            case "NCDEX":
                strCode = "8";
                break;
            case "MCXSX":
                strCode = "14";
                break;
            case "NSEL":
                strCode = "36";
                break;
            case "MCXSXEQ":
                strCode = "64";
                break;
            case "MCXSXFO":
                strCode = "65";
                break;
            case "CDBSE":
                strCode = "17";
                break;
        }
        return (strCode);
    }
    toggleGroup(group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
        } else {
            this.shownGroup = group;
        }
      };
      isGroupShown(group) {
        return this.shownGroup === group;
      };
}
