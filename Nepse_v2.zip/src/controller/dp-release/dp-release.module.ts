import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DpReleasePage } from './dp-release';
import {PipesModule} from '../../pipes/pipes.module';
import { NgProgressModule } from 'ngx-progressbar';
import {SharedModule} from '../../app/shared-components.module';

@NgModule({
  declarations: [
    DpReleasePage,
  ],
  imports: [
    PipesModule,
    SharedModule,
    NgProgressModule,
    IonicPageModule.forChild(DpReleasePage),
  ],
})
export class DpReleasePageModule {}
