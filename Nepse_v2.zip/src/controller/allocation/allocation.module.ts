import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AllocationPage } from './allocation';
// import { SearchPipe }from '../../pipes/search/search';

@NgModule({
  declarations: [
    AllocationPage,
  ],
  imports: [
    IonicPageModule.forChild(AllocationPage),
  ],
})
export class AllocationPageModule {}
// SearchPipe
