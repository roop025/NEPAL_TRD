import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { PlaceorderManagerProvider } from '../../providers/placeorder-manager/placeorder-manager';
import { Http } from '@angular/http';
import swal from 'sweetalert2';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { RequestManagerProvider } from "../../providers/request-manager/request-manager";


@IonicPage()
@Component({
    selector: 'page-allocation',
    templateUrl: '../../pages/Bgse/allocation/allocation.html',
})
export class AllocationPage {
    public popovershow: boolean = false;
    public holdinglist: any;
    public pagelist: any;
    public HoldingParam: any;
    public holdingreport_result: any;
    public errmsg: any;
    private showNoData: any;
    public allocationData:any;
    public result_table_4:any;
    public result_table_5:any;
    public result_table_6:any;
    public result_table_7:any;
    public result_table_3:any[]=[]

    shownGroup = null;
    constructor(public navCtrl: NavController,
                public navParams: NavParams,
                public globalVar: GlobalVariableService,
                private common: CommonProvider,
                private placeorderManager: PlaceorderManagerProvider,
                public http: Http,
                private menu: MenuController,
                private userManager: UserManagerProvider,
                public requestManager:RequestManagerProvider,
              )
     {
        this.menu.enable(true);
        this.holdinglist = [];
        this.showNoData= false;
        // this.getHoldingReports();
        this.pagelist = [ { text: "Purchase", value: "AP" }, { text: "ISIP", value: "ISIP" }, { text: "XSIP", value: "XSIP" }, { text: "SIP", value: "SIP" }, { text: "Redeem", value: "R" }, { text: "Switch", value: "SWITCH" }, { text: "STP", value: "STP" }, { text: "SWP", value: "SWP" }];
        // this.pagelist = [{ text: "Additional Purchase", value: "AP" },  { text: "Switch", value: "SWITCH" }, { text: "Redeem", value: "R" },{ text: "ISIP", value: "ISIP" }, { text: "XSIP", value: "XSIP" }, { text: "STP", value: "STP" }, { text: "SWP", value: "SWP" },];
        this.allocationData = this.globalVar.getAllocationObj();
        //console.log("this.allocationData");
        console.log(">>>>..",this.allocationData);
        if(this.allocationData != null || this.allocationData != undefined){
          this.result_table_3 = this.allocationData.ReportTable3;
          this.result_table_4 = this.allocationData.ReportTable4;
          this.result_table_7 = this.allocationData.ReportTable7;
          this.result_table_6 = this.allocationData.ReportTable6;

        }


    }

    ionViewDidLoad() {


      return new Promise((resolve, reject) =>{
        this.requestManager.getSession().subscribe(data =>{
         console.log("data",data);
        if(data.ErrorCode == 0){
          // this.requestManager.post('BSEStarMFServices.DownloadReport', investmentRequestObj, "BSEStarMFAPI")
          // .subscribe(data =>{
            resolve(data);
          // }, err=>{
          //   reject(err);
          // })
        }
         else{
          this.common.logOutFromSessionOut();
        }
      })
    })



    }

    show() {
        this.popovershow = !this.popovershow;
    }


// Accordian method here

      toggleGroup(group) {
      if (this.isGroupShown(group)) {
        this.shownGroup = null;
      } else {
        this.shownGroup = group;
      }
      };

      isGroupShown(group) {
      return this.shownGroup === group;
      };


    search(ev: any) {
        this.holdinglist.filter(function (item) {
            console.log("search", item);
        });
    }


}
