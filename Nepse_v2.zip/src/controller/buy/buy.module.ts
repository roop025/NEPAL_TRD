import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BuyPage } from './buy';
import {SharedModule} from '../../app/shared-components.module';
import {PipesModule} from '../../pipes/pipes.module';


@NgModule({
  declarations: [
    BuyPage
  ],
  imports: [
    SharedModule,
    PipesModule,
    IonicPageModule.forChild(BuyPage),
  ],
})
export class BuyPageModule {}
