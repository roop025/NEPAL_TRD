import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, IonicPage, NavParams, Content, Navbar, Events, ToastController, ViewController, ModalController } from 'ionic-angular';
import swal from 'sweetalert2';
import { BuySellProvider } from "../../providers/buy-sell/buy-sell";
import { ExchangeInformationProvider } from "../../providers/exchange-information/exchange-information";
import { CommonProvider } from '../../providers/common/common';
import { GlobalVariableService } from '../../providers/common/global-variable';
import { WebsocketProvider } from '../../providers/websocket/websocket';
import { Storage } from '@ionic/storage';
import { UserManagerProvider } from '../../providers/user-manager/user-manager';
import { WebsocketUtilityService } from '../../util/webSocketUtility';
import { ReportProvider } from '../../providers/report/report';
@IonicPage()
@Component({
    selector: 'page-buy',
    templateUrl: '../../pages/DionWhite/buy/buy.html'
})

export class BuyPage {
    @ViewChild(Content) content: Content;
    @ViewChild(Navbar) navBar: Navbar;
    @ViewChild("messageInput") public messageInput: ElementRef;
    @ViewChild("quantityField") public quantityField: ElementRef;
    @ViewChild("qtyInput") public qtyInput: ElementRef;
    @ViewChild("przInput") public przInput: ElementRef;


    public item: any;
    public clientUserData: any;
    public showDisclosedQty: any;
    public AUTOAMS: any;
    public tickertype: any;
    public isIndex: any;
    public ExpiryDateString: any;
    public getExpiry_result: any;
    public scripSetExpiry: any;
    public orderObject: any;
    public buttonText: any;
    public showSwitch: any;
    public showLot: any;
    public lotSize: any;
    public AMOallowed: any;
    public getSpecifiedQuote_result: any;
    public exchange: any;
    public ProductTypeItems: any;
    public formatedTicker: any;
    public ProductTypeitem: any;
    public Price: any;
    public NewOrderCategory: any;
    public orderTermSelected: any;
    public lotSize_result: any;
    public companyInfo_result: any;
    public ViewlotSize: any;
    public TickSize: any;
    public exchangeInfo_result: any;
    public ExchangeStatusFullList: any;
    public showAdvanceOptions: any;
    public OrderTypeOptions: any;
    public checkboxModel: any;
    public showPriceForLimitOrder: any;
    public products: any;
    public productTypeSelected: any;
    public orderTerms: any;
    public defaultTradingAccount: any;
    public showGTDDate: any;
    public showDiscolosed: any;
    public amoOrder: any;
    public checkboxModelrlsl: any;
    public numlenValue: any;
    public myvalueformated: any;
    public checkTckSize: any;
    public place_order_result: any;
    public alerttext: any;
    public isModData: any;
    public itemMod: any;
    public isSquareOffOrderData: any;
    public disablePlusButton: any;
    public msg: any;
    public showTriggerPrice: any;
    public isVoiceSearchOrderData: any;
    public itemFromSearch: any;
    public previousPage: any;
    public margin_report_result: any;
    public originalModifyData: any;
    public showTriggerPriceToggle: any;
    public amoOrderFromModify: any;
    public amo: any;
    public isMarginPlusOrder: any;
    public ClientName: any;
    public prvPage: any;
    public orderobj:any;
    public activeAction:any ='D';
    public depthdata: any;
    public webSocket_Data:any;
    public keylist:any;
    public upperCrcut: any;
    public lowerCrcut: any;
    public avlBalance: any;
    public popupData:any;
    public userData:any;
    public marginReport_result:any;
    public myCollateral:any;

    public lowLTP: any;
    public highLTP: any;

    public sellFromHoldings : any;
    public sellFromHoldingsQty : any;
    public defaultSourceAccount : any;
    public isSelected:any = 'Trade'
    public filter: any = [];




    public items:any;
    public itemTR:any;
    public spreadType:any;
    public cancelBtnFlg:any;
    public isRecord:any = ''
    public shownGroup = null;
    public cancelOrderObject : any;
    public inProcessOrder:any;
    public cancel_order_result:any;
    public order: boolean = false;






  // public delivery_flag:any;

    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        public buySellManager: BuySellProvider,
        private commonService: CommonProvider,
        private clientMarketWatchList: GlobalVariableService,
        public socket: WebsocketProvider,
        public exchangeInfoManager: ExchangeInformationProvider,
        private ev: Events, public storage: Storage,
        private userManager: UserManagerProvider, public toast: ToastController,
        public websocketUtilityManager: WebsocketUtilityService,
        public getReportManager: ReportProvider,public viewCtrl: ViewController,
        public modalCtrl: ModalController,

    ) {
        this.showAdvanceOptions = false;
        this.showGTDDate = false;
        this.isMarginPlusOrder = false;
        this.amoOrderFromModify = true;
        this.OrderTypeOptions = [
            { value: "LMT", id: 1, TagType: 'L' },
            { value: "MKT", id: 2, TagType: 'M' }
        ];
        this.checkboxModel = { value: 'LMT' }
        this.orderObject = {
            Quantity: ''
        }
        this.products = {
            availableOptions: []
        }
        this.orderTerms = [];
        this.defaultTradingAccount = {
            TradingAccount: ''
        }
        this.disablePlusButton = false;
        this.showTriggerPrice = false;

        this.previousPage = this.clientMarketWatchList.getPageName().currentPageName
        this.clientMarketWatchList.setPageName({ currentPageName: "BuyPage" });
        this.ClientName = clientMarketWatchList.clientName;

        // console.log(' this.previousPage', this.previousPage);
        this.orderobj = { mode:'CONTINUOUS', price : '', qty: 0.00,prodType:'CNC',validity:'validity',orderType:'LMT' }
        this.item = this.navParams.get('userbuyData');
        this.activeAction = this.navParams.get('selectedBTN');
        this.sellFromHoldings = this.navParams.get('fromHoldings');
        this.item = this.item? this.item : this.navParams.get('usersellData');

        // this.products.availableOptions=[];
        this.depthdata = [
            {
              "Ticker": "", "DateTime": "", "depth":
                [
                  { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
                  { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
                  { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
                  { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" },
                  { "BBR": "", "BBQ": "", "BO": "", "BSR": "", "BSQ": "", "SO": "" }
                ],
      
            }
          ];
    }

    segmentChanged(e){
        if(this.isSelected != 'Trade'){
            // this.orderReport_result = ''
          this.loadOrderBook()
        } else {
          // this.loadTradeBook()
        }
      }

    ionViewDidLoad() {

        this.storage.get("userMaster").then((data) => {
            if (data != null && data != undefined) {
                this.userData = data;
                this.loadMarginReport();
            }


        })
        this.prvPage = this.navCtrl.getPrevious().name;
        // console.log("Prev Page", this.prvPage);

        //  }
        // ionViewDidEnter() {


        this.navBar.backButtonClick = (e: UIEvent) => {
            // todo something
            this.socket.send('DELETE^*')
            this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: this.item });
            // if (this.previousPage == 'MarketDepthPage') {
            //     this.navCtrl.push('MarketDepthPage', { userMWDepthData: this.item, clientUserData: this.clientUserData });
            // } else if (this.previousPage == 'MarketWatchPage') {
            //     this.navCtrl.push('MarketWatchPage', { useLogindata: this.clientUserData });
            // } else {
            //     this.navCtrl.pop();
            // }
            try {
                let page = this.navCtrl.getViews()
                if (page.length > 1){
                this.navCtrl.pop();
                }
              } catch(e){}
        }
        //---get the selected scrip data --
        //console.log("this.item",this.item)
        this.originalModifyData = this.navParams.get('userbuyData');
        this.itemFromSearch = this.navParams.get('userbuyData');
        this.itemMod = this.item
        //console.log("this.item from buy",this.item)
        this.clientUserData = this.navParams.get('clientUserData');
        this.isModData = this.navParams.get('ismodify');
        this.isSquareOffOrderData = this.navParams.get('isSquareOfOrder');
        this.isVoiceSearchOrderData = this.navParams.get('isVoiceSearchOrder');
        //console.log("this.isSquareOffOrderData",this.isSquareOffOrderData)
        //--If form is open from modify order set the ismodifyorder to be true--
        let from_notification = this.navParams.get('from_notification');

        



        if(this.sellFromHoldings){
            this.AUTOAMS = this.clientUserData.CustomerName.split("-")[1];
            if(this.AUTOAMS == 1){
                this.defaultSourceAccount = {
                  Source: 'AUTO'
                }
              }

            this.sellFromHoldingsQty=this.item.totalQtyToSell;
            this.defaultSourceAccount.Source = this.item.Source;
            this.defaultTradingAccount = {TradingAccount:this.item.TradingAccount}
            this.activeAction ='S';
            this.orderObject.TradingAccount = this.item.TradingAccount
            this.item.exchange = this.item.exchange ? this.item.exchange : 'NEPSE'
            let qt =  this.item.AvailableQty
                
            setTimeout(() => {
                this.orderObject.Quantity = qt
            }, 2000);
            //console.log("this.defaultTradingAccount",this.defaultTradingAccount)
          }


        // debugger

        if(this.item){
            if(this.item.LTP != ''){
                let percent = ((this.item.LTP * 2) / 100);
                this.lowLTP = (parseFloat(this.item.LTP) - percent).toFixed(2)
                this.highLTP = (parseFloat(this.item.LTP) + percent).toFixed(2)
                if(isNaN(this.lowLTP)){
                    this.lowLTP = 0
                }
                if(isNaN(this.highLTP)){
                    this.highLTP = 0
                }
            } else {
                
                let percent = ((this.item.Close * 2) / 100);
                this.lowLTP = (parseFloat(this.item.Close) - percent).toFixed(2)
                this.highLTP = (parseFloat(this.item.Close) + percent).toFixed(2)
                if(isNaN(this.highLTP)){
                    this.highLTP = 0
                }
                if(isNaN(this.lowLTP)){
                    this.lowLTP = 0
                }
            }
        }

        if(this.isModData){
            if((this.item.BuySellType).toUpperCase() == 'BUY'){
                this.activeAction = 'B'
            } else {
                this.activeAction = 'S'

            }
        }

        

        this.reserchMsgProduct();
        this.connectSocket()

        if (from_notification) {
            this.handleBrodcastMessage(this.item)
        }

        if (this.isModData) {
            this.orderObject.isModifyOrder = true;
        }
        if (this.isSquareOffOrderData) {
            this.orderObject.isSquareoffOrder = true;
        }
        this.showDisclosedQty = true;
        this.showPriceForLimitOrder = true;
        this.showDiscolosed = true;
        this.amoOrder = 'N';
        this.amo = { checkedData: false }
        // this.AUTOAMS = this.clientUserData.CustomerName.split("-")[1];
        //---when calling Buy/Sell from Order book, in the ticker, we receive Scrip~O:26-May-16:CE:1000 whereas we need Scrip~O:1-Mon:CE:1000.
        //---hence we will use the logic below to extract underlying,exchange and instrument type and use that to call getLongTermExpiry Date.
        //---Then using the results of that service, we will compute a new ticker as needed above and then use it to call GetSpecified Quote and getLotSize services.

        //---look for tilde (~), if found, the ticker is F&O. then find if there is more than 1 Colen (:), if found, ticker is Options.
        //---Use this to identify underlying, expiry, option type and strike price.
        this.tickertype = 'EQT';
        this.isIndex = false;
        if (this.item.Scrip != undefined) {
            if (this.item.Scrip.search("~") > 0) {
                this.tickertype = 'FUT';
                if (this.item.Scrip.indexOf(":", this.item.Scrip.indexOf(":") + 1) > 0) {
                    this.tickertype = 'OPT';
                }
                if (this.item.Scrip.search("~S") > 0) {
                    this.tickertype = 'SPD';
                }

                if (this.item.Scrip.toUpperCase().search("NIFTY") > -1 || this.item.Scrip.toUpperCase().search("SENSEX") > -1) {
                    this.isIndex = true;
                }
            }
        } else {
            if (this.item.ticker.search("~") > 0) {
                this.tickertype = 'FUT';
                if (this.item.ticker.indexOf(":", this.item.ticker.indexOf(":") + 1) > 0) {
                    this.tickertype = 'OPT';
                }
                if (this.item.ticker.search("~S") > 0) {
                    this.tickertype = 'SPD';
                }

                if (this.item.ticker.toUpperCase().search("NIFTY") > -1 || this.item.ticker.toUpperCase().search("SENSEX") > -1) {
                    this.isIndex = true;
                }
            }
        }
        //---if Scrip search selection is future, get Expiry data as well and show--
        if (this.tickertype === "EQT" || this.tickertype === "SPD") {
            //call main function for getting quote/lotsize and rendering Form
            this.getQuoteLot();
        }
        if (this.tickertype === "FUT") {
            //var ExpiryDateString = configService.FeedServiceURL + configService.GetLongTermExpiryDate;
            this.ExpiryDateString = '?Exchange=' + encodeURIComponent(this.item.exchange);
            //---To get Expiry for Future indices
            if (this.item.exchange === 'NSE' || this.item.exchange === 'BSE' || this.item.exchange === 'FONSE' || this.item.exchange === 'FOBSE') {
                if (this.isIndex === false) {
                    this.ExpiryDateString += '&InstrumentType=FUTSTK';
                } else {
                    this.ExpiryDateString += '&InstrumentType=FUTIDX';
                }
            }
            if (this.item.exchange == 'MCX' || this.item.exchange == 'NCDEX' || this.item.exchange == 'COMNSE') {
                this.ExpiryDateString += '&InstrumentType=FUTCOM';
            }
            if (this.item.exchange == 'CDNSE') {
                this.ExpiryDateString += '&InstrumentType=FUTCUR';
            }
            if (this.item.exchange == 'CDBSE') {
                this.ExpiryDateString += '&InstrumentType=FUTCUR';
            }
            this.ExpiryDateString += '&Symbol=' + encodeURIComponent(this.item.underlying);

            //---Service to call the long term expiry date--
            this.buySellManager.getExpiryDate(this.ExpiryDateString).then((data) => {
                this.getExpiry_result = data;
                if (this.getExpiry_result.ErrorCode == 0) {
                    if (this.getExpiry_result.data != null) {
                        this.scripSetExpiry = JSON.parse(this.getExpiry_result.data);
                    } else {
                        this.scripSetExpiry = []
                    }
                    var firstColen = -1
                    var expVal = "";
                    if (this.item.Scrip != undefined) {
                        firstColen = this.item.Scrip.toUpperCase().search(":");
                    } else {
                        firstColen = this.item.ticker.toUpperCase().search(":");
                    }
                    if (this.item.Scrip != undefined) {
                        expVal = this.item.Scrip.substr(firstColen + 1).toUpperCase().trim();
                    } else {
                        expVal = this.item.ticker.substr(firstColen + 1).toUpperCase().trim();
                    }

                    this.scripSetExpiry.forEach((value, index) => {
                        //---check if expiry of scrip is matched with ExpVal of this.scripSetExpiry, if so, then set this.item.expiryKey as
                        //---ExpKey
                        if (expVal.toUpperCase() === this.scripSetExpiry[index].ExpVal.split("=")[1].toUpperCase()) {
                            this.item.expiryKey = this.scripSetExpiry[index].ExpKey;
                            //for FUTIDX, hardcoded rules to convert Nifty to Nifty 50 and MiniNifty to mini nifty etc.
                            if (this.isIndex === true) {
                                switch (this.item.underlying) {
                                    case "NIFTY":
                                        this.item.underlying = "NIFTY 50";
                                        break;
                                    case "BANKNIFTY":
                                        this.item.underlying = "BANK NIFTY";
                                        break;
                                    case "NIFTYIT":
                                        this.item.underlying = "NIFTY IT";
                                        break;
                                    case "NIFTYMID50":
                                        this.item.underlying = "NIFTY MIDCAP 50";
                                        break;
                                    case "NIFTYPSE":
                                        this.item.underlying = "NIFTY PSE";
                                        break;
                                    case "NIFTYINFRA":
                                        this.item.underlying = "NIFTY INFRA";
                                        break;
                                }
                            }
                            //---end of hardcoded rules
                            if (this.item.underlying == "BANK NIFTY") {
                                this.item.ticker = this.item.underlying + "~F:" + this.item.ExpiryDate;
                            } else {
                                this.item.ticker = this.item.underlying + "~F:" + this.item.expiryKey;
                            }
                        }
                    });
                    //---function to call get quote lot data --
                    this.getQuoteLot();
                }
            }, err => {
                // this.common.hideLoading();
                swal({
                    // title: "Error!",
                    text: "Oops, Something went wrong.",
                    timer: 2000,
                    showConfirmButton: false,
                    allowOutsideClick: true
                });
            });
        }
        //----If ticker is OPT
        if (this.tickertype === "OPT") {
            //ExpiryDateString = configService.FeedServiceURL + configService.GetLongTermExpiryDate;
            this.ExpiryDateString = '?Exchange=' + encodeURIComponent(this.item.exchange);

            //---To get Expiry for Future indices
            if (this.item.exchange === 'NSE' || this.item.exchange === 'BSE' || this.item.exchange === 'FONSE' || this.item.exchange === 'FOBSE') {
                if (this.isIndex === false) {
                    this.ExpiryDateString += '&InstrumentType=OPTSTK';
                } else {
                    this.ExpiryDateString += '&InstrumentType=OPTIDX';
                }
            }
            if (this.item.exchange == 'MCX' || this.item.exchange == 'NCDEX' || this.item.exchange == 'COMNSE') {
                this.ExpiryDateString += '&InstrumentType=OPTFUT';
            }
            if (this.item.exchange == 'CDNSE') {
                this.ExpiryDateString += '&InstrumentType=OPTCUR';
            }
            if (this.item.exchange == 'CDBSE') {
                this.ExpiryDateString += '&InstrumentType=OPTCUR';
            }
            this.ExpiryDateString += '&Symbol=' + encodeURIComponent(this.item.underlying);
            //---Service to call the long term expiry date--
            this.buySellManager.getExpiryDate(this.ExpiryDateString).then((data) => {
                this.getExpiry_result = data;
                if (this.getExpiry_result.ErrorCode == 0) {
                    if (this.getExpiry_result.data != null) {
                        this.scripSetExpiry = JSON.parse(this.getExpiry_result.data);
                    } else {
                        this.scripSetExpiry = []
                    }
                    var firstColen = -1;
                    var secondColen = -1;
                    var thirdColen = -1;
                    var expVal = "";
                    var instrumentType = "";
                    var strikePrice = "";

                    if (this.item.Scrip != undefined) {
                        firstColen = this.item.Scrip.toUpperCase().search(":");
                        secondColen = firstColen + this.item.Scrip.substr(firstColen + 1).toUpperCase().search(":");
                        thirdColen = secondColen + this.item.Scrip.substr(secondColen + 2).toUpperCase().search(":");
                    } else {
                        firstColen = this.item.ticker.toUpperCase().search(":");
                        secondColen = firstColen + this.item.ticker.substr(firstColen + 1).toUpperCase().search(":");
                        thirdColen = secondColen + this.item.ticker.substr(secondColen + 2).toUpperCase().search(":");
                    }
                    if (this.item.Scrip != undefined) {
                        expVal = this.item.Scrip.substr(firstColen + 1, (secondColen - firstColen)).toUpperCase().trim();
                    } else {
                        expVal = this.item.ticker.substr(firstColen + 1, (secondColen - firstColen)).toUpperCase().trim();
                    }

                    if (this.item.Scrip != undefined) {
                        instrumentType = this.item.Scrip.substr(secondColen + 2, (thirdColen - secondColen)).toUpperCase().trim();
                        strikePrice = this.item.Scrip.substr(thirdColen + 3).toUpperCase().trim();

                    } else {
                        instrumentType = this.item.ticker.substr(secondColen + 2, (thirdColen - secondColen)).toUpperCase().trim();
                        strikePrice = this.item.ticker.substr(thirdColen + 3).toUpperCase().trim();

                    }
                    this.scripSetExpiry.forEach((value, index) => {
                        //---check if expiry of scrip is matched with ExpVal of this.scripSetExpiry, if so, then set this.item.expiryKey as
                        //---ExpKey
                        if (expVal.toUpperCase() === this.scripSetExpiry[index].ExpVal.split("=")[1].toUpperCase()) {
                            this.item.expiryKey = this.scripSetExpiry[index].ExpKey;
                            //for FUTIDX, hardcoded rules to convert Nifty to Nifty 50 and MiniNifty to mini nifty etc.
                            if (this.isIndex === true) {
                                switch (this.item.underlying) {
                                    case "NIFTY":
                                        this.item.underlying = "NIFTY 50";
                                        break;
                                    case "BANKNIFTY":
                                        this.item.underlying = "NIFTY BANK";
                                        break;
                                    case "NIFTYIT":
                                        this.item.underlying = "NIFTY IT";
                                        break;
                                    case "NIFTYMID50":
                                        this.item.underlying = "NIFTY MIDCAP 50";
                                        break;
                                    case "NIFTYPSE":
                                        this.item.underlying = "NIFTY PSE";
                                        break;
                                    case "NIFTYINFRA":
                                        this.item.underlying = "NIFTY INFRA";
                                        break;
                                }
                            }
                            //---end of hardcoded rules
                            this.item.ticker = this.item.underlying + "~O:" + this.item.expiryKey + ":" + instrumentType + ":" + strikePrice;
                        }
                    });
                    //---function to call get quote lot data --
                    this.getQuoteLot();
                }
            }, err => {
                swal({
                    // title: "Error!",
                    text: "Oops, Something went wrong.",
                    timer: 2000,
                    showConfirmButton: false,
                    allowOutsideClick: true
                });
            });
        }
        //---Service to call market status --
        this.getMarketStatus();
    }
    //---toggle advance options --
    toggleAdvanceOptions() {
        this.showAdvanceOptions = !this.showAdvanceOptions;
        if (this.showAdvanceOptions == false) {
            this.content.scrollToTop();
        }
    }
    //---Toggle Order Type --
    toggleOrderType(val) {
        if (val.toUpperCase() == "MKT") {
            this.showPriceForLimitOrder = false;
            this.orderObject.Price = 0;
            this.orderObject.Market = 1;
        } else {
            this.showPriceForLimitOrder = true;
            this.orderObject.Market = 0;
        }
    }

    //---Cnahge Product type --
    changeProductType(proObj) {
        //console.log("proObj",proObj)
        this.products.availableOptions.forEach((value, index) => {
            if (value.TradingAccount == proObj.TradingAccount) {
                //---For margin plus order--
                if (value.DeliveryFlag == "MPT") {
                    this.isMarginPlusOrder = true;
                    //---For margin plus order hide the limit price and put order on basis of market price only.
                    if (this.isModData) {
                        this.showPriceForLimitOrder = true;
                        this.isMarginPlusOrder = false;       // changes for marging plush 10/09
                    } else {
                        this.showPriceForLimitOrder = false;
                        this.orderObject.Price = 0;
                        this.orderObject.Market = 1;
                        this.showTriggerPrice = true;
                    }
                } else {
                    this.isMarginPlusOrder = false;
                    //this.showPriceForLimitOrder = true;
                    //this.orderObject.Market=0;
                    //this.showTriggerPrice=false
                    //this.showAdvanceOptions=true;

                    // this.showPriceForLimitOrder = false;
                    // this.orderObject.Price = 0;
                    // this.orderObject.Market = 1;
                    // this.showTriggerPrice = true;
                    this.toggleOrderType(this.checkboxModel.value)
                }
                this.orderObject.TradingAccount = value.TradingAccount
                this.orderObject.DeliveryFlag = value.DeliveryFlag
            }
        });
        var newVtdProd = this.clientUserData.VTDAllowedToProducts.split('~');
        for (var tempFlagNew = 0; tempFlagNew < newVtdProd.length; tempFlagNew++) {
            //console.log("valueVTDPROD",newVtdProd[tempFlagNew])
            if (newVtdProd[tempFlagNew] == proObj.TradingAccount) {
                this.orderTerms = []
                var ExchangeTermsList = this.clientUserData.ExchangeTermsList;
                var ExchangeWiseList = ExchangeTermsList.split('^');
                var ExchangePermit = 0;
                for (var i = 0; i < ExchangeWiseList.length; i++) {
                    if (ExchangeWiseList[i] == this.item.exchange) {
                        ExchangePermit = 1;
                        break;
                    }
                }
                if (ExchangePermit == 1) {
                    this.orderTerms =[]
                    var OrderTerms = ExchangeWiseList[i + 1].split('~');
                    var j = 0;
                    for (var tempi3 = 0; tempi3 < OrderTerms.length; tempi3++) {
                        this.orderTerms.push(OrderTerms[tempi3]);
                        //---if order terms has already been set by modify order, then identify which one matches and set variable j.
                        //---then use variable j to set the default option
                        if (OrderTerms[tempi3] == this.orderObject.OrderTerms) {
                            j = tempi3
                        };
                    }

                }
                break;
            } else {
                this.orderTerms = []
                var ExchangeTermsList = this.clientUserData.ExchangeTermsList;
                var ExchangeWiseList = ExchangeTermsList.split('^');
                var ExchangePermit = 0;
                for (var i = 0; i < ExchangeWiseList.length; i++) {
                    if (ExchangeWiseList[i] == this.item.exchange) {
                        ExchangePermit = 1;
                        break;
                    }
                }
                if (ExchangePermit == 1) {
                    this.orderTerms = []
                    var OrderTerms = ExchangeWiseList[i + 1].split('~');
                    var j = 0;
                    for (var tempi3 = 0; tempi3 < OrderTerms.length; tempi3++) {
                        this.orderTerms.push(OrderTerms[tempi3]);
                        //---if order terms has already been set by modify order, then identify which one matches and set variable j.
                        //---then use variable j to set the default option
                        if (OrderTerms[tempi3] == this.orderObject.OrderTerms) {
                            j = tempi3
                        };
                    }
                    //console.log("test")
                    var OrderTermsVTD = this.clientUserData.VTDAllowedToProducts.split('~');
                    for (var tempFlag = 0; tempFlag < OrderTermsVTD.length; tempFlag++) {
                        for (var tempFlagProduct = 0; tempFlagProduct < this.products.availableOptions.length; tempFlagProduct++) {
                            // console.log("OrderTermsVTD",OrderTermsVTD[tempFlag])
                            // console.log("this.products",this.products.availableOptions[tempFlagProduct])
                            if (OrderTermsVTD[tempFlag] == this.products.availableOptions[tempFlagProduct].TradingAccount) {
                                //console.log("this.orderTerms",this.orderTerms)
                                this.orderObject.OrderTerms = this.orderObject.OrderTerms ? this.orderObject.OrderTerms : this.orderTermSelected;
                                // if(this.orderObject.TermValidity && this.orderObject.OrderTerms == "VTD"){
                                //     this.orderObject.TermValidity = this.formatDate(this.orderObject.TermValidity)
                                // }
                                // var indexOfOrderTerms = this.orderTerms.indexOf("VTD");
                                // if (indexOfOrderTerms > -1) {
                                //     this.orderTerms.splice(indexOfOrderTerms, 1);
                                //     break;
                                // }
                            }


                        }
                    }
                }
            }
        }
    }
    //---Change Order Type --
    changeOrderType(oObj) {
        this.orderObject.OrderTerms = oObj;
        if (oObj == "GTD" || oObj == "VTD") {
            this.showGTDDate = true;
        } else {
            this.showGTDDate = false;
        }
        if (oObj == "IOC") {
            this.showDiscolosed = false;
        } else {
            this.showDiscolosed = true;
        }
    }
    //---function to reset stop loss --
    resetstoploss(val) {
        if (val == false) {
            this.orderObject.TriggerPrice = 0;
        }
    }
    //--AMO order --
    changeAMO(amoObj) {
        // debugger
        if (this.ClientName == 'Bhumika') {
            if (amoObj == 'N') {
                this.orderObject.AMOBulkIndicator = ''
            } else {
                this.orderObject.AMOBulkIndicator = 'AMO'
            }
        } else {
            if (amoObj == 'N') {
                this.orderObject.AMOBulkIndicator = ''
            } else {
                this.orderObject.AMOBulkIndicator = 'AMO'
            }
            if (amoObj == true) {
                this.orderObject.AMOBulkIndicator = 'AMO'
            } else {
                this.orderObject.AMOBulkIndicator = ''
            }

        }


    }
    //---Service to call get quote lot --
    //---service to fetch scrip related specified quote from feedAPI based on Exchange and Ticker info passed in this
    getQuoteLot() {
        this.buttonText = "Buy";
        this.showSwitch = true;
        this.showLot = false;
        this.lotSize = 1;
        this.AMOallowed = true;

        //--- for future and options, send only underlying as querystring....
        //---fix header before sending http  request to google api
        this.buySellManager.getSpecifiedQuote(this.item.exchange, this.item.ticker).then((data) => {
            this.getSpecifiedQuote_result = data;
            if (this.getSpecifiedQuote_result.ErrorCode == 0) {
                var scripSet = JSON.parse(this.getSpecifiedQuote_result.data);
                this.item = scripSet[0];
                this.tickertype = 'EQT';
                this.isIndex = false;

                if(this.item){
                    if(this.item.LTP != ''){
                        let percent = ((this.item.LTP * 2) / 100);
                        this.lowLTP = (parseFloat(this.item.LTP) - percent).toFixed(2)
                        this.highLTP = (parseFloat(this.item.LTP) + percent).toFixed(2)
                        if(isNaN(this.lowLTP)){
                            this.lowLTP = 0
                        }
                        if(isNaN(this.highLTP)){
                            this.highLTP = 0
                        }
                    } else {
                        
                        let percent = ((this.item.Close * 2) / 100);
                        this.lowLTP = (parseFloat(this.item.Close) - percent).toFixed(2)
                        this.highLTP = (parseFloat(this.item.Close) + percent).toFixed(2)
                        if(isNaN(this.highLTP)){
                            this.highLTP = 0
                        }
                        if(isNaN(this.lowLTP)){
                            this.lowLTP = 0
                        }
                    }
                }
                

                if (this.item.Scrip != undefined) {
                    if (this.item.Scrip.search("~") > 0) {
                        this.tickertype = 'FUT';
                        if (this.item.Scrip.indexOf(":", this.item.Scrip.indexOf(":") + 1) > 0) {
                            this.tickertype = 'OPT';
                        }
                        if (this.item.Scrip.search("~S") > 0) {
                            this.tickertype = 'SPD';
                        }

                        if (this.item.Scrip.toUpperCase().search("NIFTY") > -1 || this.item.Scrip.toUpperCase().search("SENSEX") > -1) {
                            this.isIndex = true;
                        }
                    }
                } else {
                    if (this.item.ticker.search("~") > 0) {
                        this.tickertype = 'FUT';
                        if (this.item.ticker.indexOf(":", this.item.ticker.indexOf(":") + 1) > 0) {
                            this.tickertype = 'OPT';
                        }
                        if (this.item.ticker.search("~S") > 0) {
                            this.tickertype = 'SPD';
                        }

                        if (this.item.ticker.toUpperCase().search("NIFTY") > -1 || this.item.ticker.toUpperCase().search("SENSEX") > -1) {
                            this.isIndex = true;
                        }
                    }
                }
                this.exchange = this.item.exchange;
                if (this.tickertype == 'EQT') {
                    this.item.underlying = this.item.ticker.toUpperCase();
                    this.item.optType = '';
                    this.item.strikePrice = '';
                    this.item.reconstructedTicker = this.item.underlying;
                    this.showLot = true;
                    if (this.item.Scrip != undefined) {
                        this.getLotSize(this.item.Scrip, this.exchange);
                        this.getCompanyInformation(this.item.Scrip, this.exchange);
                    } else {
                        this.getLotSize(this.item.ticker, this.exchange);
                        this.getCompanyInformation(this.item.ticker, this.exchange);
                    }
                }
                if (this.tickertype == 'SPD') {
                    //this.item.underlying = this.item.ticker.toUpperCase();
                    this.item.underlying = this.item.ticker;
                    this.item.optType = '';
                    this.item.strikePrice = '';
                    this.item.reconstructedTicker = this.item.underlying;
                    this.showLot = true;
                    if (this.item.Scrip != undefined) {
                        this.getLotSize(this.item.Scrip, this.exchange);
                        this.getCompanyInformation(this.item.Scrip, this.exchange);
                    } else {
                        this.getLotSize(this.item.ticker, this.exchange);
                        this.getCompanyInformation(this.item.ticker, this.exchange);
                    }

                }
                if (this.tickertype == 'FUT') {
                    this.item.underlying = this.item.ticker.substr(0, this.item.ticker.search("~")).toUpperCase();

                    //---for FUTIDX, hardcoded rules to convert Nifty 50 to Nifty and Mini Nifty to mininifty etc.
                    if (this.item.Instrument === "FUTIDX" || this.item.Instrument === "OPTIDX") {
                        switch (this.item.underlying) {
                            case "NIFTY 50":
                                this.item.underlying = "Nifty";
                                break;
                            case "NIFTY BANK":
                                this.item.underlying = "BANKNIFTY";
                                break;
                            case "NIFTY IT":
                                this.item.underlying = "NiftyIT";
                                break;
                            case "NIFTY MIDCAP 50":
                                this.item.underlying = "NIFTYMID50";
                                break;
                            case "NIFTY PSE":
                                this.item.underlying = "NIFTYPSE";
                                break;
                            case "NIFTY INFRA":
                                this.item.underlying = "NIFTYINFRA";
                                break;
                        }
                    }
                    //end of hardcoded rules
                    this.item.optType = '';
                    this.item.strikePrice = '';
                    if (this.item.ExpiryDate == "") {
                        this.item.reconstructedTicker = this.item.ticker;
                    } else {
                        this.item.reconstructedTicker = this.item.underlying + '~F:' + this.item.ExpiryDate;
                    }

                    this.showLot = true;
                    //var exchange="NSE";
                    if (this.item.exchange === "FONSE") {
                        this.exchange = "NSE";
                    }
                    if (this.item.exchange === "FOBSE") {
                        this.exchange = "BSE";
                    }
                    this.getLotSize(this.item.reconstructedTicker, this.exchange);
                    this.getCompanyInformation(this.item.ticker, this.exchange);
                }
            }
            if (this.tickertype == 'OPT') {
                this.item.underlying = this.item.ticker.substr(0, this.item.ticker.search("~")).toUpperCase();
                //for FUTIDX, hardcoded rules to convert Nifty 50 to Nifty and Mini Nifty to mininifty etc.
                if (this.item.Instrument === "FUTIDX" || this.item.Instrument === "OPTIDX") {
                    switch (this.item.underlying) {
                        case "NIFTY 50":
                            this.item.underlying = "Nifty";
                            break;
                        case "NIFTY BANK":
                            this.item.underlying = "BANK NIFTY";
                            break;
                        case "NIFTY IT":
                            this.item.underlying = "NiftyIT";
                            break;
                        case "NIFTY MIDCAP 50":
                            this.item.underlying = "NIFTYMID50";
                            break;
                        case "NIFTY PSE":
                            this.item.underlying = "NIFTYPSE";
                            break;
                        case "NIFTY INFRA":
                            this.item.underlying = "NIFTYINFRA";
                            break;
                    }
                }
                //---end of hardcoded rules
                if (this.item.Scrip != undefined) {
                    this.item.optType = this.item.Scrip.substr(this.item.Scrip.indexOf(":", this.item.Scrip.indexOf(":") + 1) + 1, 2);
                    this.item.strikePrice = this.item.Scrip.substr(this.item.Scrip.indexOf(":", this.item.Scrip.indexOf(":", this.item.Scrip.indexOf(":") + 1) + 1) + 1);
                } else {
                    this.item.optType = this.item.ticker.substr(this.item.ticker.indexOf(":", this.item.ticker.indexOf(":") + 1) + 1, 2);
                    this.item.strikePrice = this.item.ticker.substr(this.item.ticker.indexOf(":", this.item.ticker.indexOf(":", this.item.ticker.indexOf(":") + 1) + 1) + 1);
                }
                this.item.reconstructedTicker = this.item.underlying + '~O:' + this.item.ExpiryDate + ':' + this.item.optType + ':' + this.item.strikePrice;
                this.showLot = true;
                //var exchange="NSE";
                if (this.item.exchange === "FONSE") {
                    this.exchange = "NSE";
                }
                if (this.item.exchange === "FOBSE") {
                    this.exchange = "BSE";
                }
                this.getLotSize(this.item.reconstructedTicker, this.exchange);
                this.getCompanyInformation(this.item.ticker, this.exchange);
            }

            //---handling ProductType based on Future , Option , Cash and Spread

            this.ProductTypeItems = ['SPREAD', 'FUTURE', 'OPTION', 'CASH'];
            this.item.ticker.split(':');
            this.formatedTicker = this.item.ticker.split(':')[0];

            if (this.formatedTicker.substr(this.formatedTicker.indexOf("~") + 1) == 'F') {
                this.ProductTypeitem = this.ProductTypeItems[1];
            } else if (this.formatedTicker.substr(this.formatedTicker.indexOf("~") + 1) == 'S') {
                this.ProductTypeitem = this.ProductTypeItems[0];
            } else if (this.formatedTicker.substr(this.formatedTicker.indexOf("~") + 1) == 'O') {
                this.ProductTypeitem = this.ProductTypeItems[2];
            } else {
                this.ProductTypeitem = this.ProductTypeItems[3];
            }

            this.item.DateTime = this.item.LastTradeTime;
            this.Price = Number(this.item.OfferPrice);
            if (this.ProductTypeitem == "SPREAD") {
                this.NewOrderCategory = 'SPREAD';
            } else {
                this.NewOrderCategory = 'NORMAL';
            }
            this.orderObject = {
                SessionNo: this.clientUserData.SessionNo,
                ClientCode: this.clientUserData.ClientCode,
                OrderPlacedBy: this.clientUserData.ClientCode,
                Source: 5,
                TradingAccount: '',
                Exchange: this.item.exchange,
                //Scrip: this.item.ticker,
                Scrip: this.item.reconstructedTicker,
                Quantity: '',
                Price: Number(this.item.OfferPrice) == 0 ? '' : Number(this.item.OfferPrice),
                Market: 0,
                OrderTerms: this.orderTermSelected,
                BuySellIndicator: '',
                BuySellType: '',
                TriggerPrice: '',
                DeliveryTerms: 'D',
                MarketSegment: 'RL',
                DeliveryFlag: '',
                OrderCategory: this.itemMod.OrderCategory,
                // OrderCategory: this.NewOrderCategory,
                OrderType: this.NewOrderCategory,
                AccRefCode: 'SELF',
                TermValidity: '',
                DisclosedQuantity: '',
                ProductType: this.ProductTypeitem,
                AMOBulkIndicator: '',
                MinQuantity: 0,
                Remarks: '',
                TranID: 0,
                OrderId: 0,
                OriginalRemainingQty: 0,
                isModifyOrder: false,
                isSquareoffOrder: false,
                AddModifyFlag: '0',
                MPSLPrice: 0,
                MPLOPrice: ''
            };
            if(this.activeAction == 'B'){
                this.orderObject.BuySellType = 'Buy'
                this.orderObject.BuySellIndicator= 'B'
          
            } else {
                this.orderObject.BuySellIndicator= 'S',
                this.orderObject.BuySellType = 'Sell'
                this.orderObject.DeliveryFlag = 'AUTO'
            }
            //console.log("this.orderObject",this.orderObject)
            //---for squareoff order logic will go here---
            if (this.isModData == true || this.isSquareOffOrderData == true) {
                //console.log("this.item from modTrue",this.itemMod)
                if (this.itemMod.BrokerTranID != undefined && this.itemMod.BrokerTranID != "") {
                    this.Price = Number(this.itemMod.Price);
                    this.orderObject.TradingAccount = this.itemMod.TradingAccount;
                    this.orderObject.Scrip = this.itemMod.Scrip;
                    this.orderObject.Quantity = Number(this.itemMod.RemainingQty);
                    this.orderObject.Price = Number(this.itemMod.Price);
                    //set order type as limit.
                    this.orderObject.Market = 0;
                    this.orderObject.OrderTerms = this.itemMod.OrderTerms;
                    this.orderObject.TriggerPrice = Number(this.itemMod.TriggerPrice);
                    this.showAdvanceOptions = true;

                    //check stop loss is avaible or not in modify condition
                    if (this.orderObject.TriggerPrice <= 0) {
                        this.checkboxModelrlsl = false;
                    } else {
                        // for Stop Loss checkbox
                        this.checkboxModelrlsl = true;
                        this.showTriggerPriceToggle = true;
                        this.showTriggerPrice = true;
                        // this.amoOrderFromModify = false;      10/09 for margin plus----------------- 
                    }
                    this.resetstoploss(true);

                    //this.orderObject.OrderCategory = OrderService.orderObject.OrderCategory;
                    //this.orderObject.OrderType = OrderService.orderObject.OrderType;
                    this.orderObject.isModifyOrder = true;
                    this.orderObject.TranID = this.itemMod.LatestOrderID;
                    this.orderObject.OrderId = this.itemMod.BrokerTranID;
                    this.orderObject.OriginalRemainingQty = this.itemMod.RemainingQty;
                    this.orderObject.DisclosedQuantity = Number(this.itemMod.DisclosedQuantity);
                    // console.log("this.itemMod", this.itemMod)
                    if (this.itemMod.OrderStatus == "AMO") {
                        this.orderObject.AMOBulkIndicator = "AMO";
                        this.AMOallowed = true;
                        //this.amoOrderFromModify = false;
                        this.amo.checkedData = true
                        // this.amoOrder = 'Y'
                    }
                } else {
                    //for Square Off Orders
                    this.orderObject.TradingAccount = this.itemMod.TradingAccount;
                    if (this.itemMod.OpenQuantity != undefined) {
                        this.orderObject.Quantity = Number(this.itemMod.OpenQuantity);
                    }

                    //from netposition or ismodify show price in order form
                    if (this.itemMod.LastTradedPrice == undefined) {
                        this.Price = Number(this.itemMod.Price);
                    } else {
                        this.orderObject.Price = Number(this.itemMod.LastTradedPrice);
                    }
                    //this.orderObject.isSquareoffOrder = this.itemMod.isSquareoffOrder;
                    this.orderObject.isSquareoffOrder = true;
                }
                if (this.orderObject.isModifyOrder === true) {
                    this.buttonText = "Modify";
                    if (this.clientMarketWatchList.clientName == 'Bhumika' && this.prvPage == 'OrderBookPage' && this.itemMod.OrderStatus == "AMO") {
                        this.AMOallowed = true;
                    } else if (this.clientMarketWatchList.clientName == 'ATS' || this.clientMarketWatchList.clientName == 'ATSNew' && this.prvPage == 'OrderBookPage' && this.itemMod.OrderStatus == "AMO") {
                        this.AMOallowed = true;
                    } else {
                        this.AMOallowed = false;
                    }
                    //this.AMOallowed = false; 
                    // this.amoOrder = 'Y' change 9/07/19 for bhumika
                    //this.amo.checkedData=false
                    //console.log("originalModifyData",this.originalModifyData)
                    this.orderObject.TermValidity = (this.originalModifyData.TermValidity);
                    if (this.originalModifyData.OrderTerms == "VTD" || this.originalModifyData.OrderTerms == "GTD") {
                        this.showGTDDate = true;

                    }
                   
                    this.orderObject.AddModifyFlag = '1'
                }

                if (this.orderObject.isSquareoffOrder === true) {
                    this.buttonText = "Square Off";
                    this.showSwitch = false;
                    this.AMOallowed = true;
                    //this.amo.checkedData=true
                }
                //OrderService.orderObject.BrokerTranID="";
            }
            //--If order is been placed from the voice based --
            if (this.isVoiceSearchOrderData == true) {
                this.orderObject.Price = this.itemFromSearch.OfferPrice;
                this.orderObject.Quantity = this.itemFromSearch.Quantity;
            }
            //---End of squareOff order ---
            this.BindProductType();
            this.BindOrderTerms();


            // setTimeout(() => {
            //     if(this.orderObject.OrderCategory){
            //         if((this.orderObject.TriggerPrice > 0 && this.orderObject.Price == 0) && this.isModData) { 
            //             this.checkboxModel = { value: 'MKT' }
            //         } else if((this.orderObject.TriggerPrice > 0 && this.orderObject.Price > 0) && this.isModData) { 
            //             this.checkboxModel = { value: 'LMT' }
            //         } else {
            //             this.checkboxModel = { value: this.orderObject.OrderCategory.toUpperCase() }
            //         }
            //         // this.checkboxModel = { value: this.orderObject.OrderCategory.toUpperCase() }
            //     }
            // }, 2000);

           

        }, err => { });
    }

    //---get lot size and company information --
    getLotSize(security, exchange) {
        security = security.replace('NIFTY 50', 'Nifty');
        security = security.replace('NIFTY BANK', 'BANKNIFTY');
        security = security.replace('BANK NIFTY', 'BANKNIFTY');
        security = security.replace('NIFTY IT', 'NiftyIT');
        security = security.replace('NIFTY MIDCAP 50', 'NIFTYMID50');
        security = security.replace('NIFTY PSE', 'NIFTYPSE');
        security = security.replace('NIFTY INFRA', 'NIFTYINFRA');
        //---get lot size from service
        this.buySellManager.getLotSize(security, exchange).then((data) => {
            this.lotSize_result = data;
            if (this.lotSize_result.ErrorCode == 0) {
                this.lotSize = Number(this.lotSize_result.data);
                if (this.lotSize == 0)
                    this.lotSize = 1;
                if (this.lotSize > 1) {
                    this.showDisclosedQty = false;
                }
            }
        }, err => {
            console.log("error in retrieving lot size data");
        });
    }
    //---SErvice to call company information---
    getCompanyInformation(security, exchange) {
        this.buySellManager.getCompanyInfo(security, exchange).then((data) => {
            this.companyInfo_result = data
            if (this.companyInfo_result.ErrorCode == 0) {
                if (JSON.parse(this.companyInfo_result.data)[0]['Market Lot'] != undefined) {
                    this.ViewlotSize = JSON.parse(this.companyInfo_result.data)[0]['Market Lot'];
                } else if (JSON.parse(this.companyInfo_result.data)[0].MarketLot != undefined) {
                    this.ViewlotSize = JSON.parse(this.companyInfo_result.data)[0].MarketLot;
                } else if (JSON.parse(this.companyInfo_result.data)[0].MinimumLotQty != undefined) {
                    this.ViewlotSize = JSON.parse(this.companyInfo_result.data)[0].MinimumLotQty
                } else {
                    this.ViewlotSize = this.lotSize;
                }
                if (this.TickSize = JSON.parse(this.companyInfo_result.data)[0].TickSize == undefined) {
                    this.TickSize = JSON.parse(this.companyInfo_result.data)[0]['Price Tick (in Rs.)'];
                }
                else {
                    this.TickSize = JSON.parse(this.companyInfo_result.data)[0].TickSize;
                }


                if (this.upperCrcut == undefined || this.upperCrcut == "") {
                    this.upperCrcut = JSON.parse(this.companyInfo_result.data)[0]['DPR Low'];
                    this.lowerCrcut = JSON.parse(this.companyInfo_result.data)[0]['DPR High'];
                }

            } else {
                this.ViewlotSize = 1;
                this.TickSize = 1;
                this.lotSize = 1;
            }
        }, err => { });
    }
    //---get bind product type --
    BindProductType() {
        var VTD;
        var ExchangePermit = 0;
        var ProductTypeList = '';
        var ProductType = this.clientUserData.TradingAccountExchangeList.split('^');
        for (var i = 0; i < ProductType.length; i++) {
            if (ProductType[i].split('$')[0] == this.item.exchange) {
                ProductTypeList = ProductType[i].split('$')[1];
                ExchangePermit = 1;
                break;
            }
        }
        //---If Exchange is permit --
        if (ExchangePermit == 1) {
            var ProductTerms = ProductTypeList.split('|')[1].split('~');


            if (VTD == 1) {
                var VTDAllowd = this.clientUserData.VTDAllowedToProducts;
                for (var tempi1 = 0; tempi1 < ProductTerms.length; tempi1++) {
                    if (VTDAllowd.indexOf(ProductTerms[tempi1].split(',')[0]) > -1) {
                        //---check for isModifyOrder. if true, then bind only single Trading Account that matches with the input one,
                        //---else bind all
                        if (this.orderObject.isModifyOrder == false && this.orderObject.isSquareoffOrder == false) {
                            this.products.availableOptions.push({
                                TradingAccount: ProductTerms[tempi1].split(',')[0],
                                DeliveryFlag: ProductTerms[tempi1].split(',')[1]
                            });
                        } else if (ProductTerms[tempi1].split(',')[0].toUpperCase() == this.orderObject.TradingAccount.toUpperCase()) {
                            this.products.availableOptions.push({
                                TradingAccount: ProductTerms[tempi1].split(',')[0],
                                DeliveryFlag: ProductTerms[tempi1].split(',')[1]
                            });

                        }
                    }
                }
            } else {
                if (this.clientMarketWatchList.clientName == 'Canara' && this.orderObject.isModifyOrder == false && this.orderObject.isSquareoffOrder == false) {
                    if (this.item.exchange != "CDNSE" && this.item.exchange != "FONSE") {
                        // ProductTerms.unshift("Select");
                        // var changeOrder = [];
                        // for(var k=ProductTerms.length; k > 0; k--){
                        //     changeOrder.unshift( ProductTerms[k]);
                        // }
                        // console.log(changeOrder);
                    }
                }
                for (var tempi2 = 0; tempi2 < ProductTerms.length; tempi2++) {
                    //---check for isModifyOrder. if true, then bind only single Trading Account that matches with the input one,
                    //---else bind all
                    if (this.orderObject.isModifyOrder == false && this.orderObject.isSquareoffOrder == false) {
                        if (ProductTerms[tempi2].split(',')[1] != 'OBL') {
                            this.products.availableOptions.push({
                                TradingAccount: ProductTerms[tempi2].split(',')[0],
                                DeliveryFlag: ProductTerms[tempi2].split(',')[1]
                            });
                        }
                    } else if (ProductTerms[tempi2].split(',')[0].toUpperCase() == this.orderObject.TradingAccount.toUpperCase()) {
                        if (ProductTerms[tempi2].split(',')[1] != 'OBL') {
                            this.products.availableOptions.push({
                                TradingAccount: ProductTerms[tempi2].split(',')[0],
                                DeliveryFlag: ProductTerms[tempi2].split(',')[1]
                            });
                        }
                    }
                }
                //    this.delivery_flag= this.products.availableOptions.find(x=>x.DeliveryFlag=='OBL');


            }
        } else {
            //alert("Exchange " + this.item.exchange + " is not mapped to the user.");
            swal({
                title: "Exchange Not Allowed",
                type: "error",
                text: "Oops, Exchange " + this.item.exchange + " is not mapped to the user.",
                timer: 2000,
                allowOutsideClick: true,
                showConfirmButton: false,
                showCancelButton: true,
                cancelButtonText: "Close"

            });
            //$ionicHistory.goBack();
        }
        //-----
        if (this.productTypeSelected == undefined) {
            var exit = 0;
            //console.log("this.products.availableOptions-->",this.products.availableOptions);
            // if($rootScope.tempPreviousState.name == 'app.orderbook' || $rootScope.tempPreviousState.name == 'app.netposition' &&  $state.this != 'app.convert'){
            //
            //     for(var x=0; x < $scope.products.availableOptions.length; x++){
            //             $scope.productTypeSelected = $scope.products.availableOptions[x];
            //             exit = 1;
            //     }
            // }
            // if($rootScope.ClientName == "Marfatia" && $rootScope.previousState == 'assetReport'){
            //     for(var x=0; x < $scope.products.availableOptions.length; x++){
            //         if(($scope.products.availableOptions[x].TradingAccount).toUpperCase() == "DELIVERY"){
            //             $scope.productTypeSelected = $scope.products.availableOptions[x];
            //             exit = 1;
            //         }
            //         // else{
            //         //     exit = 1;
            //         //     $scope.productTypeSelected = $scope.products.availableOptions[0];
            //         // }
            //     }
            // }
            // else if($rootScope.ClientName == "Marfatia" && $rootScope.previousState != 'assetReport'){
            //     for(var x=0; x < $scope.products.availableOptions.length; x++){
            //         if(($scope.products.availableOptions[x].TradingAccount).toUpperCase() == "INTRADAY" && ($scope.products.availableOptions[x].DeliveryFlag).toUpperCase() == "MAR"){
            //             $scope.productTypeSelected = $scope.products.availableOptions[x];
            //             exit = 1;
            //         }
            //         // else{
            //         //     exit = 1;
            //         //     $scope.productTypeSelected = $scope.products.availableOptions[0];
            //         // }
            //
            //     }
            // }
            // else{
            //     exit = 1;
            //     $scope.productTypeSelected = $scope.products.availableOptions[0];
            //     console.log("$scope.productTypeSelected in else",$scope.productTypeSelected);
            // }

            if (exit == 0) {
                this.productTypeSelected = this.products.availableOptions[0];
                this.defaultTradingAccount = { TradingAccount: this.products.availableOptions[0].TradingAccount }
                this.orderObject.TradingAccount = this.products.availableOptions[0].TradingAccount
                this.orderObject.DeliveryFlag = this.products.availableOptions[0].DeliveryFlag
                if (this.clientMarketWatchList.clientName == 'Ajcon') {
                    var lengthData = Object.keys(this.products.availableOptions).length;
                    //console.log("lengthData",lengthData)
                    for (var temp = 0; temp < lengthData; temp++) {
                        if (this.products.availableOptions[temp].DeliveryFlag === "DEL") {
                            this.defaultTradingAccount = { TradingAccount: this.products.availableOptions[temp].TradingAccount }
                            this.orderObject.TradingAccount = this.products.availableOptions[temp].TradingAccount
                            this.orderObject.DeliveryFlag = this.products.availableOptions[temp].DeliveryFlag
                        }
                    }
                }
            }
        }
    }
    BindOrderTerms() {
        // console.log("this.products.availableOptions-->", this.products);
        var ExchangeTermsList = this.clientUserData.ExchangeTermsList;
        var ExchangeWiseList = ExchangeTermsList.split('^');
        var ExchangePermit = 0;
        for (var i = 0; i < ExchangeWiseList.length; i++) {
            if (ExchangeWiseList[i] == this.item.exchange) {
                ExchangePermit = 1;
                break;
            }
        }
        if (ExchangePermit == 1) {

            // var OrderTerms = ExchangeWiseList[i + 1].split('~');
            // var OrderTermsVTD = this.clientUserData.VTDAllowedToProducts.split('~');
            // //console.log("var OrderTermsVTD",OrderTermsVTD)
            // var j = 0;
            // for (var tempi3 = 0; tempi3 < OrderTerms.length; tempi3++) {
            //     //console.log("this.products.length",this.products.availableOptions.length)
            //     this.orderTerms.push(OrderTerms[tempi3]);
            //     //---if order terms has already been set by modify order, then identify which one matches and set variable j.
            //     //---then use variable j to set the default option
            //     if (OrderTerms[tempi3] == this.orderObject.OrderTerms) {
            //         j = tempi3
            //     };
            // }

            // for (var tempFlag = 0; tempFlag < OrderTermsVTD.length; tempFlag++) {
            //     for (var tempFlagProduct = 0; tempFlagProduct < this.products.availableOptions.length; tempFlagProduct++) {
            //         // console.log("OrderTermsVTD",OrderTermsVTD[tempFlag])
            //         // console.log("this.products",this.products.availableOptions[tempFlagProduct])
            //         if (this.products.availableOptions.TradingAccount != this.products.availableOptions[tempFlagProduct].TradingAccount) {
            //             if (OrderTermsVTD[tempFlag] == this.products.availableOptions[tempFlagProduct].TradingAccount) {
            //                 this.orderTermSelected = this.orderTerms[j];
            //                 this.orderObject.OrderTerms = this.orderObject.OrderTerms ? this.orderObject.OrderTerms : this.orderTermSelected;

            //                 if(this.orderObject.TermValidity && this.orderObject.OrderTerms == "VTD"){
            //                     this.orderObject.TermValidity = this.formatDate(this.orderObject.TermValidity)
            //                 }
            //                 //console.log("this.orderTerms",this.orderTerms)
            //                 // var indexOfOrderTerms = this.orderTerms.indexOf("VTD");
            //                 // if (indexOfOrderTerms > -1) {
            //                 //     this.orderTerms.splice(indexOfOrderTerms, 1);
            //                 // }
            //             }
            //         }

            //     }


            var OrderTerms = ExchangeWiseList[i + 1].split('~');
            var OrderTermsVTD = this.clientUserData.VTDAllowedToProducts.split('~');
            var j = 0;
            this.orderTerms = []

            for (var tempi3 = 0; tempi3 < OrderTerms.length; tempi3++) {
                this.orderTerms.push(OrderTerms[tempi3]);
            }

            for (let setDay = 0; setDay < this.orderTerms.length; setDay++) {
                // this.orderTerms.push(OrderTerms[tempi3]);
                if((this.orderTerms[setDay]).toUpperCase() == 'DAY' && !this.isModData){
                    this.orderObject.OrderTerms = this.orderTerms[setDay]
                    this.orderTermSelected = this.orderTerms[setDay]
                } else {
                 this.orderTermSelected = this.orderObject.OrderTerms ? this.orderObject.OrderTerms : this.orderTerms[0]

                }
            }

        //  this.orderTermSelected = this.orderObject.OrderTerms ? this.orderObject.OrderTerms : this.orderTerms[0]
         this.orderObject.OrderTerms = this.orderTermSelected;


         if (this.orderObject.TermValidity && this.orderObject.OrderTerms == "VTD") {
                this.orderObject.TermValidity = this.formatDate(this.orderObject.TermValidity)
            }



















            //console.log("this.orderTerms after",this.orderTerms)
        } else {
            //alert($scope.item.exchange + " Order Terms is not mapped to the user.");
        }
        // if (this.orderTermSelected == undefined) {
        //     this.orderTermSelected = this.orderTerms[j];
        // };
        //--Set the order term in order object -
        // this.orderObject.OrderTerms = this.orderTermSelected;
    }


    //---Place order --
    placeOrder(placeObj) {
        if(this.activeAction == 'B'){
            this.orderObject.BuySellType = 'Buy';
            this.orderObject.BuySellIndicator= 'B';
            this.orderObject.DeliveryFlag = this.products.availableOptions[0].DeliveryFlag
        } else {
            this.orderObject.BuySellType = 'Sell'
            this.orderObject.DeliveryFlag = 'AUTO'
            this.orderObject.BuySellIndicator= 'S';

        }
        
        //console.log("this.clientUserData",this.clientUserData)
        var tPass = localStorage.getItem("validateTradePassFlg")
        if (tPass != null && tPass != undefined && tPass == 'true') {
            this.clientUserData.tradeVarification = true;
        } else {
            this.clientUserData.tradeVarification = false;
        }

        if (this.clientUserData.guestLogin) {
            swal({
                title: "Error!",
                text: "You are Guest User.You are not allowed to trade.Please contact us with our representative for further instructions.",
                allowOutsideClick: true,
                showConfirmButton: true
            });
            return;
        } else if (!this.clientUserData.tradeVarification && (this.clientMarketWatchList.clientName == 'Jetrade' || this.clientMarketWatchList.clientName == 'Arch' || this.clientMarketWatchList.clientName == 'Gogia' || this.clientMarketWatchList.clientName == 'Nirman')) {
            this.validatePw()
            swal({
                //     // html:true, 
                // title: 'Trade Password',
                // // text: "Required Trade Password",
                // html: `<button id="gTradePw">CLick Me</button>`,
                // input: 'password',
                // inputPlaceholder: "Trade Password",
                // showCancelButton: true,
                // confirmButtonText: 'Varify',
                // showLoaderOnConfirm: true,
                // showCloseButton: false,
                // showConfirmButton: true,

                title: 'Trade Password',
                html: "<span class='black'>To generate trade password </span> <a id='gTradePw' class='blue'>Click here</a>",
                input: 'password',
                inputPlaceholder: "Trade Password",
                showCancelButton: true,
                confirmButtonText: 'Verify',
                showLoaderOnConfirm: true,
                inputValidator: (inputValue) => {
                    if (!inputValue) {
                        //---input field is blank ---
                        return !inputValue && 'Please enter Trade Password!'
                    } else {
                        // this.ev.publish('tradePassword',{inputValue:inputValue,flg:"ByOrdFrm"});
                        this.validateTradePw(inputValue)
                    }
                }
            })

            return;
        }

        if (this.isModData) {
            // console.log("this.originalModifyData",this.originalModifyData)
            // console.log("this.orderObject",this.orderObject)
            if (this.showPriceForLimitOrder) {
                var elem: any = this.messageInput;
                elem._native.nativeElement.blur();
            }
            //console.log("this.originalModifyData.Price",this.originalModifyData.Price)
            //console.log("this.orderObject.Price",this.orderObject.Price)


            if (this.clientMarketWatchList.clientName == 'Bhumika' || this.clientMarketWatchList.clientName == 'Canara' && this.prvPage == 'OrderBookPage') {
                // && (Number(this.originalModifyData.TermValidity) == Number(this.orderObject.TermValidity))
                if (placeObj != 'marginReport') {
                    if ((this.originalModifyData.Quantity == this.orderObject.Quantity || this.originalModifyData.RemainingQty == this.orderObject.Quantity)
                        && (Number(this.originalModifyData.Price) == Number(this.orderObject.Price))
                        && (this.originalModifyData.OrderTerms == this.orderObject.OrderTerms)
                        && (Number(this.originalModifyData.TriggerPrice) == Number(this.orderObject.TriggerPrice))
                        && (Number(this.originalModifyData.DisclosedQuantity) == Number(this.orderObject.DisclosedQuantity))
                    ) {
                        swal({
                            title: "Info!",
                            text: "No attribute changes",
                            timer: 1500,
                            allowOutsideClick: true,
                            showConfirmButton: true
                        });
                        return
                    }
                }
            } else if (this.clientMarketWatchList.clientName == 'Jetrade' || this.clientMarketWatchList.clientName == 'ATS' || this.clientMarketWatchList.clientName == 'ATSNew' && this.prvPage == 'OrderBookPage') {
                // && (Number(this.originalModifyData.TermValidity) == Number(this.orderObject.TermValidity))
                if (placeObj != 'marginReport') {
                    if ((this.originalModifyData.Quantity == this.orderObject.Quantity || this.originalModifyData.RemainingQty == this.orderObject.Quantity)
                        && (Number(this.originalModifyData.Price) == Number(this.orderObject.Price))
                        && (this.originalModifyData.OrderTerms == this.orderObject.OrderTerms)
                        && (Number(this.originalModifyData.TriggerPrice) == Number(this.orderObject.TriggerPrice))
                        && (Number(this.originalModifyData.DisclosedQuantity) == Number(this.orderObject.DisclosedQuantity))
                    ) {
                        swal({
                            title: "Info!",
                            text: "No attribute changes",
                            timer: 1500,
                            allowOutsideClick: true,
                            showConfirmButton: true
                        });
                        return
                    }
                }
            } else if (this.clientMarketWatchList.clientName == 'MTradez' && this.prvPage == 'OrderBookPage') {
                // && (Number(this.originalModifyData.TermValidity) == Number(this.orderObject.TermValidity))
                if (placeObj != 'marginReport') {
                    if ((this.originalModifyData.Quantity == this.orderObject.Quantity)
                        && (Number(this.originalModifyData.Price) == Number(this.orderObject.Price))
                        && (this.originalModifyData.OrderTerms == this.orderObject.OrderTerms)
                        && (Number(this.originalModifyData.TriggerPrice) == Number(this.orderObject.TriggerPrice))
                        && (Number(this.originalModifyData.DisclosedQuantity) == Number(this.orderObject.DisclosedQuantity))
                    ) {
                        swal({
                            title: "Info!",
                            text: "No attribute changes",
                            timer: 1500,
                            allowOutsideClick: true,
                            showConfirmButton: true
                        });
                        return
                    }
                }
            } else {

                if (placeObj != 'marginReport') {
                    if (this.originalModifyData.Quantity == this.orderObject.Quantity && Number(this.originalModifyData.Price) == Number(this.orderObject.Price)
                        && this.originalModifyData.OrderTerms == this.orderObject.OrderTerms && Number(this.originalModifyData.TriggerPrice) == Number(this.orderObject.TriggerPrice)
                        && Number(this.originalModifyData.DisclosedQuantity) == Number(this.orderObject.DisclosedQuantity) && Number(this.originalModifyData.TermValidity) == Number(this.orderObject.TermValidity)
                    ) {
                        swal({
                            title: "Info!",
                            text: "No attribute changes",
                            timer: 1500,
                            allowOutsideClick: true,
                            showConfirmButton: true
                        });
                        return
                    }
                }
            }




        }
        //---check if disclosed quantity has been set as blank or zero. in which case it gets undefined and set it manually as zero.
        if (this.orderObject.DisclosedQuantity == undefined || this.orderObject.DisclosedQuantity === '') {
            this.orderObject.DisclosedQuantity = '0';
        }
        //check if stop loss has been set as blank or zero. in which case it gets undefined and set it manually as zero.
        if (this.orderObject.TriggerPrice == undefined || this.orderObject.TriggerPrice === '') {
            this.orderObject.TriggerPrice = '0';
        }
        if (this.showTriggerPrice == false) {
            this.orderObject.TriggerPrice = '0';
        }

        //---If delivery flag is undefined show the alert --
        if (this.orderObject.DeliveryFlag == undefined || this.orderObject.DeliveryFlag == '') {
            swal({
                title: "Error!",
                text: "Please select product type first",
                timer: 1500,
                allowOutsideClick: true,
                showConfirmButton: true
            });
            return;
        }
        //---verify the input parameters prior to proceeding
        //---check if Sl is active then Trigger Price is mendotary else if it is RL then not mendotary
        if (this.checkboxModelrlsl == true) {
            //this.advanceCheckbox =true;
            if (this.orderObject.TriggerPrice <= 0) {
                swal({
                    title: "Error!",
                    text: "Trigger Price is mandatory",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        //---check for TickSize either in fractional value or not, if fractional then check multiply with price is fracktional the invalid

        // console.log("this.orderObject.Price", this.orderObject)
        if (this.orderObject.Price % 1 != 0) {
            this.numlenValue = this.orderObject.Price.toString().split(".")[1].length;
            this.orderObject.Price = Number(this.orderObject.Price);
            if (this.numlenValue == 1) {
                this.myvalueformated = this.orderObject.Price.toFixed(2);
            }
            else if (this.numlenValue == 3) {
                this.myvalueformated = this.orderObject.Price.toFixed(4);
            }
            else {
                this.myvalueformated = this.orderObject.Price;
            }
            var myval = this.myvalueformated / this.TickSize;
            var roundValue = Math.round(myval);
            if (roundValue % 1 != 0) {
                this.checkTckSize = false;
            }
            else {
                this.checkTckSize = true;
            }
            if (this.checkTckSize == false) {
                swal({
                    title: "Error!",
                    text: "Invalid tick size entered. Price should be in multipler by tick size of :" + this.TickSize,
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        if (this.orderObject.TriggerPrice > 0) {
            if (this.orderObject.OrderCategory == 'SPREAD') {
                swal({
                    title: "Error!",
                    text: "Trigger Price Not allowed",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
            if (this.orderObject.Market != 1) {
                if (parseFloat(this.orderObject.TriggerPrice) > parseFloat(this.orderObject.Price)) {
                    swal({
                        title: "Error!",
                        text: "Invalid Trigger Price entered.Trigger price cannot be greater than order price.",
                        timer: 2000,
                        allowOutsideClick: true,
                        showConfirmButton: true
                    });
                    return;
                }
            }
        }
        if (this.orderObject.Quantity <= 0 || this.orderObject.Quantity >= 10000000) {
            swal({
                title: "Error!",
                text: "Invalid Quantity entered",
                timer: 1500,
                allowOutsideClick: true,
                showConfirmButton: true
            });
            return;
        }
        if (this.orderObject.DisclosedQuantity < 0) {
            swal({
                title: "Error!",
                text: "Disclosed Volume is lesser than 10 percent of order Quantity",
                timer: 1500,
                allowOutsideClick: true,
                showConfirmButton: true
            });
            return;
        }
        // if (this.orderObject.DisclosedQuantity >= 1) {
        //     if (this.orderObject.Exchange == 'FONSE' || this.orderObject.Exchange == 'CDNSE') {
        //         swal({
        //             title: "Error!",
        //             text: "Disclosed Quantity Not allowed",
        //             timer: 1500,
        //             allowOutsideClick: true,
        //             showConfirmButton: true
        //         });
        //         return;
        //     } else if (this.orderObject.OrderCategory == 'SPREAD') {
        //         swal({
        //             title: "Error!",
        //             text: "Disclosed Quantity Not allowed",
        //             timer: 1500,
        //             allowOutsideClick: true,
        //             showConfirmButton: true
        //         });
        //         return;
        //     }
        // }
        //---
        if (this.orderObject.DisclosedQuantity >= 1) {
            if (this.orderObject.OrderCategory == 'SPREAD') {
                swal({
                    title: "Error!",
                    text: "Disclosed Quantity Not allowed",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            } else if (this.orderObject.Exchange == 'NCDEX') {
                if ((this.orderObject.Quantity / 100 * 10) <= this.orderObject.DisclosedQuantity && this.orderObject.Quantity > this.orderObject.DisclosedQuantity) {

                } else {
                    swal({
                        title: "Error!",
                        text: "Disclosed Volume is lesser than 10 percent of order Quantity",
                        timer: 1500,
                        allowOutsideClick: true,
                        showConfirmButton: true
                    });
                    return;
                }
            } else if (this.orderObject.DisclosedQuantity < (this.orderObject.Quantity / 10)) {
                swal({
                    title: "Error!",
                    text: "Invalid Disclosed  quantity,Disclosed quantity should not be less than 10% of order quantity.",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            } else if (parseFloat(this.orderObject.DisclosedQuantity) > parseFloat(this.orderObject.Quantity)) {
                swal({
                    title: "Error!",
                    text: "Disclosed Quantity is greater than Order quantity",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        if (this.orderObject.Quantity % this.lotSize !== 0) {
            swal({
                title: "Error!",
                text: "Invalid Quantity entered, lot size is " + this.lotSize,
                timer: 1500,
                showConfirmButton: true
            });
            return;
        }
        if (this.orderObject.DisclosedQuantity % 1 !== 0) {
            swal({
                title: "Error!",
                text: "Invalid Disclosed Quantity entered,Disclosed quantity cannot be in decimal.",
                timer: 1500,
                showConfirmButton: true
            });
            return;
        }
        if (this.orderObject.OrderCategory == 'SPREAD') {
            if (this.orderObject.Market == 1) {
                swal({
                    title: "Error!",
                    text: "Market Order not allowed in spread",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        //---special exchange case handling for FONSE,FOBSE and CDNSE as the feedAPI does not recognize these two exchanges
        //---and they must be sent as NSE adn BSE respectively
        if (this.item.exchange == "FONSE") {
            this.orderObject.Scrip = this.item.reconstructedTicker;
        };
        if (this.item.exchange == "FOBSE") {
            this.orderObject.Scrip = this.item.reconstructedTicker;
        };
        if (this.item.exchange == "CDNSE") {
            this.orderObject.Scrip = this.item.reconstructedTicker;
        };
        if (this.item.exchange == "CDBSE") {
            this.orderObject.Scrip = this.item.reconstructedTicker;
        };
        if (this.item.exchange == "BSE" || this.item.exchange == "FOBSE") {
            this.orderObject.DeliveryTerms = 'OD';
        };

        if (this.orderObject.TriggerPrice > 0 && this.orderObject.OrderTerms == "GTD") {
            swal({
                title: "Error!",
                text: "GTD is not allowed in Stop loss order",
                timer: 1500,
                allowOutsideClick: true,
                showConfirmButton: true
            });
            return;
        }
        if (this.orderObject.TriggerPrice > 0 && this.orderObject.OrderTerms == "GTC") {
            swal({
                title: "Error!",
                text: "GTC is not allowed in Stop loss order",
                timer: 1500,
                allowOutsideClick: true,
                showConfirmButton: true
            });
            return;
        }
        if (this.showTriggerPrice) {
            if (this.orderObject.TriggerPrice <= 0) {
                swal({
                    title: "Error!",
                    text: "Invalid Trigger Price entered.Trigger price cannot be less than or equal to zero.",
                    timer: 2000,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        if (this.orderObject.OrderCategory == 'SPREAD') {
            if (this.orderObject.OrderTerms == "GTC") {
                swal({
                    title: "Error!",
                    text: "GTC is not allowed in Spread order",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;

            }
            if (this.orderObject.OrderTerms == "GTD") {
                swal({
                    title: "Error!",
                    text: "GTD is not allowed in Spread order",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        //console.log("this.orderObject",this.orderObject)
        if (this.orderObject.Market != 1 && this.orderObject.OrderCategory != 'SPREAD') {
            //alert("Test")
            if ((this.orderObject.Price == 0 || this.orderObject.Price <= 0) && !(this.orderObject.Exchange =='MCX' || this.orderObject.Exchange == 'NCDEX')) {
                swal({
                    title: "Error!",
                    text: "Invalid Price entered",
                    timer: 1500,
                    allowOutsideClick: true,
                    showConfirmButton: true
                });
                return;
            }
        }
        if (this.orderObject.OrderTerms == "GTD" || this.orderObject.OrderTerms == "VTD") {
            if (this.orderObject.TermValidity == "") {
                swal({
                    title: "Error!",
                    text: "Please select a valid date",
                    timer: 2000,
                    showConfirmButton: true,
                    allowOutsideClick: true
                });
                return;
            }
            var Validity = this.formatDate(this.orderObject.TermValidity);
            this.orderObject.Validity = Validity;
        }
        //console.log("this.orderObject",this.orderObject)
        //---build buy order querystring---
        var BuyOrderqString = '{';
        BuyOrderqString += '"SessionNo":"' + this.orderObject.SessionNo + '",';
        BuyOrderqString += '"ClientCode":"' + this.orderObject.ClientCode + '",';
        BuyOrderqString += '"OrderPlacedBy":"' + this.orderObject.OrderPlacedBy + '",';
        BuyOrderqString += '"Source":"' + this.orderObject.Source + '",';
        BuyOrderqString += '"TradingAccount":"' + this.orderObject.TradingAccount + '",';
        BuyOrderqString += '"Exchange":"' + this.orderObject.Exchange + '",';
        BuyOrderqString += '"Scrip":"' + encodeURIComponent(this.orderObject.Scrip) + '",';
        BuyOrderqString += '"Quantity":"' + this.orderObject.Quantity + '",';
        BuyOrderqString += '"Price":"' + this.orderObject.Price + '",';
        BuyOrderqString += '"Market":"' + this.orderObject.Market + '",';
        BuyOrderqString += '"OrderTerms":"' + this.orderObject.OrderTerms + '",';
        BuyOrderqString += '"BuySellIndicator":"' + this.orderObject.BuySellIndicator + '",';
        BuyOrderqString += '"BuySellType":"' + this.orderObject.BuySellType + '",';
        BuyOrderqString += '"TriggerPrice":"' + this.orderObject.TriggerPrice + '",';
        BuyOrderqString += '"DeliveryTerms":"' + this.orderObject.DeliveryTerms + '",';
        BuyOrderqString += '"MarketSegment":"' + this.orderObject.MarketSegment + '",';
        BuyOrderqString += '"DeliveryFlag":"' + this.orderObject.DeliveryFlag + '",';
        BuyOrderqString += '"OrderCategory":"' + this.orderObject.OrderCategory + '",';
        if (this.isMarginPlusOrder) {
            this.orderObject.OrderType = "MARGINPLUS";
            // BuyOrderqString += '"LimitPrice":"' + this.orderObject.MPSLPrice + '",';
        }
        BuyOrderqString += '"OrderType":"' + this.orderObject.OrderType + '",';
        BuyOrderqString += '"AccRefCode":"' + this.orderObject.AccRefCode + '",';
        BuyOrderqString += '"AddModifyFlag":"' + this.orderObject.AddModifyFlag + '",';
        if (this.orderObject.OrderTerms == "GTD" || this.orderObject.OrderTerms == "VTD") {
            BuyOrderqString += '"TermValidity":"' + this.orderObject.Validity + '",';
        } else {
            BuyOrderqString += '"TermValidity":" ",';
        }
        BuyOrderqString += '"DisclosedQuantity":"' + this.orderObject.DisclosedQuantity + '",';
        BuyOrderqString += '"ProductType":"' + this.orderObject.ProductType + '",';
        BuyOrderqString += '"MinQuantity":"' + this.orderObject.MinQuantity + '",';
        BuyOrderqString += '"Remarks":"' + this.orderObject.Remarks + '",';
        //---add tranID to BuyOrderQuerystring if isModifyOrder is true---
        if (this.orderObject.isModifyOrder == true) {
            BuyOrderqString += '"TranID":"' + this.orderObject.TranID + '",';
            BuyOrderqString += '"OrderId":"' + this.orderObject.OrderId + '",';
            BuyOrderqString += '"OriginalRemainingQty":"' + this.orderObject.OriginalRemainingQty + '",';
        }
        //add tranID to BuyOrderQuerystring if isSquareoffOrder is true
        else if (this.orderObject.isSquareoffOrder == true) {
            BuyOrderqString += '"isSquareOff":"1",';
        }
        if (this.amo.checkedData == true) {
            this.orderObject.AMOBulkIndicator = 'AMO'
        }
        //---For margin plus order only
        //BuyOrderqString += '"MPSLPrice":"' + this.orderObject.TriggerPrice + '",';
        BuyOrderqString += '"MPLOPrice":"' + this.orderObject.MPLOPrice + '",';
        BuyOrderqString += '"AMOBulkIndicator":"' + this.orderObject.AMOBulkIndicator + '"}';
        //console.log("this.BuyOrderqString",BuyOrderqString)

        //---Swal alert text section --
        this.alerttext = "You are placing an order to"+ this.orderObject.BuySellType + "<br>";
        this.alerttext += this.orderObject.Scrip + " : " + this.orderObject.Quantity + " @ ";
        if (this.orderObject.Market === 1) {
            this.alerttext += "Market" + "<br>";
        } else {
            this.alerttext += this.orderObject.Price + "<br>";
        }
        this.alerttext += "Product : " + this.orderObject.TradingAccount + "<br>";
        this.alerttext += "Order Term : " + this.orderObject.OrderTerms + "<br>";
        if (this.orderObject.TriggerPrice > 0) {
            this.alerttext += "Trigger Price : " + this.orderObject.TriggerPrice + "<br>";
        }
        if (this.isMarginPlusOrder) {
            this.alerttext += "Limit Price : " + this.orderObject.MPSLPrice + "<br>";
            this.alerttext += "Profit Price : " + this.orderObject.MPLOPrice + "<br>";

        }
        this.alerttext += this.orderObject.AMOBulkIndicator;

        //---Placing normal order--
        if (placeObj == 'addOrder') {
            swal({
                title: 'Place Order?',
                html: this.alerttext,
                type: 'info',
                showCancelButton: true,
                cancelButtonText: "No, cancel order!",
                confirmButtonColor: "#387ef5",
                confirmButtonText: "Yes, confirm order!",
                showLoaderOnConfirm: true,
            }).then((result) => {
                if (result.value) {
                    //---User want to Place order--
                    //--- if margin plus order --
                    if (this.isMarginPlusOrder) {
                        placeObj = 'marginplusOrder'
                    }
                    this.buySellManager.placeOrder(BuyOrderqString, this.orderObject.isModifyOrder, placeObj).then((data) => {
                        this.place_order_result = data;

                        if (this.place_order_result.TranId == '0') {
                            swal({
                                title: "Order Status",
                                text: JSON.stringify(this.place_order_result.Message),
                                showCancelButton: true,
                                showConfirmButton: false,
                                cancelButtonText: "Close"
                            });
                        } else {
                            swal({
                                title: "Order Status",
                                text: JSON.stringify(this.place_order_result.Message),
                                type: "info",
                                showCancelButton: true,
                                cancelButtonText: "Close",
                                confirmButtonColor: "#387ef5",
                                confirmButtonText: "Order Detail"
                            }).then((result) => {
                                if (result.value) {
                                    // swal({
                                    //     title: "Redirecting",
                                    //     text: "loading order details",
                                    //     type: "success",
                                    //     showConfirmButton: false,
                                    //     timer: 350
                                    // });
                                    //---Code to redirect to order Detail page goes here --
                                    // this.navCtrl.push('OrderBookPage');
                                    // this.navCtrl.pop()
                                    this.segmentChanged('OrderBook')
                                    this.isSelected = 'OrderBook'
                                }
                            })
                        }
                    }, err => {
                        swal({
                            // swal({
                            //    title: "OOPS!",
                            //   text: 'Network Issue ! Please retry or check your network Connection.',
                            //  type: "error"
                            // });
                        });
                    });
                }
            })
        } else {
            //---Getting margin report computation
            //---User want to Get margin report order--
            this.buySellManager.placeOrder(BuyOrderqString, this.orderObject.isModifyOrder, placeObj).then((data) => {
                this.margin_report_result = data;
                if (this.margin_report_result.ErrorCode == '0') {
                    swal({
                        title: "Margin Requirement",
                        html: this.margin_report_result.CustomMessage,
                        showCancelButton: true,
                        cancelButtonText: "Close",
                    });
                } else {
                    swal({
                        title: "Error",
                        html: this.margin_report_result.Message,
                        showCancelButton: true,
                        cancelButtonText: "Close",
                    });
                }
            }, err => { });
        }

    }
    //--Function to format date --
    formatDate(date) {
        var dd = new Date(date),
            month = '' + (dd.getMonth() + 1),
            day = '' + dd.getDate(),
            year = dd.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return [year, month, day].join('-');
    }
    //---Service to get current market status --
    getMarketStatus() {
        this.exchangeInfoManager.getExchInfo().then((data) => {
            this.exchangeInfo_result = data;
            if (this.exchangeInfo_result.ErrorCode == 0) {
                this.ExchangeStatusFullList = JSON.parse(this.exchangeInfo_result.data);
                this.ExchangeStatusFullList.forEach((value, index) => {
                    if (this.ExchangeStatusFullList[index].Exchange == this.item.exchange + 'AMO') {
                        if (this.ExchangeStatusFullList[index].Status == "OPEN") {
                            this.AMOallowed = true;
                            this.amo.checkedData = true;
                            // console.log("this.amo.checkedData", this.amo.checkedData)
                            if (this.amo.checkedData == true) {
                                this.orderObject.AMOBulkIndicator = 'AMO'
                            }
                        } else {
                            this.AMOallowed = false;
                            //this.amo.checkedData=false
                        }
                    }
                });
            }
        }, err => { })
    }
    //---Inc quantity function -- this.itemMod.OpenQuantity
    qtyPlus() {
        if (this.orderObject.Quantity === '') {
            this.orderObject.Quantity = 0;
        }

        if (parseInt(this.orderObject.Quantity) >= parseInt(this.itemMod.OpenQuantity)) {
            this.disablePlusButton = true;
        } else {
            var wholeLot = Number(this.orderObject.Quantity) % Number(this.lotSize);
            this.orderObject.Quantity = (Number(this.orderObject.Quantity) + Number(this.lotSize)) - wholeLot;
        }
    }
    //---Dec quantity --
    qtyMinus() {
        if (this.orderObject.Quantity === '') {
            this.orderObject.Quantity = 0;
        }
        if (parseInt(this.orderObject.Quantity) <= parseInt(this.itemMod.OpenQuantity)) {
            this.disablePlusButton = false;
        }
        if (Number(this.orderObject.Quantity) - Number(this.lotSize) >= 0) {
            var wholeLotMinus = Number(this.orderObject.Quantity) % Number(this.lotSize);
            //console.log("wholeLotMinus",wholeLotMinus)
            this.orderObject.Quantity = (Number(this.orderObject.Quantity) - Number(this.lotSize)) - wholeLotMinus;
        }
    }
    //---buy page --
    // buyItem() {
    //     this.msg = "Inside Buy Page"
    //     this.commonService.showToast(this.msg);
    // }
    //---Sell page --
    sellItem() {
        //--Apply the logic of valid trade password for login --
        this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: this.item });
        this.navCtrl.push('SellPage', { usersellData: this.item, clientUserData: this.clientUserData });
    }
    //---Sell page --
    marketDepth() {
        //--Apply the logic of valid trade password for login --
        this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: this.item });
        this.navCtrl.push('MarketDepthPage', { userMWDepthData: this.item, clientUserData: this.clientUserData });
    }
    //---Show trriger price for stop loss order --
    // giveStopLossPrice() {
    //     this.showTriggerPrice = !this.showTriggerPrice;

    //     if (this.showTriggerPrice == false) {
    //         this.checkboxModelrlsl = false
    //     }
    // }


    giveStopLossPrice(value) {
        if (value.value == true) {
            this.showTriggerPrice = true;
            console.log("value", value);
        }
        else {
            this.showTriggerPrice = false;
            this.orderObject.TriggerPrice = 0;
        }
        // debugger
        // console.log("Show trigger price toggle",this.showTriggerPriceToggle)
        // if(this.showTriggerPriceToggle)
        // this.showTriggerPrice=true
        // else
        // this.orderObject.TriggerPrice = 0;
        if (this.showTriggerPrice == false) {
            this.checkboxModelrlsl = false
        }
    }


    changeFunction(priceObj) {
        if (this.isModData) {
            this.orderObject.Price = priceObj;
        }
    }

    qtyBoxClick() {
        var elem: any = this.quantityField;
        elem._native.nativeElement.focus();
        // input.focus(); //sets focus to element
        var val = this.orderObject.Quantity; //store the value of the element
        this.orderObject.Quantity = ''; //clear the value of the element
        setTimeout(() => {
            this.orderObject.Quantity = val; //set that value back.
            this.disablePlusButton = false;
        }, 10);
    }
    validatePw() {
        setTimeout(_ => {


            document.getElementById("gTradePw").addEventListener("click", () => {
                console.log("CLicked");
                this.generateTradePw()
            });
        }, 1000)
    }


    generateTradePw() {
        // var GenerateTradePasswordString = '{';
        //   "Action":"' + LoginService.LoginUserData.Action + '",';
        // '"Source":"' + LoginService.LoginUserData.Source + '",';
        // '"UserId":"' + LoginService.LoginUserData.userId + '",';
        // GenerateTradePasswordString += '"Password":"' + LoginService.LoginUserData.password + '",';
        // GenerateTradePasswordString += '"SessionNo":"' + LoginService.LoginDetails.SessionNo + '",';
        // GenerateTradePasswordString += '"ClientIPAddress":"' + LoginService.LoginUserData.ClientIPAddress + '"';
        // GenerateTradePasswordString += '}';

        // Action:'',
        // Source:'',
        this.storage.get('userMaster').then((_userData_: any) => {
            if (_userData_ != null) {
                let obj = {
                    "UserId": _userData_.ClientCode,
                    "SessionNo": _userData_.SessionNo,
                }
                console.log("objjjjjj", obj);

                this.userManager.generateTradePassword(obj).then((data: any) => {
                    console.log(">>>>>>>>>>>>>>>>", data);
                    if (data.ErrorCode == 0) {
                        let toast = this.toast.create({
                            message: data.Message,
                            duration: 5000,
                            position: 'bottom'
                        });

                        toast.onDidDismiss(() => {
                            console.log('Dismissed toast');
                        });

                        toast.present();
                    }
                    else {
                        let toast = this.toast.create({
                            message: data.Message,
                            duration: 5000,
                            position: 'bottom'
                        });

                        toast.onDidDismiss(() => {
                            console.log('Dismissed toast');
                        });

                        toast.present();
                    }
                }).catch(err => {
                    console.log("Error in genearete pw", err);
                    let toast = this.toast.create({
                        message: 'Please try again',
                        duration: 5000,
                        position: 'bottom'
                    });

                    toast.onDidDismiss(() => {
                        console.log('Dismissed toast');
                    });

                    toast.present();
                })
            }
        })

        // ClientIPAddress:''



    }

    validateTradePw(TradePassword) {

        var storageData = localStorage.getItem("login_Data");

        this.storage.get("userMaster").then((data) => {
            if (storageData) {
                let obj = JSON.parse(storageData);
                let loginFrmData = {
                    "userId": obj.userId,
                    "password": obj.password,
                    "Source": 5,
                    "Action": "LOGIN",
                    "TradePassword": TradePassword,
                    "NewPassword": "",
                    "ClientIPAddress": 833,
                    "SessionNo": data.SessionNo,
                    "PAN": "",
                    "ValidateThrough": "U",
                    "DPID": "",
                    "mpinFlag": obj.mpinFlag
                }
                this.validateTradePassword(loginFrmData);
            }
        });
    }

    validateTradePassword(loginFrmData) {
        var randomNumber = Math.floor((Math.random() * 1000) + 1);
        loginFrmData.ClientIPAddress = randomNumber;
        // if (this.validateThrogh != 'ByOrdFrm') {
        // }
        this.commonService.showLoading();
        this.userManager.validateTradePassword(loginFrmData).then((data) => {
            let user_tradePassword_result: any = data;
            this.clientUserData.tradeVarification = true;
            this.commonService.hideLoading();
            //----Successfully login ---
            if (user_tradePassword_result.ErrorCode == '0') {
                let validateTradePassFlg = true;
                localStorage.setItem("validateTradePassFlg", JSON.stringify(validateTradePassFlg));
                // swal({
                //     title: "",
                //     text: JSON.stringify(user_tradePassword_result.Message),
                //     type: "info",
                // })
            }
            else {
                // this.commonService.hideLoading();
                swal({
                    title: "",
                    text: JSON.stringify(user_tradePassword_result.Message),
                    type: "info",
                })
            }
        }).catch(err => {
            this.commonService.hideLoading();
        })
    }

    handleBrodcastMessage(data) //for CoverTargetPrice and CoverTriggerPrice
    {
        console.log("Handle notification", data)
        if (data.CoverTargetPrice != '' && data.CoverTriggerPrice != '') {
            setTimeout(_ => {

                this.checkboxModel.value = "Market";

                this.isMarginPlusOrder = true;
                this.showTriggerPrice = true;
                // this.orderObject.CoverTriggerPrice=data.CoverTargetPrice;
                // this.orderObject.CoverTriggerPrice=
                // orderObject.MPLOPrice

                this.orderObject.MPSLPrice = data.OfferPrice;
                this.orderObject.MPLOPrice = data.CoverTargetPrice;
                this.orderObject.TriggerPrice = data.CoverTriggerPrice;

                console.log("Avail P", this.products.availableOptions);
                for (let i = 0; i < this.products.availableOptions.length; i++) {
                    if (this.products.availableOptions[i].DeliveryFlag == 'MPT') {
                        this.defaultTradingAccount.TradingAccount = this.products.availableOptions[i].TradingAccount;
                    }
                }

            }, 1000)


        }
        {

        }
    }
    reserchMsgProduct() {
        setTimeout(_ => {
            let str: any = this.item;
            if (str.Message) {
                // this.products.availableOptions=this.products.availableOptions.filter(x=>{ return x.DeliveryFlag=='DEL' || x.DeliveryFlag=='MAR' })
                let n = str.Message.search("INTRADAY");
                if (n != -1)
                    this.defaultTradingAccount.TradingAccount = 'INTRADAY';
            }
        }, 1000)

    }











    getRadiovalue(v){
        console.log(v)
        this.orderobj.orderType = v;
      }

      public action(val){
        // console.log("val----> ", val)
        this.activeAction =val
        if(this.activeAction == 'B'){
            this.orderObject.BuySellType = 'Buy'
            this.orderObject.BuySellIndicator= 'B'
      
        } else {
            this.orderObject.BuySellIndicator= 'S',
            this.orderObject.BuySellType = 'Sell'
            this.orderObject.DeliveryFlag = 'AUTO'
        }
      }

      public connectSocket(){

        var th = this
        this.getReportManager.getMarketDepthReport(encodeURIComponent(this.item.ticker), this.item.exchange).then((data) => {
            let marketDepth_result:any = data;
            //---successfully fetched the market depth result --
            try {
              if (marketDepth_result.ErrorCode == 0) {
                // th.depthdata = JSON.parse(JSON.stringify(JSON.parse(marketDepth_result.data)));
                th.depthdata = JSON.parse(marketDepth_result.data);
                console.log(JSON.parse("marketDepth_result ----->",th.depthdata));
              } else {
                // this.depthdata = [
                //   {
                //     "Ticker": "", "DateTime": "", "depth":
                //       [
                //         { "BBR": "0", "BBQ": "0", "BO": "0", "BSR": "0", "BSQ": "0", "SO": "0" },
                //         { "BBR": "0", "BBQ": "0", "BO": "0", "BSR": "0", "BSQ": "0", "SO": "0" },
                //         { "BBR": "0", "BBQ": "0", "BO": "0", "BSR": "0", "BSQ": "0", "SO": "0" },
                //         { "BBR": "0", "BBQ": "0", "BO": "0", "BSR": "0", "BSQ": "0", "SO": "0" },
                //         { "BBR": "0", "BBQ": "0", "BO": "0", "BSR": "0", "BSQ": "0", "SO": "0" }
                //       ],
      
                //   }
                // ];
              }
            } catch (err) { }

        })

        setTimeout(() => {
            this.keylist = 'ADD^2^' + this.GetExchangeCode(this.item.exchange) + '.1!' + this.item.ticker + '^' + this.GetExchangeCode(this.item.exchange) + '.2!' + this.item.ticker;
            this.socket.send(this.keylist.toUpperCase());
           
          this.websocketUtilityManager.getFeedAfterSubscribeMDepth(th.depthdata, this.item).then((data) => {
            this.webSocket_Data = data;
            //console.log("this.webSocket_Data-->>>>>",this.webSocket_Data)
          })
        }, 1000);
       
    
    }

    public getMarginReport(BuyOrderqString) {
        this.popupData = { TGAMessage: "" };
        // this.popupData.TGAMessage = "";
        this.buySellManager.placeOrder(BuyOrderqString, this.orderObject.isModifyOrder, "marginReport").then((data) => {
            this.margin_report_result = data;
            if (this.margin_report_result.ErrorCode == '0') {

                if (this.margin_report_result.CustomMessage) {
                    let CustomMessage = this.margin_report_result.CustomMessage.split("\r\r");
                    this.popupData.availableBalance = CustomMessage[0];
                    this.popupData.orderMargin = CustomMessage[1];
                    this.popupData.tentativeBalance = CustomMessage[2];

                    this.avlBalance = CustomMessage[0].split(":")[1]
                    // this.orderMargin = CustomMessage[1].split(":")[1]
                    
                    // if(Number(this.avlBalance) < Number(this.orderMargin)) {
                    //     this.shortAmt = Number(this.orderMargin) - Number(this.avlBalance)
                    // } else {
                    //     this.shortAmt = 0
                    // }

                }
                if (this.margin_report_result.TGAMessage) {
                    this.popupData.TGAMessage = this.margin_report_result.TGAMessage.split("\r\r");
                }
            } else {
                swal({
                    title: "Error",
                    html: this.margin_report_result.Message,
                    showCancelButton: true,
                    cancelButtonText: "Close",
                });
            }
        }, err => { });
    }

    GetExchangeCode(Exchange) {
        var strCode = "0";
        switch (Exchange) {
          case "NSE":
          case "FONSE":
            strCode = "4";
            break;
          case "BSE":
          case "FOBSE":
            strCode = "1";
            break;
          case "ACE":
            strCode = "10";
            break;
          case "CDNSE":
            strCode = "13";
            break;
          case "MCX":
            strCode = "7";
            break;
          case "COMNSE":
            strCode = "5";
            break;
          case "NCDEX":
            strCode = "8";
            break;
          case "MCXSX":
            strCode = "14";
            break;
          case "NSEL":
            strCode = "36";
            break;
          case "MCXSXEQ":
            strCode = "64";
            break;
          case "MCXSXFO":
            strCode = "65";
            break;
          case "CDBSE":
            strCode = "17";
            break;
          case "NEPSE":
              strCode = "25";
          break;
        }
        return (strCode);
      }
     



      loadMarginReport(){
        this.getReportManager.getScripOrderReport("ALL","ClientBuyingPowerReport",this.userData,"").then((data)=>{
          this.marginReport_result = data;
          if(this.marginReport_result.ErrorCode == 0){
           this.myCollateral =  JSON.parse(this.marginReport_result.reportTable)[0].CASHDEPOSITED;
           this.myCollateral = parseFloat(this.myCollateral).toFixed(2)
          }
          
        },err=>{
          swal({
              title: "Error!",
              text: "Network Issue...",
              timer: 3000,
              showConfirmButton: false
          });
        //   this.progressBarColor = 'Red'
        //   this.ngProgress.done();
        });
      }




      closed(){
        this.viewCtrl.dismiss({adults:"a"})
      }

      public estimateQty(){
        // var elem:any = this.qtyInput;
        // elem._native.nativeElement.select();

        let qty:any = 0;
        if(this.orderObject.Price){
         qty = (parseInt(this.myCollateral) / parseInt(this.orderObject.Price)).toFixed(0)
        }
        return qty;

      }

      public remainingColtrl(){
        let qty:any = 0;

        if(this.orderObject.Quantity && this.orderObject.Price){
            let totalEstQty = (parseFloat(this.orderObject.Quantity) * parseFloat(this.orderObject.Price))
            qty = (parseFloat(this.myCollateral) - totalEstQty).toFixed(0)
        }

        return qty;

      }

      public changeScript(){
        this.navCtrl.push('AddScripPage', { userMWListData: "", clientUserID: this.userData, currentMarketWatch: "" });
      }

      public resetOrderFrm(){
        this.orderObject.Quantity = ''
        this.orderObject.Price = ''
      }

      public select(){
        var elem:any = this.przInput;
        elem._native.nativeElement.select();
    }



//--- Service to call order book --
  loadOrderBook(){
    this.items = [];
    this.itemTR = []
    this.isRecord = ''

    this.cancelBtnFlg = false;
    this.commonService.showLoading()
    // this.progressBarColor = 'white'
    // this.ngProgress.start();
    this.getReportManager.getScripOrderReport("ALL","PendingOrder",this.userData,"").then((data)=>{
      // this.ngProgress.done();
    this.commonService.hideLoading()

      let orderReport_result:any = data;
      if(orderReport_result.reportTable=="" || orderReport_result.reportTable==null){
        this.items = [];
        this.isRecord= orderReport_result.Message
      }else{
        this.items = JSON.parse(orderReport_result.reportTable);
        // console.log("this.orderitems",this.items)
        //---call function to identify underlying,expiry,option and strike
        this.items.forEach((value, index) => {
          this.computeScripDetails(value, index);
        });
        this.items.forEach((value, index) => {
          this.items[index]["exchange"]=this.items[index].Exchange;
          this.items[index]["ticker"]=this.items[index].underlying;

          if(this.items[index].OrderStatus.toUpperCase() == 'ACCEPTED' && parseFloat(this.items[index].TradedQuantity) > 0) {
            this.items[index].OrderStatus = "PARTIALLY COMPLETE";
          } else if(this.items[index].OrderStatus.toUpperCase() == 'ACCEPTED' && parseFloat(this.items[index].TradedQuantity) == 0) {
            this.items[index].OrderStatus = "OPEN";
          }
          
          this.clientMarketWatchList.setData({ watchlistItems: this.items });
        });
        //--console.log("this.items",this.items)
        this.itemTR = this.items;
        
      }
    },err=>{
      swal({
          title: "Error!",
          text: "Network Issue...",
          timer: 3000,
          showConfirmButton: false
      });
      // this.progressBarColor = 'Red'
      // this.ngProgress.done();
    this.commonService.hideLoading()

    });
  }


  //--- Computer Scrip details ---
  computeScripDetails(value, index){
    var tickertype = 'EQT';
    var ScripExchange = value.Exchange;
    var ticker = value.Scrip;

    //---identify each item to be EQT/FUT/OPT to identify underlying, expiry, option type and strike price
    if (ticker.search("~") > 0) {
        tickertype = 'FUT';
        if (ticker.indexOf(":", ticker.indexOf(":") + 1) > 0) {
            tickertype = 'OPT';
        }
        if (ticker.search("~S") > 0) {
            tickertype = 'SPD';
        }
    } else {
        tickertype = 'EQT';
    }

    this.items[index].exchangeLegend = this.GetExchangeLegend(ScripExchange);

    if (tickertype == 'EQT') {
        this.items[index].underlying = ticker.toUpperCase();
        this.items[index].optType = '';
        this.items[index].strikePrice = '';
    }
    if (tickertype == 'FUT') {
        this.items[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.items[index].optType = 'F';
        this.items[index].strikePrice = '';
        this.items[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'OPT') {
        this.items[index].underlying = ticker.substr(0, ticker.search("~")).toUpperCase();
        this.items[index].optType = ticker.substr(ticker.indexOf(":", ticker.indexOf(":") + 1) + 1, 2);
        this.items[index].strikePrice = ticker.substr(ticker.indexOf(":", ticker.indexOf(":", ticker.indexOf(":") + 1) + 1) + 1);
        this.items[index].ExpiryDate = ticker.split(":")[1];
    }
    if (tickertype == 'SPD') {
        this.items[index].underlying = ticker.substr(0, ticker.search("~S")).toUpperCase();
        this.items[index].optType = 'S';
        this.spreadType = ticker.substr(ticker.indexOf(":") + 1);
        this.items[index].ExpiryDate = '';
        this.items[index].strikePrice = this.spreadType.split("~")[0];
    }
  }


  GetExchangeLegend(Exchange){
    var strCode = "";
    switch (Exchange) {
        case "NSE":
            strCode = "N";
            break;
        case "BSE":
            strCode = "B";
            break;
        case "FOBSE":
            strCode = "B";
            break;
        case "CDBSE":
            strCode = "B, CU";
            break;
        case "FONSE":
            strCode = "N";
            break;
        case "ACE":
            strCode = "A";
            break;
        case "CDNSE":
            strCode = "N, CU";
            break;
        case "MCX":
            strCode = "M";
            break;
        case "COMNSE":
            strCode = "COM";
            break;
        case "NCDEX":
            strCode = "X";
            break;
        case "MCXSX":
            strCode = "M, CU";
            break;
        case "NSEL":
            strCode = "NS";
            break;
        case "MCXSXEQ":
            strCode = "M, EQ";
            break;
        case "MCXSXFO":
            strCode = "M, FO";
            break;
        case "NEPSE":
            strCode = "NEP";
            break;
    }
    return (strCode);
  }

  toggleGroup(group) {
    if (this.isGroupShown(group)) {
        this.shownGroup = null;
            console.log(group)

    } else {
        this.shownGroup = group;

    }
  };
  isGroupShown(group) {
    return this.shownGroup === group;

  };



   //---Open order detail page --
   detailsOrder(item){
    this.clientMarketWatchList.setQuoteHeaderData({ quoteItem: item });
    this.navCtrl.push('OrderDetailPage',{userOrderData:item,clientUserData:this.userData});
  }

  public openOrderFRM(item){
    this.navCtrl.pop()
    this.navCtrl.push('BuyPage',{userbuyData:item,clientUserData:this.userData,ismodify:true});
  }

   //---Cancel order --
   public cancelOrder(item){
    item.exchange=item.Exchange;
    item.ticker=item.Scrip;

    this.cancelOrderObject = {
        SessionNo: this.userData.SessionNo,
        ClientCode:this.userData.ClientCode,
        OrderPlacedBy:this.userData.ClientCode,
        Source: "5",
        TradingAccount: item.TradingAccount,
        Exchange: item.exchange,
        Scrip: item.Scrip,
        Quantity: item.RemainingQty,
        Price: item.Price,
        Market: item.MarketOrder,
        OrderTerms: item.OrderTerms,
        BuySellIndicator: item['B/S'],
        BuySellType: item.BuySellType,
        TriggerPrice: item.TriggerPrice,
        DeliveryTerms: item.DeliveryTerms,
        MarketSegment: item.MarketSegment,
        DeliveryFlag: item.TradeType,
        OrderCategory: "NORMAL",
        OrderType: "NORMAL",
        AccrefCode: item.AccRefCode,
        TermValidity: item.TermValidity,
        DisclosedQuantity: item.DisclosedQuantity,
        OrderID: item.BrokerTranID,
        Remarks: 'Cancelled from Mobile App',
        TranID: item.LatestOrderID,
        AMOBulkIndicator: '',
        Status: item.OrderStatus,
        AddModifyFlag:'2'
    };
    if (item.OrderStatus === "AMO") {
        this.cancelOrderObject.AMOBulkIndicator = 'AMO';
    }
    //---build Cancel order querystring
    var CancelOrderqString = '{';
    CancelOrderqString += '"SessionNo":"' + this.cancelOrderObject.SessionNo + '",';
    CancelOrderqString += '"ClientCode":"' + this.cancelOrderObject.ClientCode + '",';
    CancelOrderqString += '"OrderPlacedBy":"' + this.cancelOrderObject.OrderPlacedBy + '",';
    CancelOrderqString += '"Source":"' + this.cancelOrderObject.Source + '",';
    CancelOrderqString += '"TradingAccount":"' + this.cancelOrderObject.TradingAccount + '",';
    CancelOrderqString += '"Exchange":"' + this.cancelOrderObject.Exchange + '",';
    CancelOrderqString += '"Scrip":"' + encodeURIComponent(this.cancelOrderObject.Scrip) + '",';
    CancelOrderqString += '"Quantity":"' + this.cancelOrderObject.Quantity + '",';
    CancelOrderqString += '"Price":"' + this.cancelOrderObject.Price + '",';
    CancelOrderqString += '"Market":"' + this.cancelOrderObject.Market + '",';
    CancelOrderqString += '"OrderTerms":"' + this.cancelOrderObject.OrderTerms + '",';
    CancelOrderqString += '"BuySellIndicator":"' + this.cancelOrderObject.BuySellIndicator + '",';
    CancelOrderqString += '"BuySellType":"' + this.cancelOrderObject.BuySellType + '",';
    CancelOrderqString += '"TriggerPrice":"' + this.cancelOrderObject.TriggerPrice + '",';
    CancelOrderqString += '"DeliveryTerms":"' + this.cancelOrderObject.DeliveryTerms + '",';
    CancelOrderqString += '"MarketSegment":"' + this.cancelOrderObject.MarketSegment + '",';
    CancelOrderqString += '"DeliveryFlag":"' + this.cancelOrderObject.DeliveryFlag + '",';
    CancelOrderqString += '"OrderCategory":"' + this.cancelOrderObject.OrderCategory + '",';
    CancelOrderqString += '"OrderType":"' + this.cancelOrderObject.OrderType + '",';
    CancelOrderqString += '"AccrefCode":"' + this.cancelOrderObject.AccrefCode + '",';
    CancelOrderqString += '"TermValidity":"' + this.cancelOrderObject.TermValidity + '",';
    CancelOrderqString += '"DisclosedQuantity":"' + this.cancelOrderObject.DisclosedQuantity + '",';
    CancelOrderqString += '"OrderID":"' + this.cancelOrderObject.OrderID + '",';
    CancelOrderqString += '"TranID":"' + this.cancelOrderObject.TranID + '",';
    CancelOrderqString += '"AMOBulkIndicator":"' + this.cancelOrderObject.AMOBulkIndicator + '",';
    CancelOrderqString += '"AddModifyFlag":"' + this.cancelOrderObject.AddModifyFlag + '",';

    if (this.cancelOrderObject.Status.toUpperCase() == 'INPROCESS') {
        CancelOrderqString += '"OREOrderID ":"' + this.cancelOrderObject.TranID + '",';
        this.inProcessOrder=true;
        //CancelOrderService = configService.CancelInProcessOrder;
    }
    CancelOrderqString += '"Remarks":"' + this.cancelOrderObject.Remarks + '"}';

    var alerttext = ''; {
        alerttext = "You are cancelling an order <br>" +
            item.Scrip + " - " + item.RemainingQty + " Qty " + "<br>" +
            "Product - " + item.TradingAccount + "<br>" +
            "OrderID - " + item.LatestOrderID + "<br>"
    }
    swal({
      title: 'Cancel Order?',
      html: alerttext,
      type: 'info',
      showCancelButton: true,
      cancelButtonText: "No, let it be !",
      confirmButtonColor: "#387ef5",
      confirmButtonText: "Yes, Cancel order!"
      }).then((result) => {
      if (result.value) {
          //---User want to Cancel Place order--
          this.cancelBtnFlg = true;
           
          this.buySellManager.cancelOrder(CancelOrderqString,this.inProcessOrder).then((data)=>{
            this.cancel_order_result = data;
            if(this.cancel_order_result.ErrorCode == '0'){
            //   closeSlide.close()
              swal({
                  title: "Cancellation Status",
                  text: JSON.stringify(this.cancel_order_result.Message),
                  showCancelButton: true,
                  showConfirmButton: false,
                  cancelButtonText: "Close"
              }).then((result) => {
                  if (result.value) {
                    swal({
                        title: "Redirecting",
                        text: "loading order details",
                        type: "success",
                        showConfirmButton: false,
                        timer: 350
                    });
                    //---Code to redirect to order Detail page goes here --
                    this.navCtrl.push('OrderBookPage');
                  }
              })
              //---reload the page after a cancel so that the order book shows the updated status
              //location.reload();
              this.loadOrderBook()
            }else{
              swal({
                  title: "Cancellation Status",
                  text: JSON.stringify(this.cancel_order_result.Message),
                  type: "info",
                  showCancelButton: true,
                  cancelButtonText: "Close",
                  confirmButtonColor: "#387ef5",
                  confirmButtonText: "Order Detail"
              })
            }

          }, err=> {});
          
          this.cancelBtnFlg = false;  
        }
      })
  }

  public openFilter() {
    console.log("open filter")
    //   let popover = this.popoverCtrl.create('FiltersPage');
    //     popover.present({
    //       ev: "myEvent"
    //     });
    //     popover.onDidDismiss(data => {
    //     })
    // }

    let filterModal = this.modalCtrl.create(
      'FiltersPage', { ev: "v", userMWDepthData: "v" },
      { cssClass: "filterModal" }
    );
    filterModal.present({
      ev: "aaa"
    });
    filterModal.onDidDismiss(data => {
      if (data) {
        let filter = data.filterAt;
        this.filterData(filter)
      }
      console.log(data);
    });

  }

  public filterData(v) {
    this.order = !this.order;

    if (v == 'atoz') {
      this.items.sort((n1, n2) => {
        return (this.order) ? n1['underlying'].localeCompare(n2['underlying']) : n2['underlying'].localeCompare(n1['underlying']);
      });
    } else if (v == 'price') {
      this.items.sort((n1, n2) => {
        return (this.order) ? n1['Price'].localeCompare(n2['Price']) : n2['Price'].localeCompare(n1['Price']);
      });
    } else if (v == 'qty') {
      this.items.sort((n1, n2) => {
        return (this.order) ? n1.Quantity.toString().localeCompare(n2.Quantity.toString()) : n2.Quantity.toString().localeCompare(n1.Quantity.toString());
      });
    } else if (v == 'value') {
      // this.items = this.items.sort((a, b) => b.Price-a.Price); RemainingQty
      this.items.sort((n1, n2) => {
        return (this.order) ? n1['Price'].localeCompare(n2['Price']) : n2['Price'].localeCompare(n1['Price']);
      });
    } else if (v == 'RQty') {
      this.items.sort((a, b) => b.RemainingQty - a.RemainingQty);
      // this.items.sort((n1,n2) => {       
      //   return (this.order)? n1['RemainingQty'].localeCompare(n2['RemainingQty']):n2['RemainingQty'].localeCompare(n1['RemainingQty']);
      // });
    } else if (v == 'status') {
        // this.items = this.items.sort((a, b) => b.Price-a.Price); RemainingQty
        this.items.sort((n1, n2) => {
          return (this.order) ? n1['OrderStatus'].localeCompare(n2['OrderStatus']) : n2['OrderStatus'].localeCompare(n1['OrderStatus']);
        });
      }
    console.log(this.items)

  }

}
